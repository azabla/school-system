<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('main_model');
        ob_start();
        $this->load->helper('cookie');
        $userLevel = userLevel();
        $uperStuDE=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentDE' order by id ASC ");  
        if($this->session->userdata('username') == '' || $uperStuDE->num_rows() < 1 || $userLevel!='1'){
            $this->session->set_flashdata("error","Please Login first");
            $this->load->driver('cache');
            delete_cookie('username');
            unset($_SESSION);
            session_destroy();
            $this->cache->clean();
            ob_clean();
            redirect('login/');
        } 
    }
	public function index($page='student')
	{
        if(!file_exists(APPPATH.'views/home-page/'.$page.'.php')){
            show_404();
        }
        $user=$this->session->userdata('username');
        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;

        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
       
        if(isset($_POST['drop_id'])){
            $id=$this->input->post('drop_id');
            $this->main_model->inactive_staffs($id);
        }
        if(isset($_POST['post_id'])){
            $id=$this->input->post('post_id');
            $this->main_model->delete_student($id);
        }
        $data['academicyear']=$this->main_model->academic_year();
        $data['sessionuser']=$this->main_model->fetch_session_user($user);
        $data['grade']=$this->main_model->fetch_grade($max_year);
        $data['schools']=$this->main_model->fetch_school();
        $data['branch']=$this->main_model->fetch_branch($max_year);
        $this->load->view('home-page/'.$page,$data);
	}
    function filterGradesecfromBranch(){
        if($this->input->post('academicyear')){
            $academicyear=$this->input->post('academicyear');
            echo $this->main_model->filterGradesecfromBranch($academicyear); 
        }
    }
    function Filter_grade_from_branch(){
        $this->load->model('main_model');
        $user=$this->session->userdata('username');
        $usertype=$this->session->userdata('usertype');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if($this->input->post('branchit')){
            $branch=$this->input->post('branchit');
            $grands_academicyear=$this->input->post('grands_academicyear');
            echo $this->main_model->fetch_grade_from_branch($branch,$grands_academicyear); 
        }
    }
    function filterGradeForGroup(){
        $this->load->model('main_model');
        $user=$this->session->userdata('username');
        $usertype=$this->session->userdata('usertype');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if($this->input->post('branchit')){
            $branch=$this->input->post('branchit');
            echo $this->main_model->fetch_grade_from_branch($branch,$max_year); 
        }
    }
    function filterOnlyGradeFromBranch(){
        $user=$this->session->userdata('username');
        $usertype=$this->session->userdata('usertype');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if($this->input->post('branchit')){
            $branch=$this->input->post('branchit');
            $grands_academicyear=$this->input->post('grands_academicyear');
            echo $this->main_model->fetchOnlyGradeFromBranch($branch,$grands_academicyear); 
        }
    }
    function filterOnlyGradeFromBranchForGroup(){
        $user=$this->session->userdata('username');
        $usertype=$this->session->userdata('usertype');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if($this->input->post('branchit')){
            $branch=$this->input->post('branchit');
            echo $this->main_model->fetchOnlyGradeFromBranch($branch,$max_year); 
        }
    }
    function downloadStuData(){
        $YearName = sessionAcademicYear();
        $max_year=$YearName['year'];
        $accessbranch = sessionUseraccessbranch();
        if($_SESSION['usertype']===trim('superAdmin') || $accessbranch === '1'){
            $queryStuddent=$this->db->query("select username,fname,mname,lname,gender,
            grade,section,father_mobile,mobile,mother_name,dob,age,email,password,city,sub_city,woreda,kebele,dateregister,branch,academicyear from users where usertype='Student' and status='Active' and isapproved='1' and academicyear='$max_year' order by fname ASC ");
        }else{
            $branchName = sessionUserDetailNonStudent();
            $branch=$branchName['branch'];
            $queryStuddent=$this->db->query("select username,fname,mname,lname,gender,
            grade,section,father_mobile,mobile,mother_name,dob,age,email,password,city,sub_city,woreda,kebele,dateregister,branch,academicyear from users where usertype='Student' and status='Active' and isapproved='1' and academicyear='$max_year' and branch='$branch' order by fname ASC ");
        }
        $filename ='Student-Data.csv';  
        header('Content-Type: testx/csv;charset=utf-8');
        header('Content-Disposition: attachment;filename="'.$filename.'"'); 
        $output=fopen('php://output', 'w');
        fputcsv($output,array('Student ID','First Name','Middle Name','Last Name','Gender','Grade','Section','Father Mobile','Mother Mobile','Mother Name','Date of birth','Age','Email','Password','City','Sub city','Woreda','Kebele','Registration Date','Branch','Academic year'));
        foreach ($queryStuddent->result_array() as $row) {
            fputcsv($output,$row);
        } 
        fclose($output);
    }
    function searchStudent(){
        $accessbranch = sessionUseraccessbranch();
        $branchName = sessionUserDetailNonStudent();
        $branch=$branchName['branch'];
        $YearName = sessionAcademicYear();
        $max_year=$YearName['year'];
        if($this->input->post('searchItem')){
            $searchItem=$this->input->post('searchItem');
            if($_SESSION['usertype']===trim('superAdmin') || $accessbranch === '1'){
                echo $this->main_model->searchStudents($searchItem,$max_year);
            }else{
                echo $this->main_model->searchAdminStudents($searchItem,$branch,$max_year);
            }
        }
    }
    function Fecth_thistudent(){
        $accessbranch = sessionUseraccessbranch();
        $branchName = sessionUserDetailNonStudent();
        $branch=$branchName['branch'];
        if($this->input->post('gs_branches')){
            $gs_branches=$this->input->post('gs_branches');
            $gs_gradesec=$this->input->post('gs_gradesec');
            $onlyGrade=$this->input->post('onlyGrade');
            $grands_academicyear=$this->input->post('grands_academicyear');
            if($_SESSION['usertype']===trim('superAdmin') || $accessbranch === '1'){
                echo $this->main_model->fetch_branchstudents($gs_branches,$onlyGrade,$gs_gradesec,$grands_academicyear);
            }else{
                echo $this->main_model->fetch_branchstudents($branch,$onlyGrade,$gs_gradesec,$grands_academicyear);
            }
        } 
    }
    function editstudent(){
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if($this->input->post('editedId')){
            $editedId=$this->input->post('editedId');
            $newAcademicYear=$this->input->post('newAcademicYear');
            echo $this->main_model->fetch_student_toedit($editedId,$newAcademicYear);
        }
    }
    function viewStudentPrint(){
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if($this->input->post('editedId')){
            $editedId=$this->input->post('editedId');
            echo $this->main_model->viewStudentPrint($editedId,$max_year);
        }
    }
    function resetPassword(){
        if($this->input->post('editedId')){
            $editedId=$this->input->post('editedId');
            $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
            $pass = array(); //remember to declare $pass as an array
            $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
            for ($i = 0; $i < 8; $i++) {
                $n = rand(0, $alphaLength);
                $pass[] = $alphabet[$n];
            }
            $temp_pass= implode($pass); //turn the array into a string
            $passHash=hash('sha256', $temp_pass);
            $data=array(
                'password'=>$passHash,
                'password2'=>$passHash
            );
            echo $this->main_model->reset_student_password($editedId,$data,$temp_pass);
        }
    }
    /*function resetAllStudentPassword(){
        $query=$this->db->query("select username from users where usertype='Student' and isapproved='1' and status='Active' group by username ");
        $nextP='12345';
        foreach($query->result() as $passwordG){
            $userName=$passwordG->username;
            $allPass=$userName.$nextP;
            $passHash=hash('sha256', $allPass);
            $this->db->where('username',$userName);
            $this->db->where('usertype','Student');
            $this->db->set('password',$passHash);
            $this->db->set('password2',$passHash);
            $queryCheck=$this->db->update('users');

        }
        if($queryCheck){
                echo 'Good';
            }else{
                echo 'Bad';
            }
    }*/
    function updateStudents(){
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        $config['upload_path']    = './profile/';
        $config['allowed_types']  = 'gif|jpg|png|ico';
        $this->load->library('upload', $config);
        $stuAcademicYear=$this->input->post('stuAcademicYear');
        $stuid=$this->input->post('stuStuid');
        $username=$this->input->post('stUsername');
        $fname=$this->input->post('stuFname');
        $mname=$this->input->post('stuLname');
        $lname=$this->input->post('stuGfname');
        $gender=$this->input->post('stuGender');
        $mobile=$this->input->post('stuMobile');
        $fmobile=$this->input->post('father_mobile');
        $grade=$this->input->post('stuGrade');
        $section=$this->input->post('stuSection');
        $email=$this->input->post('stuEmail');
        $dob=$this->input->post('stuDob');
        $stuAge=$this->input->post('stuAge');
        $city=$this->input->post('stuCity');
        $subcity=$this->input->post('stuSubcity');
        $woreda=$this->input->post('stuWoreda');
        $kebele=$this->input->post('stuKebele');
        $transportService=$this->input->post('transportService');
        if($this->upload->do_upload('stuProfile')){
            $dataa = $this->upload->data('file_name');
            $data=array(
                'fname'=>$fname,
                'mname'=>$mname,
                'lname'=>$lname,
                'gender'=>$gender,
                'mobile'=>$mobile,
                'father_mobile'=>$fmobile,
                'email'=>$email,
                'dob'=>$dob,
                'age'=>$stuAge,
                'city'=>$city,
                'sub_city'=>$subcity,
                'woreda'=>$woreda,
                'kebele'=>$kebele,
                'transportservice'=>$transportService,
                'profile'=>$dataa
            );
            $this->db->where(array('unique_id'=>$stuid));
            $this->db->where('academicyear',$stuAcademicYear);
            $this->db->set('grade',$grade);
            $this->db->set('section',$section);
            $this->db->set('gradesec',$grade.$section);
            $queryUpdate=$this->db->update('users');
            if($queryUpdate){
                echo $this->main_model->update_student_detail($stuid,$username,$data,$max_year);
            }
        }else{
           $data=array(
                'fname'=>$fname,
                'mname'=>$mname,
                'lname'=>$lname,
                'gender'=>$gender,
                'mobile'=>$mobile,
                'father_mobile'=>$fmobile,
                'email'=>$email,
                'dob'=>$dob,
                'age'=>$stuAge,
                'city'=>$city,
                'sub_city'=>$subcity,
                'woreda'=>$woreda,
                'kebele'=>$kebele,
                'transportservice'=>$transportService
            );
            $this->db->where(array('unique_id'=>$stuid));
            $this->db->where('academicyear',$stuAcademicYear);
            $this->db->set('grade',$grade);
            $this->db->set('section',$section);
            $this->db->set('gradesec',$grade.$section);
            $queryUpdate=$this->db->update('users');
            if($queryUpdate){
                echo $this->main_model->update_student_detail($stuid,$username,$data,$max_year);
            }
        }
    }
    function fecthThiStudentAttendance(){
        $quarterName = sessionQuarterDetail();
        $max_quarter=$quarterName['quarter'];
        if($this->input->post('stuID')){
            $stuID=$this->input->post('stuID');
            $yearattende=$this->input->post('yearattende');
            echo $this->main_model->fecthThiStudentAttendance($stuID,$yearattende,$max_quarter);
        }
    }
    function searchStudentsToTransportService(){
        $accessbranch = sessionUseraccessbranch();
        $branchName = sessionUserDetailNonStudent();
        $branch=$branchName['branch'];
        $YearName = sessionAcademicYear();
        $max_year=$YearName['year'];
        if($this->input->post('searchItem')){
            $searchItem=$this->input->post('searchItem');
            if($_SESSION['usertype']===trim('superAdmin') || $accessbranch === '1'){
                echo $this->main_model->searchStudentsToTransportService($searchItem,$max_year);
            }else{
                echo $this->main_model->searchStudentsToTransportServiceNotAccess($searchItem,$branch,$max_year);
            }
            
        }
    }
    function saveNewTransportPlace(){
        $YearName = sessionAcademicYear();
        $max_year=$YearName['year'];
        if($this->input->post('stuIdArray')){
            $stuIdArray=$this->input->post('stuIdArray');
            $takeAction=$this->input->post('takeAction');
            if($takeAction=='dropGroup'){
                foreach($stuIdArray as $stuIdArrays){
                    $this->db->where('username',$stuIdArrays);
                    $this->db->where('academicyear',$max_year);
                    $this->db->set('status','Inactive');
                    $queryUpdate=$this->db->update('users');
                }
                if($queryUpdate){
                    echo '<div class="alert alert-success alert-dismissible show fade">
                        <div class="alert-body">
                        <i class="fas fa-check-circle"> </i> Group Droped successfully.
                    </div></div>';
                }else{
                    echo '<div class="alert alert-warning alert-dismissible show fade">
                        <div class="alert-body">
                        <i class="fas fa-check-circle"> </i> Please try again.
                    </div></div>'; 
                }
            } 
            else if($takeAction=='deleteGroup'){
                foreach($stuIdArray as $stuIdArrays){
                    $this->db->where('username',$stuIdArrays);
                    $this->db->where('academicyear',$max_year);
                    $queryUpdate=$this->db->delete('users');
                }
                if($queryUpdate){
                    echo '<div class="alert alert-success alert-dismissible show fade">
                        <div class="alert-body">
                        <i class="fas fa-check-circle"> </i> Group Deleted successfully.
                    </div></div>';
                }else{
                    echo '<div class="alert alert-warning alert-dismissible show fade">
                        <div class="alert-body">
                        <i class="fas fa-check-circle"> </i> Please try again.
                    </div></div>'; 
                }
            }
            else if($takeAction=='adjustTransPlace'){
                $newServiceTransPlace=trim($this->input->post('newServiceTransPlace'));
                if($newServiceTransPlace!==''){
                    foreach($stuIdArray as $stuIdArrays){
                        $this->db->where('username',$stuIdArrays);
                        $this->db->where('academicyear',$max_year);
                        $this->db->set('transportservice',$newServiceTransPlace);
                        $queryUpdate=$this->db->update('users');
                    }
                    if($queryUpdate){
                        echo '<div class="alert alert-success alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Transport Service updated successfully.
                        </div></div>';
                    }else{
                        echo '<div class="alert alert-warning alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Please try again.
                        </div></div>'; 
                    }
                }else{
                    echo '<div class="alert alert-warning alert-dismissible show fade">
                        <div class="alert-body">
                        <i class="fas fa-check-circle"> </i> Please Enter new Transport Place.
                    </div></div>';
                } 
            }
            else if($takeAction=='sectionGroup'){
                $newSection=trim($this->input->post('newSection'));
                $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
                $row2 = $query2->row();
                $max_quarter=$row2->quarter;
                if($newSection!==''){
                    foreach($stuIdArray as $stuIdArrays){
                        $queryFetchSection=$this->db->query("select grade,section,branch,id from users where academicyear='$max_year' and username='$stuIdArrays' ");
                        foreach($queryFetchSection->result_array() as $queryRow){


                            /*$queryRow=$queryFetchSection->row_array();*/
                            $grades=$queryRow['grade'];
                            $oldSection=$queryRow['section'];
                            $oldBranch=$queryRow['branch'];
                            $studId=$queryRow['id'];
                            $oldGradesec=$grades.$oldSection;

                            $newGradesec=$grades.$newSection;

                            $this->db->where('username',$stuIdArrays);
                            $this->db->where('academicyear',$max_year);
                            $this->db->set('section',$newSection);
                            $this->db->set('gradesec',$grades.$newSection);
                            $queryUpdate=$this->db->update('users');
                            if($queryUpdate){
                                $queryCheck = $this->db->query("SHOW TABLES LIKE 'mark".$oldBranch.$oldGradesec.$max_quarter.$max_year."' ");
                                if ($queryCheck->num_rows()>0)
                                {
                                    $queryMark=$this->db->query("SELECT * FROM mark".$oldBranch.$oldGradesec.$max_quarter.$max_year." where stuid='$studId' ");
                                    foreach($queryMark->result() as $newMark){
                                        $dataMark[]=array(
                                            'stuid'=>$newMark->stuid,
                                            'mgrade'=>$newMark->mgrade,
                                            'subname'=>$newMark->subname,
                                            'evaid'=>$newMark->evaid,
                                            'quarter'=>$newMark->quarter,
                                            'outof'=>$newMark->outof,
                                            'value'=>$newMark->value,
                                            'academicyear'=>$newMark->academicyear,
                                            'markname'=>$newMark->markname,
                                            'status'=>$newMark->status,
                                            'lockmark'=>$newMark->lockmark,
                                            'approved'=>$newMark->approved,
                                            'approvedby'=>$newMark->approvedby,
                                            'zeromarkinfo'=>$newMark->zeromarkinfo,
                                            'mbranch'=>$newMark->mbranch

                                        );
                                    }
                                    if(!empty($dataMark)){
                                        $queryInsert=$this->db->insert_batch('mark'.$oldBranch.$newGradesec.$max_quarter.$max_year,$dataMark);
                                        if($queryInsert){

                                        
                                            $this->db->where('stuid',$studId);
                                            $this->db->where('academicyear',$max_year);
                                            $this->db->set('mgrade',$grades.$newSection);
                                            $queryUpdateMark=$this->db->update('mark'.$oldBranch.$newGradesec.$max_quarter.$max_year);
                                            if($queryUpdateMark){
                                                $this->db->where('stuid',$studId);
                                                $this->db->where('academicyear',$max_year);
                                                $queryDeleteMark=$this->db->delete('mark'.$oldBranch.$oldGradesec.$max_quarter.$max_year);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if($queryUpdate){
                        echo '<div class="alert alert-success alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Group Section updated successfully.
                        </div></div>';
                    }else{
                        echo '<div class="alert alert-warning alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Please try again.
                        </div></div>'; 
                    }
                }else{
                    echo '<div class="alert alert-warning alert-dismissible show fade">
                        <div class="alert-body">
                        <i class="fas fa-check-circle"> </i> Please Enter Section.
                    </div></div>';
                } 
            }
            else if($takeAction=='gradeGroup'){
                $newGrade=trim($this->input->post('newGrade'));
                if($newGrade!==''){
                    foreach($stuIdArray as $stuIdArrays){
                        $queryFetchSection=$this->db->query("select section from users where academicyear='$max_year' and username='$stuIdArrays' ");
                        $queryRow=$queryFetchSection->row_array();
                        $section=$queryRow['section'];

                        $this->db->where('username',$stuIdArrays);
                        $this->db->where('academicyear',$max_year);
                        $this->db->set('grade',$newGrade);
                        $this->db->set('gradesec',$newGrade.$section);
                        $queryUpdate=$this->db->update('users');
                    }
                    if($queryUpdate){
                        echo '<div class="alert alert-success alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Group Grade updated successfully.
                        </div></div>';
                    }else{
                        echo '<div class="alert alert-warning alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Please try again.
                        </div></div>'; 
                    }
                }else{
                    echo '<div class="alert alert-warning alert-dismissible show fade">
                        <div class="alert-body">
                        <i class="fas fa-check-circle"> </i> Please Enter Grade.
                    </div></div>';
                } 
            }
            else if($takeAction=='branchGroup'){
                $branchGroup=trim($this->input->post('branchGroup'));
                if($branchGroup!==''){
                    foreach($stuIdArray as $stuIdArrays){
                        $this->db->where('username',$stuIdArrays);
                        $this->db->where('academicyear',$max_year);
                        $this->db->set('branch',$branchGroup);
                        $queryUpdate=$this->db->update('users');
                    }
                    if($queryUpdate){
                        echo '<div class="alert alert-success alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Group Branch updated successfully.
                        </div></div>';
                    }else{
                        echo '<div class="alert alert-warning alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Please try again.
                        </div></div>'; 
                    }
                }else{
                    echo '<div class="alert alert-warning alert-dismissible show fade">
                        <div class="alert-body">
                        <i class="fas fa-check-circle"> </i> Please Enter Branch.
                    </div></div>';
                } 
            }
        }
    }
    function changeDefaultGroupEdit(){
        $YearName = sessionAcademicYear();
        $max_year=$YearName['year'];
        $accessbranch = sessionUseraccessbranch();
        $branchName = sessionUserDetailNonStudent();
        $branch=$branchName['branch'];
        if($this->input->post('groupBranch')){
            if($_SESSION['usertype']===trim('superAdmin') || $accessbranch === '1'){
                $groupBranch=$this->input->post('groupBranch');
            }else{
                $groupBranch=$branch;
            }
            /*$groupBranch=$this->input->post('groupBranch');*/
            $groupGrade=$this->input->post('groupGrade');
            $groupSection=$this->input->post('groupSection');
            $actionType=$this->input->post('actionType');
            if($groupSection == '' && $groupGrade != ''){
                if($actionType=='deleteBranchGroup'){
                    $this->db->where('branch',$groupBranch);
                    $this->db->where('grade',$groupGrade);
                    $this->db->where('academicyear',$max_year);
                    $queryUpdate=$this->db->delete('users');
                    if($queryUpdate){
                        echo '<div class="alert alert-success alert-dismissible show fade">
                                <div class="alert-body">
                                <i class="fas fa-check-circle"> </i> Group Deleted successfully.
                            </div></div>';
                    }else{
                        echo '<div class="alert alert-warning alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Please try again.
                        </div></div>';
                    }
                }elseif($actionType=='dropBranchGroup'){
                    $this->db->where('branch',$groupBranch);
                    $this->db->where('grade',$groupGrade);
                    $this->db->where('academicyear',$max_year);
                    $this->db->set('status','Inactive');
                    $queryUpdate=$this->db->update('users');
                    if($queryUpdate){
                        echo '<div class="alert alert-success alert-dismissible show fade">
                                <div class="alert-body">
                                <i class="fas fa-check-circle"> </i> Group updated successfully.
                            </div></div>';
                    }else{
                        echo '<div class="alert alert-warning alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Please try again.
                        </div></div>';
                    }
                }elseif($actionType=='undropBranchGroup'){
                    $this->db->where('branch',$groupBranch);
                    $this->db->where('grade',$groupGrade);
                    $this->db->where('academicyear',$max_year);
                    $this->db->set('status','Active');
                    $queryUpdate=$this->db->update('users');
                    if($queryUpdate){
                        echo '<div class="alert alert-success alert-dismissible show fade">
                                <div class="alert-body">
                                <i class="fas fa-check-circle"> </i> Group updated successfully.
                            </div></div>';
                    }else{
                        echo '<div class="alert alert-warning alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Please try again.
                        </div></div>';
                    }
                }
            }else{
                if($actionType=='deleteBranchGroup'){
                    $this->db->where('branch',$groupBranch);
                    $this->db->where('gradesec',$groupSection);
                    $this->db->where('academicyear',$max_year);
                    $queryUpdate=$this->db->delete('users');
                    if($queryUpdate){
                        echo '<div class="alert alert-success alert-dismissible show fade">
                                <div class="alert-body">
                                <i class="fas fa-check-circle"> </i> Group Deleted successfully.
                            </div></div>';
                    }else{
                        echo '<div class="alert alert-warning alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Please try again.
                        </div></div>';
                    }
                }elseif($actionType=='dropBranchGroup'){
                    $this->db->where('branch',$groupBranch);
                    $this->db->where('gradesec',$groupSection);
                    $this->db->where('academicyear',$max_year);
                    $this->db->set('status','Inactive');
                    $queryUpdate=$this->db->update('users');
                    if($queryUpdate){
                        echo '<div class="alert alert-success alert-dismissible show fade">
                                <div class="alert-body">
                                <i class="fas fa-check-circle"> </i> Group updated successfully.
                            </div></div>';
                    }else{
                        echo '<div class="alert alert-warning alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Please try again.
                        </div></div>';
                    }
                }elseif($actionType=='undropBranchGroup'){
                    $this->db->where('branch',$groupBranch);
                    $this->db->where('gradesec',$groupSection);
                    $this->db->where('academicyear',$max_year);
                    $this->db->set('status','Active');
                    $queryUpdate=$this->db->update('users');
                    if($queryUpdate){
                        echo '<div class="alert alert-success alert-dismissible show fade">
                                <div class="alert-body">
                                <i class="fas fa-check-circle"> </i> Group updated successfully.
                            </div></div>';
                    }else{
                        echo '<div class="alert alert-warning alert-dismissible show fade">
                            <div class="alert-body">
                            <i class="fas fa-check-circle"> </i> Please try again.
                        </div></div>';
                    }
                }
            }
        }
    }
}
