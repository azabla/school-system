<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Addlesson extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('main_model');
    ob_start();
    $this->load->helper('cookie');
    $userLevel = userLevel();
    $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='homeworkworksheet' order by id ASC ");
        if($this->session->userdata('username') == '' || $usergroupPermission->num_rows()<1 || $userLevel!='1'){
          $this->session->set_flashdata("error","Please Login first");
          $this->load->driver('cache');
          delete_cookie('username');
          unset($_SESSION);
          session_destroy();
          $this->cache->clean();
          ob_clean();
          redirect('login/');
        } 
  }
	public function index($page='addlesson')
	{
         if(!file_exists(APPPATH.'views/home-page/'.$page.'.php')){
            show_404();
        }
        $this->load->model('main_model');
        $config['upload_path'] = './lessonworksheet/';
        $config['allowed_types'] ='docx|pdf|mp4';
        $this->load->library('upload', $config);

        $user=$this->session->userdata('username');
        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;

        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        
        if(isset($_POST['addlessonnow'])){
          $subject=$this->input->post('subject');
          $gradesec=$this->input->post('gradesec');
          $title=$this->input->post('title');
          $note=$this->input->post('note');
          $this->upload->do_upload('pdfdoc');
          $notepdf= $this->upload->data('file_name');
          if($notepdf ==''){
            $query=$this->main_model->insert_lesson($user,$subject,$gradesec,$title,$note,$max_year);
          }else{
            $query=$this->main_model->insert_lesson2($user,$subject,$gradesec,$title,$notepdf,$max_year);
          }
          if($query){
            $this->session->set_flashdata('success','Lesson Inserted successfully.');
             redirect('Addlesson/');
          }else{
            $this->session->set_flashdata('error','Something wrong please try again.');
            redirect('Addlesson/');
          }
        }
        $accessbranch = sessionUseraccessbranch();
        $data['sessionuser']=$this->main_model->fetch_session_user($user);
        $data['academicyear']=$this->main_model->academic_year_filter();
        $data['schools']=$this->main_model->fetch_school();
        $data['posts']=$this->main_model->fetch_post();
        if(trim($_SESSION['usertype'])===trim('superAdmin') || $accessbranch === '1')
        {
          $data['fetch_gradesec']=$this->main_model->fetch_myschool_gradesec($max_year);
        }else{
          $data['fetch_gradesec']=$this->main_model->fetch_mybranch_gradesec($branch,$max_year);
        }
		    $this->load->view('home-page/'.$page,$data);
	} 

}