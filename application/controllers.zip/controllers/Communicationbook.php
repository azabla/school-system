<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Communicationbook extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('main_model');
    ob_start();
    $this->load->helper('cookie');
    $userLevel = userLevel();
    $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='communicationbook' order by id ASC "); 
    if($this->session->userdata('username') == '' || $usergroupPermission->num_rows()<1 || $userLevel!='1'){
      $this->session->set_flashdata("error","Please Login first");
      $this->load->driver('cache');
      delete_cookie('username');
      unset($_SESSION);
      session_destroy();
      $this->cache->clean();
      ob_clean();
      redirect('login/');
    }   
  }
	public function index($page='communicationbook')
	{
    if(!file_exists(APPPATH.'views/home-page/'.$page.'.php')){
      show_404();
    }
    $user=$this->session->userdata('username');
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $data['branch']=$this->main_model->fetch_branch($max_year);
    $data['sessionuser']=$this->main_model->fetch_session_user($user);
    $data['academicyear']=$this->main_model->academic_year_filter();
    $data['schools']=$this->main_model->fetch_school();
    $data['subjects']=$this->main_model->fetch_all_subject($max_year);
    $data['subj4merged']=$this->main_model->fetchAllSubject4Forged($max_year);
    $data['grades_subject']=$this->main_model->fetch_subject_grades($max_year);
    $data['usertype']=$this->main_model->fetch_usertype();
    $this->load->view('home-page/'.$page,$data);
	} 
  function fetchCommunicationBookTeacher(){
    $user=$this->session->userdata('username');
    $userType=$this->session->userdata('usertype');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch_teacher=$row_branch->branch;
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;

    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;

    $queryAccessBranch=$this->db->query("select accessbranch from usegroup where uname='$userType' ");
    $rowaccessbranch = $queryAccessBranch->row_array();
    $accessbranch=$rowaccessbranch['accessbranch'];

    if($_SESSION['usertype']===trim('superAdmin') || $accessbranch === '1'){
      echo $this->main_model->fetchCommunicationBooksuAdmin($user,$max_year,$max_quarter);
    }else{
      echo $this->main_model->fetchCommunicationBookAdmin($user,$branch_teacher,$max_year,$max_quarter); 
    } 
  }
  function viewComBookId(){
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('viewlessonplan')){
      $lessonID=$this->input->post('viewlessonplan');
      echo $this->main_model->viewComBookId($lessonID,$max_year);
    }
  }
  function fetchCustomText(){
    echo $this->main_model->fetchCustomText();
  }
  function postCustomText(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('customTextName')){
      $customTextName=$this->input->post('customTextName');
      $data=array(
        'comtext'=>$customTextName,
        'academicyear'=>$max_year,
        'datecreated'=>date('M-d-Y'),
        'createdby'=>$user
      );
      $queryInsert= $this->db->insert('customcomtext',$data);
      if($queryInsert){
        echo '<div class="alert alert-success alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Text saved successfully.
            </div></div>';
      }else{
        echo '<div class="alert alert-warning alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Ooops Please try again.
            </div></div>';
      }
    }
  }
  function deleteCustomText(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['textId'])){
      $id=$this->input->post('textId');
      $this->db->where('id',$id);
      $query=$this->db->delete('customcomtext');
    }
  }

}