<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class My_mark_status extends CI_Controller {
    public function __construct(){
        parent::__construct();
        if($this->session->userdata('username') == ''){
            $this->session->set_flashdata("error","Please Login first");
            redirect('login/');
        }
    }
	public function index()
	{
        $this->load->model('main_model');
        $user=$this->session->userdata('username');
        $usertype=$this->session->userdata('usertype');

        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;

        $query_gradesec = $this->db->query("select * from users where username='$user' and academicyear='$max_year' ");
        $row_gradesec = $query_gradesec->row();
        $grade=$row_gradesec->grade;
        $gradesec=$row_gradesec->gradesec;
        $id=$row_gradesec->id;
        $branch1=$row_gradesec->branch;

        

        $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
        $row2 = $query2->row();
        $max_quarter=$row2->quarter;
        if(isset($_POST['view'])){
            if($_POST['view']!=''){
                $this->main_model->update_myunseen_mark($id,$branch1,$gradesec,$max_quarter,$max_year);
            }
            $this->db->where('academicyear',$max_year);
            $queryCheck = $this->db->get('enableapprovemark');
            if($queryCheck->num_rows()>0){
                $show=$this->main_model->fetch_allmymarkstatusApproved($id,$branch1,$gradesec,$max_quarter,$max_year);
                $result['notification']=$show;
                
                $tot=$this->main_model->fetch_allunseetseen_mymarkApproved($id,$branch1,$gradesec,$max_quarter,$max_year);
                $result['unseen_notification']=$tot;
                echo json_encode($result);
            }else{
                $show=$this->main_model->fetch_allmymarkstatus($id,$branch1,$gradesec,$max_quarter,$max_year);
                $result['notification']=$show;
                
                $tot=$this->main_model->fetch_allunseetseen_mymark($id,$branch1,$gradesec,$max_quarter,$max_year);
                $result['unseen_notification']=$tot;
                echo json_encode($result); 
            }
        } 
	}    
}