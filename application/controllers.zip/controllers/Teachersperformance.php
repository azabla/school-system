<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teachersperformance extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('main_model');
    ob_start();
    $this->load->helper('cookie');
    $userLevel = userLevel();
    $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='communicationbook' order by id ASC "); 
    if($this->session->userdata('username') == '' || $usergroupPermission->num_rows()<1 || $userLevel!='1'){
      $this->session->set_flashdata("error","Please Login first");
      $this->load->driver('cache');
      delete_cookie('username');
      unset($_SESSION);
      session_destroy();
      $this->cache->clean();
      ob_clean();
      redirect('login/');
    }   
  }
	public function index($page='teachersperformance')
	{
    if(!file_exists(APPPATH.'views/home-page/'.$page.'.php')){
      show_404();
    }
    $user=$this->session->userdata('username');
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $data['branch']=$this->main_model->fetch_branch($max_year);
    $data['sessionuser']=$this->main_model->fetch_session_user($user);
    $data['academicyear']=$this->main_model->academic_year_filter();
    $data['schools']=$this->main_model->fetch_school();
    $data['subjects']=$this->main_model->fetch_all_subject($max_year);
    $data['subj4merged']=$this->main_model->fetchAllSubject4Forged($max_year);
    $data['grades_subject']=$this->main_model->fetch_subject_grades($max_year);
    $data['usertype']=$this->main_model->fetch_usertype();
    $data['perGroup']=$this->main_model->fetchPerformanceGroup($max_year);
    $this->load->view('home-page/'.$page,$data);
	} 
  function fetchCustomGroup(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;
    echo $this->main_model->fetchCustomGroup($max_year,$max_quarter);
  }
  function postCustomGroup(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;
    if($this->input->post('customGroupName')){
      $customGroupName=trim($this->input->post('customGroupName'));
      $customGroupWeight=trim($this->input->post('customGroupWeight'));
      $data=array(
        'pername'=>$customGroupName,
        'quarter'=>$max_quarter,
        'perweight'=>$customGroupWeight,
        'academicyear'=>$max_year,
        'datecreated'=>date('M-d-Y'),
        'createdby'=>$user
      );
      $queryInsert= $this->db->insert('teacherperfogroup',$data);
      if($queryInsert){
        echo '<div class="alert alert-success alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Group saved successfully.
            </div></div>';
      }else{
        echo '<div class="alert alert-warning alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Ooops Please try again.
            </div></div>';
      }
    }
  }
  function deleteCustomGroup(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['textId'])){
      $id=$this->input->post('textId');
      $this->db->where('tid',$id);
      $query=$this->db->delete('teacherperfogroup');
    }
  }
  function fetchCustomActivity(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;
    echo $this->main_model->fetchCustomActivity($max_year,$max_quarter);
  }
  function postCustomActivity(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;
    if($this->input->post('selectperGroup')){
      $selectperGroup=trim($this->input->post('selectperGroup'));
      $customActivitiesName=trim($this->input->post('customActivitiesName'));
      $data=array(
        'acname'=>$customActivitiesName,
        'pergroup'=>$selectperGroup,
        'quarter'=>$max_quarter,
        'academicyear'=>$max_year,
        'datecreated'=>date('M-d-Y'),
        'createdby'=>$user
      );
      $queryInsert= $this->db->insert('teacherperactivity',$data);
      if($queryInsert){
        echo '<div class="alert alert-success alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Activity saved successfully.
            </div></div>';
      }else{
        echo '<div class="alert alert-warning alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Ooops Please try again.
            </div></div>';
      }
    }
  }
  function deleteCustomActivity(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['textId'])){
      $id=$this->input->post('textId');
      $this->db->where('aid',$id);
      $query=$this->db->delete('teacherperactivity');
    }
  }
  function fetchStaffToPerformActivity(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;
    if(isset($_POST['activityYear'])){
      $activityYear=$this->input->post('activityYear');
      $activityBranch=$this->input->post('activityBranch');
      echo $this->main_model->fetchStaffToPerformActivity($activityYear,$activityBranch,$max_quarter);
    }
  }
  function updateTeacherPerformance(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;
    if(isset($_POST['value'])){
      $value=trim($this->input->post('value'));
      $teid=trim($this->input->post('teid'));
      $acname=trim($this->input->post('acname'));
      $quarter=trim($this->input->post('quarter'));
      $data=array(
        'teid'=>$teid,
        'acid'=>$acname,
        'pervalue'=>$value,
        'quarter'=>$quarter,
        'academicyear'=>$max_year,
        'datecreated'=>date('M-d-Y'),
        'valueby'=>$user
      );
      $queryCheck=$this->db->query("select acid,pervalue from teacherperfvalue where academicyear='$max_year' and quarter='$quarter' and acid='$acname' and teid='$teid' ");
      if($queryCheck->num_rows()>0){
        $this->db->where('teid',$teid);
        $this->db->where('acid',$acname);
        $this->db->where('quarter',$quarter);
        $this->db->where('academicyear',$max_year);
        $this->db->set('pervalue',$value);
        $queryUpdated=$this->db->update('teacherperfvalue');
      }else{
        $queryInserted=$this->db->insert('teacherperfvalue',$data);
      }
    }
  }
  function fetchStaffPerformResult(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;
    if(isset($_POST['activityYear'])){
      $activityYear=$this->input->post('activityYear');
      $activityBranch=$this->input->post('activityBranch');
      echo $this->main_model->fetchStaffPerformResult($activityYear,$activityBranch,$max_quarter);
    }
  }

}