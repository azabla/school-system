<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Change_bgcolor extends CI_Controller {
  public function __construct(){
    parent::__construct();
    if($this->session->userdata('username') == ''){
      $this->session->set_flashdata("error","Please Login first");
      redirect('Login');
    }     
  }
  public function index($page='staffs')
  {
    if(!file_exists(APPPATH.'views/home-page/'.$page.'.php')){
      show_404();
    }
    $this->load->model('main_model');
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $id=$row_branch->id;

    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['bgcolor'])){
      $bgcolor=$this->input->post('bgcolor');
      $q_bgcolor=$this->db->query("select * from bgcolor where sid='$id' ");
      if($q_bgcolor->num_rows()>0){
        $this->db->where('sid',$id);
        $this->db->set('bgcolor',$bgcolor);
        $this->db->set('sid',$id);
        $query=$this->db->update('bgcolor');
      }else{
        $data=array(
          'sid'=>$id,
          'bgcolor'=>$bgcolor
        );
        $this->db->where('sid',$id);
        $this->db->insert('bgcolor',$data);
      }  
    }
  } 
}