<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Miprofile extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('main_model');
        ob_start();
        $this->load->helper('cookie');
        $userLevel = userLevel();
        if($this->session->userdata('username') == '' || $userLevel!='2'){
          $this->session->set_flashdata("error","Please Login first");
          $this->load->driver('cache');
          delete_cookie('username');
          unset($_SESSION);
          session_destroy();
          $this->cache->clean();
          ob_clean();
          redirect('login/');
        } 
    }
    public function index($page='myprofile')
    {
        if(!file_exists(APPPATH.'views/teacher/'.$page.'.php')){
            show_404();
        }
        $user=$this->session->userdata('username');
        $data['sessionuser']=$this->main_model->fetch_session_user($user);
        $data['academicyear']=$this->main_model->academic_year();
        $data['schools']=$this->main_model->fetch_school();//school
        $data['posts']=$this->main_model->fetch_post();
        $this->load->view('teacher/'.$page,$data);
    } 
    function updateMyProfile(){
        $user=$this->session->userdata('username');
        if(isset($_POST['profileFname'])){
            $config['upload_path']    = './profile/';
            $config['allowed_types']  = 'gif|jpg|png|ico';
            $this->load->library('upload', $config);

            $fName=$this->input->post('profileFname');
            $mName=$this->input->post('profileMname');
            $lName=$this->input->post('profileLname');

            $email=$this->input->post('profileEmail');
            $mobile=$this->input->post('profileMobile');
            $bio=$this->input->post('profileBio');


            if ($this->upload->do_upload('profilePhoto')){
                $dataa =  $this->upload->data('file_name');
                $dataProfile=array(
                    'fname'=>$fName,
                    'mname'=>$mName,
                    'lname'=>$lName,
                    'mobile'=>$mobile,
                    'email'=>$email,
                    'profile'=>$dataa,
                    'biography'=>$bio
                ); 
            }
            else{
                $dataProfile=array(
                    'fname'=>$fName,
                    'mname'=>$mName,
                    'lname'=>$lName,
                    'mobile'=>$mobile,
                    'email'=>$email,
                    'biography'=>$bio
                );
            }
            $this->db->where('username',$user);
            $queryUpdate=$this->db->update('users',$dataProfile);
            if($queryUpdate){
                echo'<div class="alert alert-success alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Profile Changed successfully.
                </div></div>';
            }else{
                echo '<div class="alert alert-warning alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Ooops Please try again.
                </div></div>.';
            }
        }
    }
    function changePassword(){
        $user=$this->session->userdata('username');
        if(isset($_POST['oldPassword'])){
            $pass1=$this->input->post('oldPassword');
            $pass2=$this->input->post('newPassword');

            $password=hash('sha256', $pass1);
            $password2=hash('sha256', $pass2);

            $this->load->model('main_model');
            $change_it=$this->main_model->change_password($user,$password);
            if($change_it){
                $this->db->where('username',$user);
                $this->db->set('password', $password2);
                $this->db->set('password2', $password2);
                $this->db->update('users');
                echo'<div class="alert alert-success alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Password Changed successfully.
            </div></div>';
            }
            else{
                echo '<div class="alert alert-warning alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Ooops old password not correct.
            </div></div>.';
            }
        }
    }

}