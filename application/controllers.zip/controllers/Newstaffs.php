<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Newstaffs extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('main_model');
    ob_start();
    $this->load->helper('cookie');
    $userLevel = userLevel();
    if($this->session->userdata('username') == '' || $userLevel!='1'){
      $this->session->set_flashdata("error","Please Login first");
      $this->load->driver('cache');
      delete_cookie('username');
      unset($_SESSION);
      session_destroy();
      $this->cache->clean();
      ob_clean();
      redirect('login/');
    } 
  }
	public function index($page='new-staffs')
	{
    if(!file_exists(APPPATH.'views/home-page/'.$page.'.php')){
      show_404();
    }
    $this->load->model('main_model');
    $user=$this->session->userdata('username');
    if($this->input->post('stuid')){
      $id=$this->input->post('stuid');
      $query=$this->main_model->accept_staffs($id);
      if($query){
        echo 'Staff Accepted';
      }else{
        echo 'Emm Please try again';
      }
    }
    if($this->input->post('decline_stuid')){
      $id=$this->input->post('decline_stuid');
      $query=$this->main_model->decline_staffs($id);
      if($query){
        echo 'Staff Declined';
      }else{
        echo 'Emm Please try again';
      }
    }
    $data['sessionuser']=$this->main_model->fetch_session_user($user);
    $data['schools']=$this->main_model->fetch_school();
    $this->load->view('home-page/'.$page,$data);
	} 

}