<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Authenticationpage extends CI_Controller {
    public function index()
    {
        $in = $this->session->flashdata('in');
        if($in==1){
            $user=$this->session->userdata('username');
            $mobile=$this->session->userdata('mobile');
            $data['mobile']=$mobile;
            $this->load->model('main_model');
            $id=$this->input->post('readmore');
            $data['blogs']=$this->main_model->fetch_blogs();
            $data['social_pages']=$this->main_model->fetch_social_pages();
            $data['schools']=$this->main_model->fetch_school();
            $this->load->view('authenticationpage',$data);
        }
        else{
            redirect('loginpage/','refresh');
        }
    } 

}