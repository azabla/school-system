<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subject extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('main_model');
    ob_start();
    $this->load->helper('cookie');
    $userLevel = userLevel();
    $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='Subject' order by id ASC "); 
    if($this->session->userdata('username') == '' || $usergroupPermission->num_rows()<1 || $userLevel!='1'){
      $this->session->set_flashdata("error","Please Login first");
      $this->load->driver('cache');
      delete_cookie('username');
      unset($_SESSION);
      session_destroy();
      $this->cache->clean();
      ob_clean();
      redirect('login/');
    }   
  }
	public function index($page='subject')
	{
    if(!file_exists(APPPATH.'views/home-page/'.$page.'.php')){
      show_404();
    }
    $user=$this->session->userdata('username');
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    
    $data['sessionuser']=$this->main_model->fetch_session_user($user);
    $data['academicyear']=$this->main_model->academic_year_filter();
    $data['schools']=$this->main_model->fetch_school();
    $data['grade']=$this->main_model->fetch_grade($max_year);
    $data['subjects']=$this->main_model->fetch_all_subject($max_year);
    $data['subj4merged']=$this->main_model->fetchAllSubject4Forged($max_year);
    $data['grades_subject']=$this->main_model->fetch_subject_grades($max_year);
    $this->load->view('home-page/'.$page,$data);
	}
  function saveNewSubject(){
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['subjectName'])){
      if(!empty($this->input->post('subjectName'))){
        $subjectName=$this->input->post('subjectName');
        $subjectLetter=$this->input->post('subjectLetter');
        $subjectGrade=$this->input->post('subjectGrade');
        $onReportCard=1;
        $date_created=date('M-d-Y');
        for($i=0;$i<count($subjectGrade);$i++){
          $check=$subjectGrade[$i];
          $letteri=$subjectLetter[$i];
          $data=array(
              'Subj_name'=>$subjectName,
              'Merged_percent'=>'100',
              'Grade'=>$check,
              'letter'=>$letteri,
              'date_created'=>$date_created,
              'Academic_Year'=>$max_year,
              'onreportcard'=>$onReportCard
            );
          $this->main_model->add_subject($subjectName,$check,$max_year,$data);
        }
      }
    }
  } 
  function fetchSubject(){
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    echo $this->main_model->fetchAllSubjets($max_year);
  }
  function fetchSubjectToEdit(){
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['edtisub'])){
      $edtisub=$this->input->post('edtisub');
      echo $this->main_model->edit_subject($edtisub,$max_year);
    }
  }
  function updateSubjectName(){
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['oldsubjName'])){
      $date_created=date('M-d-Y');
      $oldsubjName=$this->input->post('oldsubjName');
      $newsubjName=$this->input->post('newsubjName');
      $data=array(
        'Subj_name'=>$newsubjName
      );
      $query=$this->main_model->update_subject($oldsubjName,$data,$max_year,$newsubjName);
      if($query){
        $this->db->where('subject',$oldsubjName);
        $this->db->where('academicyear',$max_year);
        $this->db->set('subject',$newsubjName);
        $this->db->update('staffplacement');
      }
    }
  }
  function updateEachSubjectPercentage(){
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('mname')){
      $date_created=date('M-d-Y');
      $mname=$this->input->post('mname');
      $grade=$this->input->post('grade');
      $valuee=$this->input->post('valuee');
      $this->db->where('Academic_Year',$max_year);
      $this->db->where('Subj_name',$mname);
      $this->db->where('Grade',$grade);
      $this->db->set('Merged_percent',$valuee);
      $query=$this->db->update('subject');
      if($query){
        echo '<span class="text-info">Saved</span>';
      }else{
        echo '<span class="text-danger">Not Saved</span>';
      }
    }
  }
  function updateSubjectForLetter(){
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['gradejoss'])){
      $gradejoss=$this->input->post('gradejoss');
      $letterjoss=$this->input->post('letterjoss');
      $subjjoss=$this->input->post('subjjoss');
      $this->db->where('Grade',$gradejoss);
      $this->db->where('Subj_name',$subjjoss);
      $this->db->where('Academic_Year',$max_year);
      $this->db->set('letter',$letterjoss);
      $query=$this->db->update('subject');
      if($query){
        /*$queryUsers=$this->db->query("select gradesec from users where academicyear='$max_year' and grade='$gradejoss' and usertype='Student' group by gradesec ");
        if($queryUsers->num_rows()>0){
          foreach($queryUsers->result() as $gradeSec ){
              $gradesec=$gradeSec->gradesec;
              $this->db->where('academicyear',$max_year);
              $this->db->where('subject',$subjjoss);
              $this->db->where('grade',$gradesec);
              $this->db->set('letter',$letterjoss);
              $queryUpdate=$this->db->update('reportcard'.$gradesec.$max_year);
          }
        }*/
        echo '<span class="text-info">Saved</span>';
      }else{
        echo 'oops';
      }
    }
  }
  function subjectDelete(){
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['post_id'])){
      $subjname=$this->input->post('post_id');
      $this->db->where('Subj_name',$subjname);
      $this->db->where('Academic_Year',$max_year);
      $this->db->group_by('Grade');
      $queryFetchMark=$this->db->get('subject');
      if($queryFetchMark->num_rows()>0){
        foreach($queryFetchMark->result() as $gradenames){
          $gradename=$gradenames->Grade;
          $queryBranch=$this->db->query("select name from branch where academicyear='$max_year' group by name ");
          if($queryBranch->num_rows()>0){
            foreach($queryBranch->result() as $branchName){
              $branch=$branchName->name;
              $queryUsers=$this->db->query("select gradesec from users where academicyear='$max_year' and usertype='Student' and grade='$gradename' and branch='$branch' group by gradesec ");
              if($queryUsers->num_rows()>0){
                foreach($queryUsers->result() as $gradesecName){
                  $gradesec=$gradesecName->gradesec;
                  $queryTerm=$this->db->query("select term from quarter where Academic_year='$max_year' group by term ");
                  if($queryTerm->num_rows()>0){
                    foreach($queryTerm->result() as $termName){
                      $max_quarter=$termName->term;
                      $queryCheckMark = $this->db->query("SHOW TABLES LIKE 'mark".$branch.$gradesec.$max_quarter.$max_year."' ");
                      if ($queryCheckMark->num_rows()>0)
                      {
                        $this->db->where('mgrade',$gradesec);
                        $this->db->where('subname',$subjname);
                        $this->db->where('academicyear',$max_year);
                        $queryDeleteMark=$this->db->delete('mark'.$branch.$gradesec.$max_quarter.$max_year);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      $queryDeleteSubject=$this->main_model->delete_subject($subjname,$max_year);
    }
  }
  function onreportcard(){
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['onreportcard'])){
      $onreportcard=$this->input->post('onreportcard');
      $subject=$this->input->post('subject');
      $grade=$this->input->post('grade');
      $this->db->where('Subj_name',$subject);
      $this->db->where('Grade',$grade);
      $this->db->where('Academic_Year',$max_year);
      $this->db->set('onreportcard',$onreportcard);
      $query=$this->db->update('subject');
      if($query){
        echo '<span class="text-info">Saved </span>';
      }else{
        echo 'oops';
      }
    }
  }
  function deleteOneSubject(){
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['gradename'])){
      $gradename=$this->input->post('gradename');
      $subjname=$this->input->post('subjname');
      $this->db->where('Grade',$gradename);
      $this->db->where('Subj_name',$subjname);
      $this->db->where('Academic_Year',$max_year);
      $query=$this->db->delete('subject');
      if($query){
        $queryBranch=$this->db->query("select name from branch where academicyear='$max_year' group by name ");
        if($queryBranch->num_rows()>0){
          foreach($queryBranch->result() as $branchName){
            $branch=$branchName->name;
            $queryUsers=$this->db->query("select gradesec from users where academicyear='$max_year' and usertype='Student' and grade='$gradename' and branch='$branch' group by gradesec ");
            if($queryUsers->num_rows()>0){
              foreach($queryUsers->result() as $gradesecName){
                $gradesec=$gradesecName->gradesec;
                $queryTerm=$this->db->query("select term from quarter where Academic_year='$max_year' group by term ");
                if($queryTerm->num_rows()>0){
                  foreach($queryTerm->result() as $termName){
                    $max_quarter=$termName->term;
                    $queryCheckMark = $this->db->query("SHOW TABLES LIKE 'mark".$branch.$gradesec.$max_quarter.$max_year."' ");
                    if ($queryCheckMark->num_rows()>0)
                    {
                      $this->db->where('mgrade',$gradesec);
                      $this->db->where('subname',$subjname);
                      $this->db->where('academicyear',$max_year);
                      $queryDeleteMark=$this->db->delete('mark'.$branch.$gradesec.$max_quarter.$max_year);
                    }
                  }
                }
              }
            }
          }
        }
      }else{
        echo 'oops';
      }
    }
  }
  function removeMergedSubject(){
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['removesub'])){
      $removesub=$this->input->post('removesub');
      $removesub2=$this->input->post('removesub2');
      $this->db->where('Grade',$removesub);
      $this->db->where('Merged_name',$removesub2);
      $this->db->where('Academic_Year',$max_year);
      $this->db->set('Merged_name','');
      $this->db->set('Merged_percent','100');
      $this->db->set('onreportcard','1');
      $query=$this->db->update('subject');
      if($query){
        echo '<span class="text-success">Removed</span>';
      }else{
        echo 'oops, please try again';
      }
    }
  }
  function FetchMergedSubject(){
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    echo $this->main_model->fetch_merged_subject_grades($max_year);
  }
  function UpdateMergedSubjectvalue(){
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['grade'])){
      $grade=$this->input->post('grade');
      $valuee=$this->input->post('valuee');
      $subjdd=$this->input->post('subjdd');
      $mname=$this->input->post('mname');
      $this->db->where('Subj_name',$subjdd);
      $this->db->where('Grade',$grade);
      $this->db->where('Academic_year',$max_year);
      $this->db->set('Merged_name',$mname);
      $this->db->set('Merged_percent',$valuee);
      $query=$this->db->update('subject');
      if($query){
        echo '<span class="text-success">Saved</span>';
      }else{
        echo 'oops, please try again';
      }
    }
  }

}