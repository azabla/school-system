<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Addstudentresult extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('teacher_model');
    ob_start();
    $this->load->helper('cookie');
    $userLevel = userLevel();
    $uaddMark=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='addstudentmark' order by id ASC "); 
    if($this->session->userdata('username') == '' || $uaddMark->num_rows()<1 || $userLevel!='2'){
      $this->session->set_flashdata("error","Please Login first");
      $this->load->driver('cache');
      delete_cookie('username');
      unset($_SESSION);
      session_destroy();
      $this->cache->clean();
      ob_clean();
      redirect('login/');
    } 
  }
	public function index($page='addexam')
	{
    if(!file_exists(APPPATH.'views/teacher/'.$page.'.php')){
      show_404();
    }
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch=$row_branch->branch;
    $approvedID=$row_branch->id;
    $status2=$row_branch->status2;
    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;
    $querychk=$this->db->query("select * from dmarkstatus where academicyear='$max_year' and dname='$status2' and dquarter='$max_quarter' ");
    $data['markstatus']=$querychk;
    $querySummerCheck=$this->db->query("select * from startsummerclass where academicyear='$max_year' and classname='summerClass' ");
    $data['summerClassMark']=$querySummerCheck;
    
    $data['checkAutoLock']=$this->teacher_model->checkAutoMarkLock($max_year,$max_quarter);
    $data['fetch_term']=$this->teacher_model->fetch_term_4teacheer($max_year);
    $data['fetch_evaluation']=$this->teacher_model->fetch_evaluation_fornewexam($max_year);
    $data['sessionuser']=$this->teacher_model->fetch_session_user($user);
    $data['academicyear']=$this->teacher_model->academic_year_filter();
    $data['fetch_grade_fromsp_toadd_neweaxm']=$this->teacher_model->fetch_grade_from_staffplace($user,$max_year);
    $data['schools']=$this->teacher_model->fetch_school();
    $this->load->view('teacher/'.$page,$data);
	} 
  function FilterAssesmentQuarterChange(){
    $user=$this->session->userdata('username');
    $usertype=$this->session->userdata('usertype');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch=$row_branch->branch;
    if($this->input->post('evaluation')){
      $gradesec=$this->input->post('gradesec');
      $evaluation=$this->input->post('evaluation');
      $quarter=$this->input->post('quarter');
      $subject=$this->input->post('subject');
      $queyEval=$this->db->query("select evname from evaluation where eid ='$evaluation' ");
      $evaRow=$queyEval->row();
      $evaName=$evaRow->evname;
      echo $this->teacher_model->FilterAssesmentQuarterChange($evaName,$gradesec,$max_year,$branch,$quarter,$subject); 
    } 
  }
  function studentResultForm(){
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch=$row_branch->branch;
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('gradesec')){
      $academicyear=$this->input->post('academicyear');
      $gradesec=$this->input->post('gradesec');
      $subject=$this->input->post('subject');
      $evaluation=$this->input->post('evaluation');
      $quarter=$this->input->post('quarter');
      $assesname=$this->input->post('assesname');
      $percentage=$this->input->post('percentage');
      echo $this->teacher_model->fetch_thisgrade_students_fornewexam($academicyear,$gradesec,$subject,$evaluation,$quarter,$assesname,$percentage,$branch,$max_year);
    }
  }
  function addNewresult(){
    $user=$this->session->userdata('username');
    $query=$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $query_branch=$this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch_me=$row_branch->branch;
    if($this->input->post('stuid')){
      $stuid=$this->input->post('stuid');
      $resultvalue=$this->input->post('resultvalue');
      $academicyear=$this->input->post('academicyear');
      $subject=$this->input->post('subject');
      $evaluation=$this->input->post('evaluation');
      $quarter=$this->input->post('quarter');
      $assesname=$this->input->post('assesname');
      $percentage=$this->input->post('percentage');
      $markGradeSec=$this->input->post('markGradeSec');
      $queryChk=$this->teacher_model->save_thisgrade_exam($academicyear,$subject,$quarter,$assesname,$markGradeSec,$branch_me);
      if($queryChk){
        for ($i=0; $i < count($stuid); $i++) { 
          $id=$stuid[$i];
          $markvalue=$resultvalue[$i];
          if($percentage>=$markvalue && $markvalue>=0 && $markvalue!=''){
            $data[]=array(
              'stuid'=>$id,
              'academicyear'=>$academicyear,
              'markname'=>$assesname,
              'subname'=>$subject,
              'evaid'=>$evaluation,
              'quarter'=>$quarter,
              'outof'=>$percentage,
              'value'=>$markvalue,
              'mgrade'=>$markGradeSec,
              'mbranch'=>$branch_me,
              'approved'=>'0'
            );
          }
        }
        $query=$this->db->insert_batch('mark'.$branch_me.$markGradeSec.$quarter.$academicyear,$data);
        if($query){
          echo '<div class="alert alert-success alert-dismissible show fade">
              <div class="alert-body">
                  <button class="close"  data-dismiss="alert">
                      <span>&times;</span>
                  </button>
              <i class="fas fa-exclamation-circle"> </i> Result Submitted successfully.
          </div></div>';
        }else{
          echo '<div class="alert alert-warning alert-dismissible show fade">
              <div class="alert-body">
                  <button class="close"  data-dismiss="alert">
                      <span>&times;</span>
                  </button>
              <i class="fas fa-exclamation-circle"> </i> Please Try Again.
          </div></div>';
        }
      }else{
        echo '<div class="alert alert-warning alert-dismissible show fade">
        <div class="alert-body">
            <button class="close"  data-dismiss="alert">
                <span>&times;</span>
            </button>
        <i class="fas fa-exclamation-circle"> </i> Mark already exists.
        </div></div>';
      }
    }
  }
}