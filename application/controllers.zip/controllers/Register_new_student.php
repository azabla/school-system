<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register_new_student extends CI_Controller {
    public function __construct()
    {
      parent::__construct();
      if($this->session->userdata('username') == ''){
          $this->session->set_flashdata("error","Please Login first");
          redirect('login/');
      }  
    }
	public function index()
	{
    $this->load->model('main_model');
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch=$row_branch->branch;
    $usertype=$this->session->userdata('usertype');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('fname')){
      $fathermobile=$this->input->post('fathermobile');
      $fname=$this->input->post('fname');
      $lname=$this->input->post('lname');
      $gfname=$this->input->post('gfname');
      $gender=$this->input->post('gender');
      $usertype=$this->input->post('usertype');
      $mobile=$this->input->post('mobile');
      $email=$this->input->post('email');
      $grade=$this->input->post('grade');
      $sec=$this->input->post('sec');
      $dob=$this->input->post('dob');
      $city=$this->input->post('city');
      $subcity=$this->input->post('subcity');
      $woreda=$this->input->post('woreda');
      $password=$this->input->post('password');
      $password2=$this->input->post('password2');
      $branch=$this->input->post('branch');
      $stuid=$this->input->post('stuid');
      $academicyear=$this->input->post('academicyear');
      $username=$this->input->post('stuid');
      $data=array(
        'father_mobile'=>$fathermobile,
        'username'=>$stuid,
        'usertype'=>$usertype,
        'fname'=>$fname,
        'mname'=>$lname,
        'lname'=>$gfname,
        'mobile'=>$mobile,
        'email'=>$email,
        'grade'=>$grade,
        'section'=>$sec,
        'gradesec'=>$grade.$sec,
        'dob'=>$dob,
        'gender'=>$gender,
        'password'=>md5($password),
        'password2'=>md5($password2),
        'city'=>$city,
        'sub_city'=>$subcity,
        'woreda'=>$woreda,
        'isapproved'=>'1',
        'dateregister'=>date('M-d-Y'),
        'branch'=>$branch,
        'unique_id'=>$stuid,
        'academicyear'=>$academicyear,
        'status'=>'Active'
      );
      $query=$this->main_model->register_new_student($data,$username,$stuid);
      if($query){
        echo '<span class="text-success">Saved successfully</span>';
      }else{
        echo '<span class="text-danger">Student ID already exists</span>';
      }
    }  
	}   
}