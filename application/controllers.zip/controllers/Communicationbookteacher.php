<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Communicationbookteacher extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('teacher_model');
    ob_start();
    $this->load->helper('cookie');
    $userLevel = userLevel();
    $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='communicationbook' order by id ASC "); 
    if($this->session->userdata('username') == '' || $usergroupPermission->num_rows()<1 || $userLevel!='2'){
          $this->session->set_flashdata("error","Please Login first");
        $this->load->driver('cache');
        delete_cookie('username');
        unset($_SESSION);
        session_destroy();
        $this->cache->clean();
        ob_clean();
        redirect('login/');
    }   
  }
	public function index($page='communicationbook')
	{
    if(!file_exists(APPPATH.'views/teacher/'.$page.'.php')){
      show_404();
    }
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch_teacher=$row_branch->branch;
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $today=date('y-m-d');
    $data['fetch_term']=$this->teacher_model->fetch_term_4teacheer($max_year);
    $data['sessionuser']=$this->teacher_model->fetch_session_user($user);
    $data['academicyear']=$this->teacher_model->academic_year_filter();
    if($_SESSION['usertype']===trim('Director')){
      $data['gradesec']=$this->teacher_model->fetch_grade_from_staffplace($user,$max_year);
    }else{
      $data['gradesecTeacher']=$this->teacher_model->fetch_session_gradesec($user,$max_year);
    }
    $data['schools']=$this->teacher_model->fetch_school();
    $this->load->view('teacher/'.$page,$data);
	}
  function fetchSubjectforMarkView(){
    $user=$this->session->userdata('username');
      $usertype=$this->session->userdata('usertype');
      $query = $this->db->query("select max(year_name) as year from academicyear");
      $row = $query->row();
      $max_year=$row->year;
      if($this->input->post('gradesec')){
      $gradesec=$this->input->post('gradesec');
      if($_SESSION['usertype']===trim('Director')){
        echo $this->teacher_model->fetch_subject_from_subjectmark($gradesec,$max_year); 
      }else{
        echo $this->teacher_model->fetch_subject_from_staffplace($gradesec,$max_year,$user);
      }
    }
  }
  function fetchUsertype(){
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch_teacher=$row_branch->branch;
    if(isset($_POST['grade'])){
      $grade=$this->input->post('grade');
      echo $this->teacher_model->fetchThisGradeStudents($grade,$branch_teacher); 
    }
  }
  function saveCommunicationBook(){
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch_teacher=$row_branch->branch;

    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;

    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;

    if(isset($_POST['comGradesec'])){
      if(!empty($this->input->post('comGradesec'))){
        $comGradesec=$this->input->post('comGradesec');
        $comSubject=$this->input->post('comSubject');
        $comNote=$this->input->post('comNote');
        $stuName=$this->input->post('stuName');
        for($i=0;$i<count($stuName);$i++){
          $check=$stuName[$i];
          $data[]=array(
            'comgrade'=>$comGradesec,
            'combranch'=>$branch_teacher,
            'stuid'=>$check,
            'comsubject'=>$comSubject,
            'comnote'=>$comNote,
            'datecreated'=>date('M-d-Y'),
            'quarter'=>$max_quarter,
            'academicyear'=>$max_year,
            'byteacher'=>$user
          );
        }
        $query=$this->db->insert_batch('communicationbook',$data);
        if($query){
          echo '<div class="alert alert-success alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i>Communication note sent successfully.
            </div></div>';
        }else{
          echo '<div class="alert alert-warning alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i>Please try again.
            </div></div>';
        }
      }
    }
  }
  function fetchCommunicationBookTeacher(){
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch_teacher=$row_branch->branch;
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;

    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;
    echo $this->teacher_model->fetchCommunicationBookTeacher($user,$branch_teacher,$max_year,$max_quarter); 
  }
  function fetchCommBookToapprove(){
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch_teacher=$row_branch->branch;
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;

    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;
    if($_SESSION['usertype']===trim('Director')){
      echo $this->teacher_model->fetchCommBookToapprove($user,$branch_teacher,$max_year,$max_quarter); 
    }
  }
  function approveCommunicationBook(){
    if($this->input->post('stuID')){
      $stuID=$this->input->post('stuID');
      $this->db->set('approvecom','1');
      $this->db->where('id',$stuID);
      $this->db->update('communicationbook');
    }
  }
  function rejectCommunicationBook(){
    if($this->input->post('stuID')){
      $stuID=$this->input->post('stuID');
      $this->db->where('id',$stuID);
      $this->db->delete('communicationbook');
    }
  }
  function viewComBookId(){
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('viewlessonplan')){
      $lessonID=$this->input->post('viewlessonplan');
      echo $this->teacher_model->viewComBookId($lessonID,$max_year);
    }
  }
  function commentedTeacher(){
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('lessonID')){
      $lessonID=$this->input->post('lessonID');
      echo $this->teacher_model->commentedTeacher($lessonID,$max_year);
    }
  }
  function saveCommunicationBookComment(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('commentText')){
      $comment=$this->input->post('commentText');
      $lessonID=$this->input->post('lessonID');
      $queryTeacher=$this->db->query("select * from communicationbook where id='$lessonID' ");
      $data=array();
      foreach($queryTeacher->result() as $teacherInfo){
        $byteacher=$teacherInfo->byteacher;
        $stuid=$teacherInfo->stuid;
        $subject=$teacherInfo->comsubject;
        $data=array(
          'comstuid'=>$stuid,
          'comid'=>$lessonID,
          'comcomment'=>$comment,
          'commentby'=>$user,
          'commento'=>$byteacher,
          'commentedsubject'=>$subject,
          'datecommented'=>date('M-d-Y')
        );
      }
      $query=$this->db->insert('commbookcomment',$data);
      if($query){
        $this->db->where('id',$lessonID);
        $this->db->set('comcommented','1');
        $queryCommented=$this->db->update('communicationbook');
        if($queryCommented){
          echo '<div class="alert alert-success alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Comment Sent Successfully.
            </div></div>';
          }else{
            echo '<div class="alert alert-warning alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Pleas try again.
            </div></div>';
          }
      }else{
        echo '<div class="alert alert-warning alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Pleas try again.
        </div></div>';
      }
    }
  }
  function unseenComBook(){
    $user=$this->session->userdata('username');
    $usertype=$this->session->userdata('usertype');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch_teacher=$row_branch->branch;
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;

    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;

    if($usertype==trim('Director')){
      if(isset($_POST['view'])){
        if($_POST['view']!=''){
          /*$query=$this->db->query("select * from directorplacement where academicyear='$max_year' and staff='$user'  ");
          foreach($query->result() as $updateComBook){
            $grade=$updateComBook->grade;
            $this->db->where('comgrade',$grade);
            $this->db->where('combranch',$branch_teacher);
            $this->db->where('academicyear',$max_year);
            $this->db->where('quarter',$max_quarter);
            $this->db->set('approvecom','1');
            $this->db->update('communicationbook');
          }*/
        }
        $tot=$this->teacher_model->fetch_unseen_comBook_notification($user,$branch_teacher,$max_year,$max_quarter);
        $result['unseen_notification']=$tot;
        echo json_encode($result);
      }
    }
  }
  function unseenreplyComBbok(){
    $user=$this->session->userdata('username');
    $usertype=$this->session->userdata('usertype');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch_teacher=$row_branch->branch;
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;

    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;

    if(isset($_POST['view'])){
      if($_POST['view']!=''){
        $sql = " UPDATE combookreplaystudent p INNER JOIN communicationbook f  ON  p.replyid = f.id SET p.seenstatus ='1' WHERE f.academicyear = $max_year and f.quarter='$max_quarter' and p.seenstatus='0' and f.byteacher='$user' ";
        $this->db->query($sql);
      }
      $tot=$this->teacher_model->unseenreplyComBbok($user,$branch_teacher,$max_year,$max_quarter);
      $result['unseen_notification']=$tot;
      echo json_encode($result);
    }
    
  }
  function returnedComBook(){
    $user=$this->session->userdata('username');
    $usertype=$this->session->userdata('usertype');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch_teacher=$row_branch->branch;
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;

    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;

    if(isset($_POST['view'])){
      $tot=$this->teacher_model->fetchreturnedComBook($user,$branch_teacher,$max_year,$max_quarter);
      $result['unseen_notification']=$tot;
      echo json_encode($result);
    }
  }
  function fetchReturnedCommunicationBook(){
    $user=$this->session->userdata('username');
    $usertype=$this->session->userdata('usertype');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch_teacher=$row_branch->branch;
    $query =$this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    echo $this->teacher_model->fetchReturnedCommunicationBook($user,$max_year);
  }
  function editReturnedCommmbookDetail(){
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('comId')){
      $comId=$this->input->post('comId');
      echo $this->teacher_model->editReturnedCommmbookDetail($comId,$max_year);
    }
  }
  function saveReturnedCommmbookDetail(){
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('comId')){
      $comId=$this->input->post('comId');
      $comNote=$this->input->post('comNote');
      $this->db->set('comnote',$comNote);
      $this->db->where('id',$comId);
      $query=$this->db->update('communicationbook');
      if($query){
        echo '<div class="alert alert-success alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Updated successfully.
        </div></div>';
      }else{
        echo '<div class="alert alert-warning alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Pleas try again.
        </div></div>';
      }
    }
  }
  function viewReturnedComBook(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('comId')){
      $comId=$this->input->post('comId');
      echo $this->teacher_model->viewReturnedComBook($user,$comId,$max_year);
    }
  }
  function fetchCustomText(){
    echo $this->teacher_model->fetchCustomText();
  }
  function postCustomText(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('customTextName')){
      $customTextName=$this->input->post('customTextName');
      $data=array(
        'comtext'=>$customTextName,
        'academicyear'=>$max_year,
        'datecreated'=>date('M-d-Y'),
        'createdby'=>$user
      );
      $queryInsert= $this->db->insert('customcomtext',$data);
      if($queryInsert){
        echo '<div class="alert alert-success alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Text saved successfully.
            </div></div>';
      }else{
        echo '<div class="alert alert-warning alert-dismissible show fade">
                <div class="alert-body">
                    <button class="close"  data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                <i class="fas fa-check-circle"> </i> Ooops Please try again.
            </div></div>';
      }
    }
  }
  function deleteCustomText(){
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['textId'])){
      $id=$this->input->post('textId');
      $this->db->where('id',$id);
      $query=$this->db->delete('customcomtext');
    }
  }
  function fetchCustomTextTosend(){
    echo $this->teacher_model->fetchCustomTextTosend();
  }
}