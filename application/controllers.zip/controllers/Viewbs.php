<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Viewbs extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('main_model');
    ob_start();
    $this->load->helper('cookie');
    $userLevel = userLevel();
    $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='studentbasicskill' order by id ASC ");
    if($this->session->userdata('username') == '' || $usergroupPermission->num_rows()<1 || $userLevel!='2'){
      $this->session->set_flashdata("error","Please Login first");
      $this->load->driver('cache');
      delete_cookie('username');
      unset($_SESSION);
      session_destroy();
      $this->cache->clean();
      ob_clean();
      redirect('login/');
    } 
  }
	public function index($page='viewbs')
	{
    if(!file_exists(APPPATH.'views/teacher/'.$page.'.php'))
    {
        show_404();
    }
    $this->load->model('main_model');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $branch=$row_branch->branch;
    if($_SESSION['usertype']===trim('Director')){
      $data['gradesec']=$this->main_model->fetch_mygradesec2($user,$max_year,$branch);
    }else{
      $data['gradesecs']=$this->main_model->fetcHrGradesec($max_year,$user,$branch);
    }
    
    $data['fetch_term']=$this->main_model->fetch_term($max_year);
    $data['sessionuser']=$this->main_model->fetch_session_user($user);
    $data['academicyear']=$this->main_model->academic_year_filter();
    $data['grade']=$this->main_model->fetch_grade($max_year);
    $data['schools']=$this->main_model->fetch_school();
    $data['branch']=$this->main_model->fetch_branch($max_year);
    $this->load->view('teacher/'.$page,$data);
	}
  function fecthStudentBs(){
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $mybranch=$row_branch->branch;
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('gradesec')){
      $gradesec=$this->input->post('gradesec');
      $quarter=$this->input->post('quarter');
      $fetchData=$this->main_model->fecthStudentBs($mybranch,$gradesec,$quarter,$max_year);
        echo json_encode($fetchData);
    }
  }
  function updateStudentBs(){
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $mybranch=$row_branch->branch;
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('bsname')){
      $bsname=$this->input->post('bsname');
      $value=$this->input->post('value');
      $stuid=$this->input->post('stuid');
      $quarter=$this->input->post('quarter');
      $bsGradesec=$this->input->post('bsGradesec');
      $data=array(
        'stuid'=>$stuid,
        'bsname'=>$bsname,
        'value'=>$value,
        'quarter'=>$quarter,
        'academicyear'=>$max_year,
        'datecreated'=>date('M-d-Y'),
        'byuser'=>$user,
        'bsgrade'=>$bsGradesec,
        'bsbranch'=>$mybranch
      );
      echo $this->main_model->updateStudentBs($bsGradesec,$stuid,$quarter,$bsname,$max_year,$value,$data);
    }
  }
  function fetch_user(){
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $mybranch=$row_branch->branch;
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('gradesec')){
      $gradesec=$this->input->post('gradesec');
      $quarter=$this->input->post('quarter');
      $fetch_data = $this->main_model->fetch_bs($mybranch,$gradesec,$quarter,$max_year);
      $data = array();
      foreach($fetch_data as $row)  
           {  
                $sub_array = array();  
                $sub_array[] = '<img src="'.base_url().'profile/'.$row->profile.'" class="img-thumbnail" width="50" height="35" />';  
                $sub_array[] = $row->fname;  
                $sub_array[] = $row->lname;  
                $sub_array[] = '<button type="button" name="update" id="'.$row->id.'" class="btn btn-warning btn-xs">Update</button>';  
                $sub_array[] = '<button type="button" name="delete" id="'.$row->id.'" class="btn btn-danger btn-xs">Delete</button>';  
                $data[] = $sub_array;  
           }  
           $output = array(  
                "draw"  =>intval($_POST["draw"]),  
                "recordsTotal"=>$this->main_model->get_all_data(),  
                "recordsFiltered"=>$this->main_model->get_filtered_data(),  
                "data" =>     $data  
           );  
           echo json_encode($output);
    }        
  }
}