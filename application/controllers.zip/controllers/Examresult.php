<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Examresult extends CI_Controller {
    public function __construct(){
        parent::__construct();
        if($this->session->userdata('username') == ''){
            $this->session->set_flashdata("error","Please Login first");
            redirect('Login/');
        }
    }
	public function index($page='examresult')
	{
        if(!file_exists(APPPATH.'views/home-page/'.$page.'.php'))
        {
            show_404();
        }
        $this->load->model('main_model');
        $user=$this->session->userdata('username');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if(isset($_POST['viewresult'])){
            $examname=$this->input->post('viewresult');
            $subject=$this->input->post('subject');
            $data['examresult']=$this->main_model->view_students_examresult($examname,$subject,$max_year);
            $data['sessionuser']=$this->main_model->fetch_session_user($user);
            $data['academicyear']=$this->main_model->academic_year_filter();
            $data['fetch_gradesec']=$this->main_model->fetch_session_gradesec($user,$max_year);
            $data['schools']=$this->main_model->fetch_school();
            $data['posts']=$this->main_model->fetch_post();
            $this->load->view('home-page/'.$page,$data);
        }
        else{
            redirect('viewexam/','refresh');
        }	    
	} 
}