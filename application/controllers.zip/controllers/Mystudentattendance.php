<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mystudentattendance extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('main_model');
        ob_start();
        $this->load->helper('cookie');
        $userLevel = userLevel();
        $userPerStuAtt=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Attendance' and allowed='studentAttendance' order by id ASC ");  
        if($this->session->userdata('username') == '' || $userPerStuAtt->num_rows()<1 || $userLevel!='2'){
            $this->session->set_flashdata("error","Please Login first");
            $this->load->driver('cache');
            delete_cookie('username');
            unset($_SESSION);
            session_destroy();
            $this->cache->clean();
            ob_clean();
            redirect('login/');
        } 
    }
	public function index($page='mystudentattendance')
	{
        if(!file_exists(APPPATH.'views/teacher/'.$page.'.php')){
            show_404();
        }
        $user=$this->session->userdata('username');
        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        $today=date('y-m-d');
        $data['fetch_today_attendance']=$this->main_model->fetch_mattendance($max_year,$branch);
        $data['sessionuser']=$this->main_model->fetch_session_user($user);
        $data['academicyear']=$this->main_model->academic_year_filter();
        $data['schools']=$this->main_model->fetch_school();
        $data['gradesecs']=$this->main_model->fetcHrGradesec($max_year,$user,$branch);
        $data['gradesec']=$this->main_model->fetch_mygradesec2($user,$max_year,$branch);
        $this->load->view('teacher/'.$page,$data);
	} 
    function filterGradesecForTeachers(){
        $user=$this->session->userdata('username');
        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;
        $usertype=$this->session->userdata('usertype');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if($this->input->post('gradesec')){
            $fetchDate=$this->input->post('fetchDate');
            $gradesec=$this->input->post('gradesec');
            $timestamp=strtotime($fetchDate);
            $newDateEnd=date('d/m/y',$timestamp);
            echo $this->main_model->filterGradesecForTeachers($gradesec,$max_year,$branch,$fetchDate);    
        }
    }
    function feedAbsentAttendance(){
        $user=$this->session->userdata('username');
        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if($this->input->post('attendanceId')){
            $attendanceId=$this->input->post('attendanceId');
            $absentDate=$this->input->post('absentDate');
            $timestamp=strtotime($absentDate);
            $newDateEnd=date('d/m/y',$timestamp);
            $abseType='Absent';
            $this->main_model->feedAbsentAttendance($attendanceId,$absentDate,$abseType,$max_year,$user);
        }
    }
    function lateAttendance(){
        $user=$this->session->userdata('username');
        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if($this->input->post('attendanceId')){
            $attendanceId=$this->input->post('attendanceId');
            $absentDate=$this->input->post('absentDate');
            $teaStuAbsentMin=$this->input->post('teaStuAbsentMin');
            $abseType='Late';
            $timestamp=strtotime($absentDate);
            $newDateEnd=date('d/m/y',$timestamp);
            $this->main_model->feedLateAttendance($attendanceId,$absentDate,$abseType,$max_year,$user,$teaStuAbsentMin);
        }
    }
    function permissionAttendance(){
        $user=$this->session->userdata('username');
        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if($this->input->post('attendanceId')){
            $attendanceId=$this->input->post('attendanceId');
            $absentDate=$this->input->post('absentDate');
            $teaStuAbsentMin=$this->input->post('teaStuAbsentMin');
            $abseType='Permission';
            $timestamp=strtotime($absentDate);
            $newDateEnd=date('d/m/y',$timestamp);
            $this->main_model->feedPermissionAttendance($attendanceId,$absentDate,$abseType,$max_year,$user);
        }
    }
    function fetchStuAttendance(){
        $user=$this->session->userdata('username');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;

        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;
        
        if($_SESSION['usertype']===trim('Director')){
            echo $this->main_model->fetchMyStuAttendanceDirector($max_year,$branch,$user);
        }else{
            $queryHrGrade = $this->db->query("select * from hoomroomplacement where teacher='$user' and academicyear='$max_year' ");
            if($queryHrGrade->num_rows()>0){
                $rowHrGradeBranch = $queryHrGrade->row();
                $HrGrade=$rowHrGradeBranch->roomgrade;
                echo $this->main_model->fetchMyStuAttendance($max_year,$branch,$user); 
            }else{
                echo '<div class="alert alert-warning alert-dismissible show fade">
                    <div class="alert-body">
                        <button class="close"  data-dismiss="alert">
                            <span>&times;</span>
                        </button>
                    <i class="fas fa-check-circle"> </i> You are not home room teacher.
                </div></div>'; 
            }
        }
    }
    function deleteAttendance(){
        if($this->input->post('attendanceId')){
            $staffId=$this->input->post('attendanceId');
            $absentDate=$this->input->post('absentDate');
            $timestamp=strtotime($absentDate);
            $newDateEnd=date('d/m/y',$timestamp);
            echo $this->main_model->delete_attendance($staffId,$absentDate);
        }
    }
    function removeAttendance(){
        if($this->input->post('attendanceId')){
            $staffId=$this->input->post('attendanceId');
            $absentDate=$this->input->post('absentDate');
            $timestamp=strtotime($absentDate);
            $newDateEnd=date('d/m/y',$timestamp);
            echo $this->main_model->delete_attendance($staffId,$absentDate);
        }
    }
    function searchAttendance(){
        $user=$this->session->userdata('username');
        $usertype=$this->session->userdata('usertype');
        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $myBranch=$row_branch->branch;
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if($this->input->post('searchItem')){
            $searchItem=$this->input->post('searchItem');
            echo $this->main_model->searchAttendanceDirector($searchItem,$myBranch,$max_year);
        }
    }
    function attendanceNotification(){
        $user=$this->session->userdata('username');
        $usertype=$this->session->userdata('usertype');

        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $myBranch=$row_branch->branch;
        $usertype=$row_branch->usertype;
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if(isset($_POST['view'])){
            $show=$this->main_model->fetch_allnewAttendanceDirector($myBranch,$max_year,$user);
            $result['notification']=$show;
            $tot=$this->main_model->fetch_unseen_newAttendanceDirector($myBranch,$max_year,$user);
            $result['unseen_notification']=$tot;
            echo json_encode($result);
        }
    }
}