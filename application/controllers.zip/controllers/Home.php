<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('main_model');
    if($this->session->userdata('username') == ''){
      $this->session->set_flashdata("error","Please Login first");
      redirect('Login/');
    }    
  }
	public function index($page='home')
  {
    if(!file_exists(APPPATH.'views/home-page/'.$page.'.php')){
      show_404();
    }
    $this->load->model('main_model');
    $config['upload_path'] = './public_post/';
    $config['allowed_types'] ='png|jpg|jpeg';
    $this->load->library('upload', $config);

    $this->load->helper('date');
    $user=$this->session->userdata('username');
    $usertype=$this->session->userdata('usertype');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $logged_id=$row_branch->id;
    $date_now= date('y-m-d');
    
    $now = new DateTime();
    $now->setTimezone(new DateTimezone('Africa/Addis_Ababa'));
    $datetime= $now->format('Y-m-d H:i:s');
    $userLevel = userLevel();
    if($userLevel=='3' && trim($_SESSION['usertype'])!==''){
      if(isset($_POST['post'])){
        $this->upload->do_upload('postphoto');
        $postphoto= $this->upload->data('file_name');
        $post=$this->input->post('posthere');
        $title=$this->input->post('title');
        //$postby=$this->session->userdata('username');
        $date_post=date('M-d-Y');
        if($postphoto!=='' || $post!==''){
          if($postphoto==''){
            $data=array(
              'title'=>$title,
              'post'=>$post,
              'postby'=>$user,
              'date_post'=>$date_post
            );
          }else{
            $data=array(
              'title'=>$title,
              'photo'=>$postphoto,
              'postby'=>$user,
              'date_post'=>$date_post
            );
          }
          $id=$this->main_model->post_data($data);
          redirect('home','refresh');
        }
        else{
          redirect('home','refresh');
        }
      }
      if(isset($_GET['post_id'])){
        $id=$_GET['post_id'];
        $this->main_model->delete_post($id);
      }
      $data['sessionuser']=$this->main_model->fetch_session_user($user);
      $data['academicyear']=$this->main_model->academic_year_filter();
      $data['schools']=$this->main_model->fetch_school();
      $data['posts']=$this->main_model->fetch_post();
      $this->load->view('student/'.$page,$data);
    }
    else if($userLevel=='2' && trim($_SESSION['usertype'])!==''){
      if(isset($_POST['post'])){
        $this->upload->do_upload('postphoto');
        $postphoto= $this->upload->data('file_name');
        $post=$this->input->post('posthere');
        $title=$this->input->post('title');
        // $postby=$this->session->userdata('username');
        $date_post=date('M-d-Y');
        if($postphoto!=='' || $post!==''){
          if($postphoto==''){
            $data=array(
              'title'=>$title,
              'post'=>$post,
              'postby'=>$user,
              'date_post'=>$date_post
            );
          }else{
            $data=array(
              'title'=>$title,
              'photo'=>$postphoto,
              'postby'=>$user,
              'date_post'=>$date_post
            );
          }
          $id=$this->main_model->post_data($data);
          redirect('home','refresh');
        }
        else{
          redirect('home','refresh');
        }
      }
      if(isset($_GET['post_id'])){
        $id=$_GET['post_id'];
        $this->main_model->delete_post($id);
      }
      $data['sessionuser']=$this->main_model->fetch_session_user($user);
      $data['academicyear']=$this->main_model->academic_year_filter();
      $data['schools']=$this->main_model->fetch_school();
      $data['posts']=$this->main_model->fetch_post();
      $this->load->view('teacher/'.$page,$data);
    }
    else if (trim($_SESSION['usertype'])==='') {
      $this->session->set_flashdata("error",'Your user type is not set. Please contact your system Admin!');
      redirect('loginpage/','refresh');
    }
    else {
      if(isset($_GET['post_id'])){
        $id=$_GET['post_id'];
        $this->main_model->delete_post($id);
      }
      if(isset($_POST['post'])){
        $this->upload->do_upload('postphoto');
        $postphoto= $this->upload->data('file_name');
        $post=$this->input->post('posthere');
        $title=$this->input->post('title');
        //$postby=$this->session->userdata('username');
        $date_post=date('M-d-Y');
        if($postphoto!=='' || $post!==''){
          if($postphoto==''){
            $data=array(
              'title'=>$title,
              'post'=>$post,
              'postby'=>$user,
              'date_post'=>$date_post
            );
          }else{
            $data=array(
              'title'=>$title,
              'photo'=>$postphoto,
              'postby'=>$user,
              'date_post'=>$date_post
            );
          }
          $id=$this->main_model->post_data($data);
          redirect('home','refresh');
        }
        else{
          redirect('home','refresh');
        }
      }
      $data['sessionuser']=$this->main_model->fetch_session_user($user);
      $data['academicyear']=$this->main_model->academic_year_filter();
      $data['schools']=$this->main_model->fetch_school();
      $data['posts']=$this->main_model->fetch_post();
		  $this->load->view('home-page/'.$page,$data);
	  } 
  }
  function save_token()
  {
      $this->main_model->save_token();
  }
  function checkNewUserFound(){
    $user=$this->session->userdata('username');
    $tot=$this->main_model->fetchAllMyNewUserNotification();
    if($tot->num_rows()>0){
      foreach($tot->result() as $myMess){
        $title =$myMess->fname.' '.$myMess->lname;
        $body =$myMess->usertype;
    
        $query = $this->db->query("SELECT distinct token FROM `notification_tokens_tbl` where delete_status='N'");
        $query_res = $query->result();
        
        
        foreach ($query_res as $query_res_data) {
        $registrationIds[] =$query_res_data->token;
        }
        
        $url ="https://fcm.googleapis.com/fcm/send";
        //"to" for single user
        //"registration_ids" for multiple users
        //$title = "$user";
        //$body = "New Message has been found.";
        $BaseUrl=base_url();
        $schools=$this->main_model->fetch_school();
        foreach($schools as $school){
            $icon = ''.$BaseUrl.'logo/'.$school->logo.'';
        }
        $click_action = ''.$BaseUrl.'inbox/';
        $fields=array(
            "registration_ids"=>$registrationIds,
            "notification"=>array(
            "body"=>$body,
            "title"=>$title,
            "icon"=>$icon,
            "click_action"=>$click_action
            )
        );
        //print_r($fields);
        //exit;
        
        $headers=array(
        'Authorization: key=AAAAv9-EmBs:APA91bFLeVp7y35RHreE5Vwxk5mq-cyckoe062CebxPlfdJgYd1Eh_KqU4uRuHCTLOk-NV8gpO7-GBxorqTAgpwN9WexbZR1sZBOvBdLyr2V46OG7-M_NLOuCvWSFW2H1AWlehRpBAGu',
        'Content-Type:application/json'
        );
    
        $ch=curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_POST,true);
        curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($fields));
        $result=curl_exec($ch);
        print_r($result);
        curl_close($ch);
      }
    }
  }
  function sendNotification(){
    $user=$this->session->userdata('username');
    $tot=$this->main_model->fetchAllMyMessages($user);
    if($tot->num_rows()>0){
      foreach($tot->result() as $myMess){
        $title =$myMess->subject;
        $body =$myMess->message;

        $query = $this->db->query("SELECT distinct token FROM `notification_tokens_tbl` where delete_status='N'");
        $query_res = $query->result();
        
        
        foreach ($query_res as $query_res_data) {
        $registrationIds[] =$query_res_data->token;
        }
        
        $url ="https://fcm.googleapis.com/fcm/send";
        //"to" for single user
        //"registration_ids" for multiple users
        //$title = "$user";
        //$body = "New Message has been found.";
        $BaseUrl=base_url();
        $schools=$this->main_model->fetch_school();
        foreach($schools as $school){
            $icon = ''.$BaseUrl.'logo/'.$school->logo.'';
        }
        $click_action = ''.$BaseUrl.'inbox/';
        $fields=array(
          "registration_ids"=>$registrationIds,
          "notification"=>array(
          "body"=>$body,
          "title"=>$title,
          "icon"=>$icon,
          "click_action"=>$click_action
          )
        );
        //print_r($fields);
        //exit;
        
        $headers=array(
        'Authorization: key=AAAAv9-EmBs:APA91bFLeVp7y35RHreE5Vwxk5mq-cyckoe062CebxPlfdJgYd1Eh_KqU4uRuHCTLOk-NV8gpO7-GBxorqTAgpwN9WexbZR1sZBOvBdLyr2V46OG7-M_NLOuCvWSFW2H1AWlehRpBAGu',
        'Content-Type:application/json'
        );
    
        $ch=curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_POST,true);
        curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($fields));
        $result=curl_exec($ch);
        print_r($result);
        curl_close($ch);
      }
    }
  }
  /*function fetch_analysis(){
    $this->load->model('main_model');
    $user=$this->session->userdata('username');
    $usertype=$this->session->userdata('usertype');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $mybranch=$row_branch->branch;

    $queryAccessBranch=$this->db->query("select accessbranch from usegroup where uname='$usertype' ");
    $rowaccessbranch = $queryAccessBranch->row_array();
    $accessbranch=$rowaccessbranch['accessbranch'];
    $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year' ");
    $row2 = $query2->row();
    $max_quarter=$row2->quarter;

    if($_SESSION['usertype']===trim('superAdmin') || $accessbranch === '1'){
      $data1=$this->main_model->fetchTeachersPerformance($max_quarter,$max_year); 
    }else{
      $data1= $this->main_model->fetchTeachersPerformance($mybranch,$max_quarter,$max_year);
    }
      $data2 =array();
      foreach($data1 as $row) {
        $data2[] = array(
          'language'    =>  $row["fname"],
          'total'     =>  $row["mname"],
          'color'     =>  '#' . rand(100000, 999999) . ''
        );
      }
      $variable = array('data1' => $data1);
      echo json_encode($variable);
    
  }*/
}