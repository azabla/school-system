<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Evaluation extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('main_model');
        ob_start();
        $this->load->helper('cookie');
        $userLevel = userLevel();
        $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='Evaluation' order by id ASC "); 
        if($this->session->userdata('username') == '' || $usergroupPermission->num_rows() < 1 || $userLevel!='1'){
            $this->session->set_flashdata("error","Please Login first");
            $this->load->driver('cache');
            delete_cookie('username');
            unset($_SESSION);
            session_destroy();
            $this->cache->clean();
            ob_clean();
            redirect('login/');
        }    
    }
	public function index($page='evaluation')
	{
        if(!file_exists(APPPATH.'views/home-page/'.$page.'.php'))
        {
          show_404();
        }
        
        $user=$this->session->userdata('username');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;

        $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year'");
        $row2 = $query2->row();
        $max_quarter=$row2->quarter;
        $data['grade']=$this->main_model->fetch_grade($max_year);
        $data['posts']=$this->main_model->fetch_term($max_year);
        $data['sessionuser']=$this->main_model->fetch_session_user($user);
        $data['academicyear']=$this->main_model->academic_year_filter();
        $data['schools']=$this->main_model->fetch_school();
        $data['staffs']=$this->main_model->fetch_students($max_year);
        $this->load->view('home-page/'.$page,$data);
	}
    function postEvaluation(){
        $user=$this->session->userdata('username');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
    
        $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year'");
        $row2 = $query2->row();
        $max_quarter=$row2->quarter;
        if(isset($_POST['id'])){
            $id = $this->input->post('id');
            $evname=$this->input->post('evname');
            $percent=$this->input->post('percent');
            foreach ($id as $grade) {
                $query=$this->main_model->add_evaluation($grade,$evname,$max_year,$max_quarter);
                if($query){
                    $data=array(
                        'grade'=>$grade,
                        'evname'=>$evname,
                        'quarter'=>$max_quarter,
                        'academicyear'=>$max_year,
                        'percent'=>$percent,
                        'date_created'=>date('M-d-Y')
                    );
                    $query2=$this->db->insert('evaluation',$data);
                    if($query2){
                        echo 'Saved';
                    }else{
                        echo 'Please try again';
                    }
                }
            }
        }
    }
    function fetchEvaluations(){
        $user=$this->session->userdata('username');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;

        $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year'");
        $row2 = $query2->row();
        $max_quarter=$row2->quarter;
        $queryMin =$this->db->query("select min(term) as quarter from quarter where Academic_Year='$max_year'");
        $rowMin = $queryMin->row();
        $min_quarter=$rowMin->quarter;

        echo $this->main_model->fetch_eval_grade($max_year,$max_quarter,$min_quarter);
    }
    function deleteEvaluation(){
        $user=$this->session->userdata('username');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if(isset($_POST['post_id'])){
            $id=$this->input->post('post_id');
            $quarter=$this->input->post('quarter');
            $evname=$this->input->post('evname');
            $query=$this->main_model->delete_evaluation($id,$quarter,$evname,$max_year);
        }
    }
    function fetchEvaluationsToEdit(){
        $user=$this->session->userdata('username');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if(isset($_POST['post_id'])){
          $id=$this->input->post('post_id');
          $quarter=$this->input->post('quarter');
          $evname=$this->input->post('evname');
          echo $this->main_model->edit_evaluation($id,$quarter,$evname,$max_year);
        }
    }
    function Edit_thisgradevaluation(){
        $user=$this->session->userdata('username');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;

        $query2 = $this->db->query("select max(term) as quarter from quarter where Academic_year='$max_year' ");
        $row2 = $query2->row();
        $max_quarter=$row2->quarter;
        
        if(isset($_POST['percent'])){
            $evname=$this->input->post('evname');
            $new_evname=$this->input->post('new_evname');
            $query=$this->main_model->edit_thisgradevaluation($max_quarter,$evname,$max_year,$new_evname);
            if($query){
                echo '<span class="text-success">Saved</span>';
            }else{
                echo'Oooops, Try again';
            }
        }
    }
    function updateEachEvaluationPercentage(){
        if($this->input->post('evname')){
            $date_created=date('M-d-Y');
            $evname=$this->input->post('evname');
            $grade=$this->input->post('grade');
            $valuee=$this->input->post('value');
            $academicyear=$this->input->post('academicyear');
            $quarter=$this->input->post('quarter');
            $this->db->where('academicyear',$academicyear);
            $this->db->where('evname',$evname);
            $this->db->where('grade',$grade);
            $this->db->where('quarter',$quarter);
            $this->db->set('percent',$valuee);
            $query=$this->db->update('evaluation');
            if($query){
                echo '<span class="text-info">Saved</span>';
            }else{
                echo '<span class="text-danger">Not Saved</span>';
            }
        }
    }
    function movingEvaluations(){
        $user=$this->session->userdata('username');
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;

        $queryCurrent = $this->db->query("select max(term) as quarter from quarter where Academic_Year='$max_year'");
        $rowCurrent = $queryCurrent->row();
        $currentQuarter=$rowCurrent->quarter;

        $query2 = $this->db->query("select max(quarter) as quarter from evaluation where academicyear='$max_year'");
        $row2 = $query2->row();
        $max_quarter=$row2->quarter;

        $queryEva = $this->db->query("select * from evaluation where academicyear='$max_year' and quarter='$max_quarter' ");
        foreach($queryEva->result() as $evaValue){
            $data[]=array(
                'evname'=>$evaValue->evname,
                'quarter'=>$currentQuarter,
                'grade'=>$evaValue->grade,
                'percent'=>$evaValue->percent,
                'academicyear'=>$evaValue->academicyear,
                'date_created'=>date('M-d-Y')
            );
        }
        $query=$this->db->insert_batch('evaluation',$data);
    }
}