<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fetch_post_likes extends CI_Controller {
    public function __construct(){
        parent::__construct();
      if($this->session->userdata('username') == ''){
            $this->session->set_flashdata("error","Please Login first");
            redirect('login/');
        }
        
    }
	public function index()
	{
        $this->load->model('main_model');
        $user=$this->session->userdata('unique_id');
        $usertype=$this->session->userdata('usertype');
        $query_branch = $this->db->query("select * from users where unique_id='$user'");
        $row_branch = $query_branch->row();
        $logged_id=$row_branch->id;
        $date_now= date('y-m-d');

        if(isset($_POST['like_id'])){
            $id=$this->input->post('like_id');
            $data=array(
                'pid'=>$id,
                'bid'=>$logged_id
            );
            $this->main_model->post_like($id,$logged_id,$data);
        }
        $tot=$this->main_model->fetch_post_likes($id);
        $result['countlikes']=$tot;
        echo json_encode($result);
	}    
}