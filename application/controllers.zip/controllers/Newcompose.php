<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Newcompose extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('main_model');
        ob_start();
        $this->load->helper('cookie');
        $userLevel = userLevel();
        if($this->session->userdata('username') == '' || $userLevel!='3'){
            $this->session->set_flashdata("error","Please Login first");
            $this->load->driver('cache');
            delete_cookie('username');
            unset($_SESSION);
            session_destroy();
            $this->cache->clean();
            ob_clean();
            redirect('login/');
        } 
    }
	public function index($page='compose')
	{
        if(!file_exists(APPPATH.'views/student/'.$page.'.php')){
            show_404();
        }
        $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='Chat' order by id ASC "); 
        if($usergroupPermission->num_rows()<1){ 
            redirect('home/');
        }
        $this->load->model('main_model');
        $user=$this->session->userdata('username');
        if(isset($_POST['composemsg'])){
            $usertype=$this->input->post('usertype');
            $touser=$this->input->post('user');
            $username=$this->input->post('username');
            $subject=$this->input->post('subject');
            $message=$this->input->post('message');
            $datetoday=date('M-d-Y');
            for($i=0;$i<count($username);$i++){
                $check=$username[$i];
                $this->main_model->compose_message($usertype,$touser,$user,$check,$subject,$message,$datetoday);
            }
        }
        $data['sessionuser']=$this->main_model->fetch_session_user($user);
        $data['usertype']=$this->main_model->fetch_usertype();
        $data['schools']=$this->main_model->fetch_school();
        $this->load->view('student/'.$page,$data);
	} 
}