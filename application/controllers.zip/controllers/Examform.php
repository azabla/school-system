<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Examform extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('main_model');
    ob_start();
    $this->load->helper('cookie');
    $userLevel = userLevel();
    $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='studentexam' order by id ASC ");
    if($this->session->userdata('username') == '' || $usergroupPermission->num_rows()<1 || $userLevel!='1'){
      $this->session->set_flashdata("error","Please Login first");
      $this->load->driver('cache');
      delete_cookie('username');
      unset($_SESSION);
      session_destroy();
      $this->cache->clean();
      ob_clean();
      redirect('login/');
    } 
  }
	public function index($page='examform')
	{
    if(!file_exists(APPPATH.'views/home-page/'.$page.'.php'))
    {
      show_404();
    }
    $this->load->model('main_model');
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if(isset($_POST['start'])){
      $examname=$this->input->post('examname');
      $grade=$this->input->post('gradesec');
      $subject=$this->input->post('subject');
      if($this->main_model->this_exam_name($examname,$max_year,$grade,$subject)){
        $data['nquestions']=$this->input->post('number');
        $data['subject']=$this->input->post('subject');
        $data['gradesec']=$this->input->post('gradesec');
        $data['examname']=$this->input->post('examname');
        $data['minute']=$this->input->post('minute');

        $data['sessionuser']=$this->main_model->fetch_session_user($user);
        $data['academicyear']=$this->main_model->academic_year_filter();
        $data['fetch_gradesec']=$this->main_model->fetch_session_gradesec($user,$max_year);
        $data['schools']=$this->main_model->fetch_school();
        $data['posts']=$this->main_model->fetch_post();
        $this->load->view('home-page/'.$page,$data);
      }else{
        $this->session->set_flashdata('error','Exam name already exists.Please try again.');
        redirect('exam/');
      }
    }
    else{
      redirect('Exam/','refresh');
    }	    
	} 
}