<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Loginpage extends CI_Controller {
	public function index()
	{
        $this->load->model('main_model');
        if(isset($_COOKIE['username']) && isset($_COOKIE['password'])){
            $user=$this->main_model->can_login($_COOKIE['username'],$_COOKIE['password']);
            if($user){
                $session_data=array(
                    'id'=>$user->id,
                    'usertype'=>$user->usertype,
                    'username'=>$user->username,
                    'fname'=>$user->fname,
                    'mname'=>$user->mname,
                    'lname'=>$user->lname,
                    'mobile'=>$user->mobile,
                    'grade'=>$user->grade,
                    'gender'=>$user->gender,
                    'city'=>$user->city,
                    'email'=>$user->email,
                    'profile'=>$user->profile,
                    'status'=>$user->status,
                    'dob'=>$user->dob,
                    'biography'=>$user->biography,
                    'unique_id'=>$user->unique_id,
                    'status2'=>$user->status2
                );
                $this->load->library('user_agent');
                $data1= $this->agent->browser();
                $data2 = $this->agent->version();
                $data3 = $this->agent->platform();
                $data4 = $this->input->ip_address();
                $query_branch = $this->db->query("select * from users where username='".$_COOKIE['username']."'");
                $row_branch = $query_branch->row();
                $logged_id=$row_branch->id;
                $date_now= date('y-m-d');
                $now = new DateTime();
                $now->setTimezone(new DateTimezone('Africa/Addis_Ababa'));
                $datetime= $now->format('Y-m-d H:i:s');
                $query_log=$this->main_model->Loged_users($logged_id,$date_now,$datetime,$data1,$data2,$data3,$data4);
                $this->session->set_userdata($session_data);
                redirect('home/',"refresh");
            }
        }
        if(isset($_POST['login'])){
            $this->form_validation->set_rules('username','Username','required');
            $this->form_validation->set_rules('password','Password','required');
            $this->load->helper('date');
          	if($this->form_validation->run())
            {
        		$username=$this->security->xss_clean($this->input->post('username'));
        		$password1=$this->security->xss_clean($this->input->post('password'));
                $passwordMd5=md5($password1);
                $passwordSha=hash('sha256', $password1);
                $user=$this->main_model->can_login($username,$passwordMd5);
                $userSha=$this->main_model->can_login($username,$passwordSha);
                if($user){
                    $this->db->where('username',$username);
                    $this->db->where('password',$passwordMd5);
                    $this->db->set('password',$passwordSha);
                    $this->db->set('password2',$passwordSha);
                    $this->db->update('users');
                    if($this->input->post('remember')!=NULL){
                        setcookie('username',$username,time()+(10*365*24*60*60),"/");
                        setcookie('password',$passwordSha,time()+(10*365*24*60*60),"/");
                    }
                    $session_data=array(
                        'id'=>$user->id,
                        'usertype'=>$user->usertype,
                        'username'=>$user->username,
                        'fname'=>$user->fname,
                        'mname'=>$user->mname,
                        'lname'=>$user->lname,
                        'mobile'=>$user->mobile,
                        'grade'=>$user->grade,
                        'gender'=>$user->gender,
                        'city'=>$user->city,
                        'email'=>$user->email,
                        'profile'=>$user->profile,
                        'status'=>$user->status,
                        'dob'=>$user->dob,
                        'biography'=>$user->biography,
                        'unique_id'=>$user->unique_id,
                        'status2'=>$user->status2
                    );
                    $this->load->library('user_agent');
                    $data1= $this->agent->browser();
                    $data2 = $this->agent->version();
                    $data3 = $this->agent->platform();
                    $data4 = $this->input->ip_address();
                    $this->session->set_userdata($session_data);
                    $query_branch = $this->db->query("select * from users where username='$username'");
                    $row_branch = $query_branch->row();
                    $logged_id=$row_branch->id;
                    $date_now= date('y-m-d');
                    $now = new DateTime();
                    $now->setTimezone(new DateTimezone('Africa/Addis_Ababa'));
                    $datetime= $now->format('Y-m-d H:i:s');
                    $query_log=$this->main_model->Loged_users($logged_id,$date_now,$datetime,$data1,$data2,$data3,$data4);
                    redirect('home/');
                }else if($userSha){
                    if($this->input->post('remember')!=NULL){
                        setcookie('username',$username,time()+(10*365*24*60*60),"/");
                        setcookie('password',$passwordSha,time()+(10*365*24*60*60),"/");
                    }
                    $session_data=array(
                        'id'=>$userSha->id,
                        'usertype'=>$userSha->usertype,
                        'username'=>$userSha->username,
                        'fname'=>$userSha->fname,
                        'mname'=>$userSha->mname,
                        'lname'=>$userSha->lname,
                        'mobile'=>$userSha->mobile,
                        'grade'=>$userSha->grade,
                        'gender'=>$userSha->gender,
                        'city'=>$userSha->city,
                        'email'=>$userSha->email,
                        'profile'=>$userSha->profile,
                        'status'=>$userSha->status,
                        'dob'=>$userSha->dob,
                        'biography'=>$userSha->biography,
                        'unique_id'=>$userSha->unique_id,
                        'status2'=>$userSha->status2
                    );
                    $this->load->library('user_agent');
                    $data1= $this->agent->browser();
                    $data2 = $this->agent->version();
                    $data3 = $this->agent->platform();
                    $data4 = $this->input->ip_address();
                    $this->session->set_userdata($session_data);
                    $query_branch = $this->db->query("select * from users where username='$username'");
                    $row_branch = $query_branch->row();
                    $logged_id=$row_branch->id;
                    $date_now= date('y-m-d');
                    $now = new DateTime();
                    $now->setTimezone(new DateTimezone('Africa/Addis_Ababa'));
                    $datetime= $now->format('Y-m-d H:i:s');
                    $query_log=$this->main_model->Loged_users($logged_id,$date_now,$datetime,$data1,$data2,$data3,$data4);
                   /* redirect('authenticationpage/');*/
                    redirect('home/');
                }
                else{
                    $this->session->set_flashdata("error",'Either Invalid username and password or not approved!');
                    redirect("Loginpage/");
                }
          	}
        }
        $this->load->model('main_model');
        $data['blogs']=$this->main_model->fetch_blogs();
        $data['social_pages']=$this->main_model->fetch_social_pages();
        $data['schools']=$this->main_model->fetch_school();
		$this->load->view('signin',$data);
	} 
}