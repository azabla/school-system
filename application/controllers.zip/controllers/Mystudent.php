<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mystudent extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('teacher_model');
        ob_start();
        $this->load->helper('cookie');
        $userLevel = userLevel();
        $uperStuView=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentVE' order by id ASC ");
        if($this->session->userdata('username') == '' || $uperStuView->num_rows()<1 || $userLevel!='2'){
              $this->session->set_flashdata("error","Please Login first");
            $this->load->driver('cache');
            delete_cookie('username');
            unset($_SESSION);
            session_destroy();
            $this->cache->clean();
            ob_clean();
            redirect('login/');
        }
    }
	public function index($page='mystudent')
	{
        if(!file_exists(APPPATH.'views/teacher/'.$page.'.php')){
            show_404();
        }
        $user=$this->session->userdata('username');
        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch_teacher=$row_branch->branch;
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        $today=date('y-m-d');
        $data['fetch_term']=$this->teacher_model->fetch_term_4teacheer($max_year);
        $data['sessionuser']=$this->teacher_model->fetch_session_user($user);
        $data['academicyear']=$this->teacher_model->academic_year_filter();
        if($_SESSION['usertype']===trim('Director')){
          $data['gradesec']=$this->teacher_model->fetch_grade_from_staffplace($user,$max_year);
        }else{
          $data['gradesecTeacher']=$this->teacher_model->fetch_session_gradesec($user,$max_year);
        }
        $data['schools']=$this->teacher_model->fetch_school();
        $this->load->view('teacher/'.$page,$data);
	}
    function downloadStuData(){
        $user=$this->session->userdata('username');
        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        $queryStuddent=$this->db->query("select username,fname,mname,lname,gender,grade, section,father_mobile,mobile,mother_name,dob,age,email,password,city,sub_city,woreda,kebele,dateregister,branch,academicyear from users where usertype='Student' and status='Active' and isapproved='1' and academicyear='$max_year' and branch='$branch' order by fname,mname,lname ASC ");
        
        $filename ='Student-Data.csv';  
        header('Content-Type: testx/csv;charset=utf-8');
        header('Content-Disposition: attachment;filename="'.$filename.'"'); 
        $output=fopen('php://output', 'w');
        fputcsv($output,array('Student ID','First Name','Middle Name','Last Name','Gender','Grade','Section','Father Mobile','Mother Mobile','Mother Name','Date of birth','Age','Email','Password','City','Sub city','Woreda','Kebele','Registration Date','Branch','Academic year'));
        foreach ($queryStuddent->result_array() as $row) {
            fputcsv($output,$row);
        } 
        fclose($output);
    }
    function searchStudent(){
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        $user=$this->session->userdata('username');
        $userType=$this->session->userdata('usertype');
        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;
        if($this->input->post('searchItem')){
            $searchItem=$this->input->post('searchItem');
            echo $this->teacher_model->searchFinanceStudents($searchItem,$branch,$max_year);
        }
    }
    function Fecth_thistudent(){
        $user=$this->session->userdata('username');
        $userType=$this->session->userdata('usertype');
        $query_branch = $this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;

        if($this->input->post('gs_gradesec')){
            $gs_gradesec=$this->input->post('gs_gradesec');    
            echo $this->teacher_model->fetchFinanceBranchStudents($branch,$gs_gradesec,$max_year);
        } 
    }
}
