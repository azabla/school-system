<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Markstatistics extends CI_Controller {
  public function __construct(){
        parent::__construct();
        $this->load->model('main_model');
        ob_start();
        $this->load->helper('cookie');
        $userLevel = userLevel();
        $uperStuDE=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='Statistics' order by id ASC ");  
        if($this->session->userdata('username') == '' || $uperStuDE->num_rows() < 1 || $userLevel!='1'){
            $this->session->set_flashdata("error","Please Login first");
            $this->load->driver('cache');
            delete_cookie('username');
            unset($_SESSION);
            session_destroy();
            $this->cache->clean();
            ob_clean();
            redirect('login/');
        } 
    }
	public function index($page='markstatistics')
	{
    if(!file_exists(APPPATH.'views/home-page/'.$page.'.php')){
      show_404();
    }
    $user=$this->session->userdata('username');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $today=date('y-m-d');
    $data['fetch_term']=$this->main_model->fetch_term($max_year);
    $data['sessionuser']=$this->main_model->fetch_session_user($user);
    $data['academicyear']=$this->main_model->academic_year_filter();
    $data['gradesec']=$this->main_model->fetch_gradesec($max_year);
    $data['branch']=$this->main_model->fetch_branch($max_year);
    $data['schools']=$this->main_model->fetch_school();
    $this->load->view('home-page/'.$page,$data);
	}
  function fetchGradeFromBranch(){
    $user=$this->session->userdata('username');
    $usertype=$this->session->userdata('usertype');
     $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('branch_statistics')){
      $branch=$this->input->post('branch_statistics');
      echo $this->main_model->fetchGradeFromBranch($branch,$max_year); 
    }
  } 
  function fetch_subject_from_gradeFilter(){
    $user=$this->session->userdata('username');
    $usertype=$this->session->userdata('usertype');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    if($this->input->post('gradesec')){
      $grade=$this->input->post('gradesec');
      echo $this->main_model->fetch_subject_from_gradeFilter($grade,$max_year); 
    } 
  }
  function thisMarkStatistics(){
    $user=$this->session->userdata('username');
    $query_branch = $this->db->query("select * from users where username='$user'");
    $row_branch = $query_branch->row();
    $mybranch=$row_branch->branch;
    $usertype=$this->session->userdata('usertype');
    $query = $this->db->query("select max(year_name) as year from academicyear");
    $row = $query->row();
    $max_year=$row->year;
    $countQuarter=0;
    $accessbranch = sessionUseraccessbranch();
    if($this->input->post('grade_statistics')){
      $quarter=$this->input->post('quarterStatistics');
      $grade=$this->input->post('grade_statistics');
      $branch=$this->input->post('branch_statistics');
      $subject=$this->input->post('subStatistics');
      $less_than=$this->input->post('less_than');
      $greater_than=$this->input->post('greater_than');
      $QuarterItems=array();
      foreach($quarter as $quarters){
        $countQuarter=$countQuarter + 1;
        $QuarterItems[] = $quarters;
      }
      if($_SESSION['usertype']===trim('superAdmin') || $accessbranch === '1'){
        foreach($subject as $subjects){
          echo $this->main_model->mark_statistics($max_year,$branch,$grade,$subjects,$QuarterItems,$less_than,$greater_than,$countQuarter);
        }
      }else{
        foreach($subject as $subjects){
          echo $this->main_model->mark_statistics($max_year,$mybranch,$grade,$subjects,$QuarterItems,$less_than,$greater_than,$countQuarter);
        }
      }
    } 
  } 
}