<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Staffs extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('main_model');
        ob_start();
        $this->load->helper('cookie');
        $userLevel = userLevel();
        $userpStaffDe=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='staffDE' order by id ASC "); 
        if($this->session->userdata('username') == '' || $userpStaffDe->num_rows()<1 || $userLevel!='1'){
            $this->session->set_flashdata("error","Please Login first");
            $this->load->driver('cache');
            delete_cookie('username');
            unset($_SESSION);
            session_destroy();
            $this->cache->clean();
            ob_clean();
            redirect('login/');
        } 
    }
	public function index($page='staffs')
	{
        if(!file_exists(APPPATH.'views/home-page/'.$page.'.php')){
            show_404();
        }
        $user=$this->session->userdata('username');
        $query_branch =$this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;
        $data['sessionuser']=$this->main_model->fetch_session_user($user);
        $data['schools']=$this->main_model->fetch_school();
        $this->load->view('home-page/'.$page,$data);
	} 
    function searchStaff(){
        if($this->input->post('searchItem')){
            $searchItem=$this->input->post('searchItem');
            echo $this->main_model->searchStaffs($searchItem);
        }
    }
    function fetchStaffs(){
        $user=$this->session->userdata('username');
        $query_branch =$this->db->query("select * from users where username='$user'");
        $row_branch = $query_branch->row();
        $branch=$row_branch->branch;
        $usertype=$row_branch->usertype;
        $myDivision=$row_branch->status2;
        $accessbranch = sessionUseraccessbranch();
        if($_SESSION['usertype']===trim('superAdmin') || $accessbranch === '1'){
            echo $this->main_model->fetch_staffs();
        }else{
            echo $this->main_model->fetch_mystaffsAdmin($branch,$usertype);
        }
    }
    function editStaff(){
        $user=$this->session->userdata('username');
        $queryUser =$this->db->query("select * from users where username='$user'"); 
        $rowUser = $queryUser->row();
        $usertype=$rowUser->usertype;

        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        if($this->input->post('staff_id')){
            $staffId=$this->input->post('staff_id');
            echo $this->main_model->fetch_staff_toedit($staffId,$max_year,$usertype);
        }
    }
    function updateStaff(){
        $id=$this->input->post('editedStaff');
        $username=$this->input->post('username');
        $unique_id=$this->input->post('username');
        $fname=$this->input->post('fname');
        $mname=$this->input->post('mname');
        $lname=$this->input->post('lname');
        $gender=$this->input->post('gender');
        $mobile=$this->input->post('mobile');
        $gsallary=$this->input->post('gsallary');
        $transport_allowance=$this->input->post('transport_allowance');
        $quality_allowance=$this->input->post('quality_allowance');
        $position_allowance=$this->input->post('position_allowance');
        $home_allowance=$this->input->post('home_allowance');
        $gross_sallary=$this->input->post('gross_sallary');
        $taxable_income=$this->input->post('taxable_income');
        $income_tax=$this->input->post('income_tax');
        $pension_7=$this->input->post('pension_7');
        $pension_11=$this->input->post('pension_11');
        $other=$this->input->post('other');
        $netsallary=$this->input->post('netsallary');
        $email=$this->input->post('email');
        $branch=$this->input->post('branch');
        $usertype=$this->input->post('schoolusertype');
        $userDivision=$this->input->post('userDivision');
        $data=array(
            //'username'=>$username,
            'fname'=>$fname,
            'mname'=>$mname,
            'lname'=>$lname,
            'gsallary'=>$gsallary,
            'allowance'=>$transport_allowance,
            'quality_allowance'=>$quality_allowance,
            'position_allowance'=>$position_allowance,
            'home_allowance'=>$home_allowance,
            'gross_sallary'=>$gross_sallary,
            'taxable_income'=>$taxable_income,
            'income_tax'=>$income_tax,
            'pension_7'=>$pension_7,
            'pension_11'=>$pension_11,
            'other'=>$other,
            'netsallary'=>$netsallary,
            'gender'=>$gender,
            'mobile'=>$mobile,
            'email'=>$email,
            'branch'=>$branch,
            //'unique_id'=>$username,
            'usertype'=>$usertype,
            'status2'=>$userDivision
        );
        echo $this->main_model->update_staff_detail($id,$username,$data);     
    }
    function deleteStaff(){
        if($this->input->post('staff_id')){
            $staff_id=$this->input->post('staff_id');
            for($i=0;$i<count($staff_id);$i++){
                $checkStudent[]=$staff_id[$i];
            }
            echo $this->main_model->deleteStaffs($checkStudent);
        }
    }
    function resetStaffPassword(){
        if($this->input->post('editedId')){
            $editedId=$this->input->post('editedId');
            foreach($editedId as $stuID){
                /*$checkStudent[]=$editedId[$i];*/
                $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
                $pass = array(); //remember to declare $pass as an array
                $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
                for ($i = 0; $i < 8; $i++) {
                    $n = rand(0, $alphaLength);
                    $pass[] = $alphabet[$n];
                }
                $temp_pass= implode($pass); //turn the array into a string
                $passHash=hash('sha256', $temp_pass);
                $data=array(
                    'password'=>$passHash,
                    'password2'=>$passHash
                );
                echo $this->main_model->reset_staff_password($stuID,$data,$temp_pass);
            }
        }
    }
    function inactiveStaff(){
        if($this->input->post('staff_id')){
            $staff_id=$this->input->post('staff_id');
            for($i=0;$i<count($staff_id);$i++){
                $checkStudent[]=$staff_id[$i];
            }
            $this->load->model('main_model');
            $this->main_model->inactive_staffs($checkStudent);
        }
    }
    function activeStaff(){
        if($this->input->post('staff_id')){
            $staff_id=$this->input->post('staff_id');
            $this->load->model('main_model');
            for($i=0;$i<count($staff_id);$i++){
                $checkStudent[]=$staff_id[$i];
            }
            $this->main_model->active_staffs($checkStudent);
        }
    }
    function downloadStuData(){
        $query = $this->db->query("select max(year_name) as year from academicyear");
        $row = $query->row();
        $max_year=$row->year;
        $queryStuddent=$this->db->query("select username,usertype,fname,mname,lname,gender,mobile,mother_name,dob,age,email,city,sub_city,woreda,kebele,dateregister,branch,academicyear from users where usertype!='Student' and status='Active' and isapproved='1' and academicyear='$max_year' order by fname,mname,lname ASC ");
        $filename ='Staff-Data.csv';  
        header('Content-Type: testx/csv;charset=utf-8');
        header('Content-Disposition: attachment;filename="'.$filename.'"'); 
        $output=fopen('php://output', 'w');
        fputcsv($output,array('Username','Usertype','First Name','Middle Name','Last Name','Gender','Mobile','Mother Name','Date of birth','Age','Email','City','Sub city','Woreda','Kebele','Registration Date','Branch','Academic year'));
        foreach ($queryStuddent->result_array() as $row) {
            fputcsv($output,$row);
        } 
        fclose($output);
    }
}