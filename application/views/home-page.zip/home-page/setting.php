<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/summernote/summernote-bs4.css">
  <link rel="stylesheet" href="<?php  echo base_url(); ?>assets/css/pretty-checkbox.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/izitoast/css/iziToast.min.css">
  <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
       <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <?php include('bgcolor.php'); ?>
            <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">
            <div class="row mt-sm-4">
              <div class="col-lg-12">
                <div class="row">
                <div class="card">
                  <ul class="nav nav-tabs" id="myTab2" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active" id="home-tab2" data-toggle="tab" href="#about" role="tab" aria-selected="true">School Information</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab2" data-toggle="tab" href="#ayear" role="tab" aria-selected="false">Academic Year</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab4" data-toggle="tab" href="#branchTab" role="tab" aria-selected="false">Manage Branch</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab5" data-toggle="tab" href="#quarter" role="tab" aria-selected="false">Manage Quarter</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab6" data-toggle="tab" href="#promotionPolicy" role="tab" aria-selected="false">Promotion Policy</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab7" data-toggle="tab" href="#rankPolicy" role="tab" aria-selected="false">Total,Average & Rank Policy</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab8" data-toggle="tab" href="#letterGrades" role="tab" aria-selected="false">Letter Grades</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab9" data-toggle="tab" href="#schoolDivision" role="tab" aria-selected="false">Manage School Division</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab11" data-toggle="tab" href="#schoolAssesment" role="tab" aria-selected="false">School Assesment</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab12" data-toggle="tab" href="#reportcardComments" role="tab" aria-selected="false">Report Card Comments</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab13" data-toggle="tab" href="#lockMarkAutomatically" role="tab" aria-selected="false">Lock Mark Automatically</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab14" data-toggle="tab" href="#enableapprovemark" role="tab" aria-selected="false">Enable Approve Mark</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab10" data-toggle="tab" href="#socialPages" role="tab" aria-selected="false">Manage Social Pages</a>
                    </li>
                  </ul>
                  <div class="tab-content tab-bordered" id="myTab3Content">

                    <div class="tab-pane fade show active" id="about" role="tabpanel" aria-labelledby="home-tab2">
                      <?php echo form_open_multipart('Setting/schoolsetting');?>
                    <div class="row">
                      <div class="col-lg-3 col-6">
                        <div class="form-group">
                          <label for="Name">School Name</label>
                        <input class="form-control" name="sname" required="required" type="text" placeholder="School Name">
                       </div>
                     </div>
                     <div class="col-lg-3 col-6">
                      <div class="form-group">
                       <label for="logo">School Logo</label>
                       <div class="custom-file">
                        <input type="file" name="logo" class="custom-file-input" id="customFile">
                        <label class="custom-file-label" for="customFile">Choose Logo</label>
                      </div>
                      </div>
                     </div>
                     <div class="col-lg-3 col-6">
                        <div class="form-group">
                          <label for="email">School email</label>
                        <input class="form-control" name="email" required="required" type="email" placeholder="School email">
                       </div>
                     </div>
                     <div class="col-lg-3 col-6">
                        <div class="form-group">
                          <label for="Address">School Address</label>
                        <input class="form-control" name="address" 
                        required="required" type="text" placeholder="School Address">
                       </div>
                     </div>
                     <div class="col-lg-6 col-6">
                        <div class="form-group">
                          <label for="slogan">Motto/Slogan</label>
                        <input class="form-control" name="slogan" required="required" type="text" placeholder="School slogan here">
                       </div>
                     </div>
                     <div class="col-lg-6 col-6">
                        <div class="form-group">
                          <label for="slogan">School Website</label>
                        <input class="form-control" name="schoolwebsite" required="required" type="text" placeholder="School Website">
                       </div>
                     </div>
                     <div class="col-lg-6 col-6">
                        <div class="form-group">
                          <label for="Mobile">School Phone</label>
                        <textarea name="mobile" class="form-control summernote-simple bio">
                        
                      </textarea>
                       </div>
                     </div>
                     <div class="col-lg-6 col-6">
                      <label>Breif Description about school</label>
                      <textarea name="about" class="form-control summernote-simple bio">
                        
                      </textarea>
                      </div>
                     <div class="form-group col-lg-6 col-12">
                        <button type="submit" value="upload"
                         name="postschool" class="btn btn-primary btn-block">Save Info
                       </button>
                    </div>
                  </div>
                  </form>
                  <form action="<?php echo base_url()?>setting/" method="POST">
                     <div class="table-responsive">
                      <table class="table table-borderedr table-md">
                        <tr>
                          <th>Name</th>
                          <th>Logo</th>
                          <th>Phone</th>
                          <th>Email</th>
                          <th>Slogan</th>
                          <th>Website</th>
                          <th>Address</th>
                          <th>Created At</th>
                        </tr>
                        <?php foreach($schools as $school) {?>
                        <tr>
                          <td><?php echo $school->name;?></td>
                           <td>
                            <img src="<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>" style="height:50px;width:50px;border-radius: 3em;">
                           </td>
                           <td><?php echo $school->phone;?></td>
                           <td><?php echo $school->email;?></td>
                            <td><?php echo $school->slogan;?></td>
                            <td><?php echo $school->website;?></td>
                            <td><?php echo $school->address;?></td>
                          <td><?php echo $school->date_created;?></td>
                        </tr>
                        <?php } ?>
                      </table>
                    </div>
                    </form>
                  </div>

                  <div class="tab-pane fade show" id="ayear" role="tabpanel" aria-labelledby="home-tab3">
                    <form method="POST" action="<?php echo base_url() ?>setting/">
                    <div class="row">
                      <div class="col-lg-5 col-6">
                        <div class="form-group">
                          <label for="Mobile">Academic Year(Ethiopian)
                           </label>
                            <input class="form-control" id="academicyear" name="academicyear" required="required" type="text" placeholder="Ethiopian academic year here...">
                       </div>
                      </div>
                      <div class="col-lg-5 col-6">
                        <div class="form-group">
                          <label for="Mobile">Academic Year(Gregorian)
                           </label>
                            <input class="form-control" id="gacademicyear" name="gacademicyear" required="required" type="text" placeholder="Gregorian academic year here...">
                       </div>
                      </div>
                     <div class="col-lg-2 col-12">
                        <button type="submit" id="postyear" name="postyear" class="btn btn-primary btn-block">Save Year
                       </button>
                    </div>
                  </div>
                  </form>
                  
                    <div class="table-responsive">
                      <table class="table table-striped table-md">
                        <tr>
                          <th>Ethiopian Year</th>
                          <th>Gregorian Year</th>
                          <th>Created At</th>
                          <th>Action</th>
                        </tr>
                        <?php foreach($fetch_year as $fetch_years) { 
                          $id=$fetch_years->id;?>
                        <tr class="delete_year<?php echo $id ?>">
                          <td><?php echo $fetch_years->year_name;?></td>
                          <td><?php echo $fetch_years->gyear;?></td>
                          <td><?php echo $fetch_years->date_created;?>
                          </td>
                          <td>
                           <button type="submit" name="deleteyear" value="<?php echo $fetch_years->id; ?>" 
                            class="btn btn-default deleteyear"><span class="text-danger">Delete</span>
                           </button>
                          </td>
                        </tr>
                        <?php } ?>
                      </table>
                    </div>
                    <div class="checkNewYear"></div>
                    <button class="btn btn-primary" type="submit" id="moveBasicSkill">Move Basik Skill</button>
                    <button class="btn btn-primary" type="submit" id="moveKgsubjectObjective">Move KG Subject Objective</button>
                  </div>
                  <div class="tab-pane fade show" id="branchTab" role="tabpanel" aria-labelledby="home-tab4">
                    <form method="POST" action="<?php echo base_url() ?>setting/">
                    <div class="row">
                      <div class="col-lg-6 col-6">
                        <div class="form-group">
                          <input class="form-control" id="branch" name="branch" required="required" type="text" placeholder="Branch name here...">
                       </div>
                     </div>
                     <div class="col-lg-6 col-6">
                       <select class="form-control selectric"
                            required="required" name="bac" 
                            id="ac">
                            <?php foreach($academicyear as $academicyears){ ?>
                              <option>
                                <?php echo $academicyears->year_name ?>
                              </option>
                            <?php } ?>
                          </select>
                     </div>
                     <div class="col-lg-12 form-group">
                        <button type="submit" id="postyear"
                         name="postbranch" class="btn btn-info btn-sm btn-block">Save Branch
                       </button>
                    </div>
                  </div>
                  </form>
                  <form method="POST" action="<?php echo base_url() ?>setting/">
                    <div class="table-responsive">
                      <table class="table table-striped table-md">
                        <tr>
                          <th>Branch Name</th>
                          <th>Academic Year</th>
                          <th>Created At</th>
                          <th>Action</th>
                        </tr>
                        <?php foreach($branch as $branchs) { 
                          $id=$branchs->bid;?>
                        <tr class="delete_mem<?php echo $id ?>">
                          <td><?php echo $branchs->name;?></td>
                          <td><?php echo $branchs->academicyear;?></td>
                          <td><?php echo $branchs->datecreated;?>
                          </td>
                          <td>
                           <button type="submit" name="deletebranch"
                           onclick="return confirm('Are you sure you want to delete this Branch Name')"
                            value="<?php echo $branchs->bid; ?>" 
                            class="btn btn-default deletebranch"><span class="text-danger">Delete</span>
                           </button>
                          </td>
                        </tr>
                        <?php } ?>
                      </table>
                    </div>
                    </form>
                  </div>

                  <div class="tab-pane fade show" id="quarter" role="tabpanel" aria-labelledby="home-tab5">
                    <div class="placeOfQuarterGS">
                      <form id="comment_form" action="<?php echo base_url() ?>setting/">
                      <div class="row">
                       <div class="col-lg-3 col-6">
                          <div class="form-group">
                           <label for="ac">Academic year</label>
                            <select class="form-control selectric"
                              required="required" name="ac" 
                              id="ac">
                              <?php foreach($academicyear as $academicyears){ ?>
                                <option>
                                  <?php echo $academicyears->year_name ?>
                                </option>
                              <?php } ?>
                            </select>
                              <span class="text-danger"> 
                              <?php echo form_error('ac'); ?>
                              </span>
                          </div>
                       </div>
                       <div class="col-lg-3 col-6">
                          <div class="form-group">
                            <label for="Mobile">Quarter or Term</label>
                              <input class="form-control" id="term" 
                              required="required" name="term" type="text" placeholder="Quarter or Term">
                         </div>
                       </div>
                        <div class="col-lg-3 col-6">
                          <div class="form-group">
                            <label for="Mobile">Start Date</label>
                              <input class="form-control" id="startdate" 
                              required="required" name="startdate" type="date">
                          </div>
                       </div>
                       <div class="col-lg-3 col-6">
                          <div class="form-group">
                            <label for="Mobile">End Date</label>
                              <input class="form-control" id="endate" 
                              required="required" name="endate" type="date">
                          </div>
                       </div>
                      </div>
                       <div class="col-lg-12 col-12">
                          <button type="submit" id="posterm" name="posterm" class="btn btn-info btn-block">Save Quarter
                         </button>
                      </div>
                    </form>
                  </div>
                  <div class="dropdown-divider"></div>
                    <div class="placeOfQuarter"></div>
                  </div>

                  <div class="tab-pane fade show" id="promotionPolicy" role="tabpanel" aria-labelledby="home-tab6">
                    <form method="POST" id="save_policy">
                    <div class="row">
                      <div class="col-lg-4 col-12">
                        <div class="form-group">
                            <input class="form-control" id="policy_average"  required="required" name="policy_average" type="text" placeholder="Yearly Average">
                       </div>
                     </div>
                     <div class="col-lg-8 col-12" id="grajosstad">
                        <div class="form-group">
                          <label for="Mobile">Grade: </label>
                            <?php foreach($grade as $grades){ ?>
                              <?php echo $grades->grade; ?>
                              <div class="pretty p-icon p-jelly p-round p-bigger">
                              <input type="checkbox" name="policy_grade" value="<?php echo $grades->grade; ?>" class="policy_grade" id="customCheck1">
                              <div class="state p-info">
                                <i class="icon material-icons"></i>
                                <label></label>
                              </div>
                             </div>
                          <?php } ?>
                       </div>
                     </div>
                     <div class="col-lg-12 col-12">
                        <button type="submit" id="post_policy" name="postpolicy" class="btn btn-primary btn-block ">Save Policy
                       </button>
                    </div>
                  </div>
                  </form>
                  <div class="card-body" id="fetch_promotion_policy"> </div>
                  </div>

                  <div class="tab-pane fade show" id="rankPolicy" role="tabpanel" aria-labelledby="home-tab7">
                    <div class="row">
                      <div class="col-lg-4 col-6 table-responsive" id="totalGradeName" style="height:30vh">
                        <div class="form-group">
                          <label for="Mobile">Dispaly Total for Grades </label><br>
                          <?php foreach($grade as $grades){ 
                          $grade=$grades->grade;
                          $queryCheck=$this->db->query("select * from rank_allowed_grades where grade='$grade' and rowname='totalname' ");
                          if($queryCheck->num_rows()>0){ ?>
                          <div class="pretty p-switch p-fill">
                            <?php echo $grades->grade; ?>
                            <input type="checkbox" name="totalGradeName" class="totalGradeName" checked="checked" id="totalname" value="<?php echo $grades->grade; ?>" >
                            <div class="state p-success">
                              <label></label>
                            </div>
                          </div>
                          <?php } else { ?>
                          <div class="pretty p-switch p-fill">
                            <?php echo $grades->grade; ?>
                            <input type="checkbox" name="totalGradeName" class="totalGradeName" id="totalname" value="<?php echo $grades->grade; ?>" >
                            <div class="state p-success">
                              <label></label>
                            </div>
                          </div>
                          <?php } } ?>
                        </div>
                      </div>
                      <div class="col-lg-4 col-6 table-responsive" id="averageGradeName" style="height:30vh">
                        <div class="form-group">
                          <label for="Mobile">Dispaly Average for Grades </label><br>
                          <?php foreach($gradee as $grades){
                          $grade=$grades->grade;
                          $queryCheck=$this->db->query("select * from rank_allowed_grades where grade='$grade' and rowname='averagename' ");
                          if($queryCheck->num_rows()>0){ ?>
                          <div class="pretty p-switch p-fill">
                            <?php echo $grades->grade; ?>
                            <input type="checkbox" name="averageGradeName" class="averageGradeName" checked="checked" id="averagename" value="<?php echo $grades->grade; ?>" >
                            <div class="state p-success">
                              <label></label>
                            </div>
                          </div>
                          <?php } else { ?>
                          <div class="pretty p-switch p-fill">
                            <?php echo $grades->grade; ?>
                            <input type="checkbox" name="averageGradeName" class="averageGradeName" id="averagename" value="<?php echo $grades->grade; ?>" >
                            <div class="state p-success">
                              <label></label>
                            </div>
                          </div>
                          <?php } } ?>
                        </div>
                      </div>
                      <div class="col-lg-4 col-6 table-responsive" id="rankGradeName" style="height:30vh">
                        <div class="form-group">
                          <label for="Mobile">Dispaly Rank for Grades </label><br>
                          <?php foreach($gradee as $grades){
                          $grade=$grades->grade;
                          $queryCheck=$this->db->query("select * from rank_allowed_grades where grade='$grade' and rowname='rankname' ");
                          if($queryCheck->num_rows()>0){ ?>
                          <div class="pretty p-switch p-fill">
                            <?php echo $grades->grade; ?>
                            <input type="checkbox" name="rankGradeName" class="rankGradeName" checked="checked" id="rankname" value="<?php echo $grades->grade; ?>" >
                            <div class="state p-success">
                              <label></label>
                            </div>
                          </div>
                          <?php } else { ?>
                          <div class="pretty p-switch p-fill">
                            <?php echo $grades->grade; ?>
                            <input type="checkbox" name="rankGradeName" class="averageGradeName" id="rankname" value="<?php echo $grades->grade; ?>" >
                            <div class="state p-success">
                              <label></label>
                            </div>
                          </div>
                          <?php } } ?>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade show" id="letterGrades" role="tabpanel" aria-labelledby="home-tab8">
                    <form method="POST" id="save_letter_policy">
                    <div class="row">
                     <div class="col-lg-12 col-12" id="letter_grajosstad">
                        <div class="form-group">
                          <label for="Mobile">Set Letter for Grades <i data-feather="chevrons-right"></i></label>
                            <?php foreach($gradeee as $grades){ ?>
                              <?php echo $grades->grade; ?>
                              <div class="pretty p-icon p-jelly p-round p-bigger">
                              <input type="checkbox" name="letter_grade" value="<?php echo $grades->grade; ?>" class="letter_grade" id="customCheck1">
                              <div class="state p-info">
                                <i class="icon material-icons"></i>
                                <label></label>
                              </div>
                             </div>
                          <?php } ?>
                       </div>
                     </div>
                     <div class="col-md-3 col-6 form-group" id="letter_grajosstad">
                      <input type="text" class="form-control" name="startRange" id="startRange" placeholder="Minimum value">
                     </div>
                     <div class="col-md-3 col-6 form-group" id="letter_grajosstad">
                      <input type="text" class="form-control" name="endRange" id="endRange" placeholder="Maximum Value">
                     </div>
                     <div class="col-md-3 col-6 form-group" id="letter_grajosstad">
                       <input type="text" class="form-control" name="valtext" id="valtext" placeholder="Range Value">
                     </div>
                     <div class="col-lg-3 col-6 form-group">
                        <button type="submit" id="post_letter_policy" name="postpolicy" class="btn btn-primary btn-block ">Save Letter Policy
                       </button>
                    </div>
                  </div>
                  </form>
                  <div class="card-body" id="fetch_letter_policy"> </div>
                  </div>

                  <div class="tab-pane fade show" id="schoolDivision" role="tabpanel" aria-labelledby="home-tab9">
                    <div class="row">
                      <div class="col-lg-6 col-6">
                        <div class="form-group">
                          <input class="form-control" id="divisionName" 
                            required="required" name="divisionName" type="text" placeholder="Division Name(5-8 Division)etc...">
                       </div>
                     </div>
                     <div class="col-lg-6 col-6">
                        <button type="submit" id="postDivision" name="postDivision" class="btn btn-primary btn-block">Save Changes
                       </button>
                    </div>
                  </div>
                  <div class="fetchDivision"></div>
                  </div>

                  <div class="tab-pane fade show" id="schoolAssesment" role="tabpanel" aria-labelledby="home-tab11">
                    <div class="StudentViewTextInfo">
                      <div class="row">
                        <div class="col-lg-2 col-6">
                          <div class="form-group">
                            <label>Evaluation</label>
                            <select class="form-control selectric" required="required" name="schoolAssesmentEva" id="schoolAssesmentEva">
                              <option></option>
                              <?php foreach($fetchEval4Assesment as $fetchEval4Assesments){ ?>
                                  <option>
                                    <?php echo $fetchEval4Assesments->evname ?>
                                  </option>
                                <?php } ?>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-2 col-6">
                          
                          <div class="form-group">
                            <label>Assesment Name</label>
                            <input class="form-control" id="schoolAssesmentName" 
                              name="schoolAssesmentName" type="text" placeholder="School assesment...." required>
                          </div>
                        </div>
                        <div class="col-lg-2 col-5">
                          
                          <div class="form-group">
                            <label>End Date</label>
                            <input class="form-control" id="assesmentEndDate" 
                              name="assesmentEndDate" type="date" placeholder="Enter here school assesment...." required>
                          </div>
                        </div>
                        <div class="col-lg-4 col-7 table-responsive" style="height: 20vh;">

                          <div class="form-group">
                            <label>Select Grade</label>
                            <div class="row">
                              <?php foreach($gradeeee as $grades){ ?>
                              <div class="col-lg-4 col-6">
                              <div class="pretty p-icon p-jelly p-round p-bigger">
                               <input id="assesementGrade" type="checkbox" name="assesementGrade" value="<?php echo $grades->grade; ?>">
                               <div class="state p-info">
                                  <i class="icon material-icons"></i>
                                  <label></label>
                               </div>
                               </div>
                                <?php echo $grades->grade; ?>
                                <div class="dropdown-divider2"></div>
                              </div>
                              <?php } ?>
                            </div>
                          </div>
                        </div>
                        <div class="col-lg-2 col-12">
                          <button type="submit" id="postAssesment" name="postAssesment" class="btn btn-primary btn-block">Save Changes
                          </button>
                        </div>
                      </div>
                    </div><br>
                    <div class="fetchSchoolAssesment table-responsive" style="height: 40vh;"></div>
                  </div>

                  <div class="tab-pane fade show" id="reportcardComments" role="tabpanel" aria-labelledby="home-tab12">
                    <div class="row">
                      <div class="col-lg-2 col-6">
                        <div class="form-group">
                          <label for="Mobile">Min Value/Average</label>
                          <input class="form-control" id="minValue" 
                            name="minValue" type="number" placeholder="Minimum value" required>
                        </div>
                      </div>
                      <div class="col-lg-2 col-6">
                        <div class="form-group">
                          <label for="Mobile">Max Value/Average</label>
                          <input class="form-control" id="maxValue" 
                            name="maxValue" type="number" placeholder="Maximum value" required>
                        </div>
                      </div>
                      <div class="col-lg-3 col-6 table-responsive" style="height: 20vh;">
                        <div class="form-group">
                          <label for="Mobile">Grade</label>
                          <div class="row">
                            <?php foreach($gradeeeee as $grades){ ?>
                            <div class="col-lg-6 col-6">
                            <div class="pretty p-icon p-jelly p-round p-bigger">
                             <input id="commentGrade" type="checkbox" name="commentGrade" value="<?php echo $grades->grade; ?>">
                             <div class="state p-info">
                                <i class="icon material-icons"></i>
                                <label></label>
                             </div>
                             </div>
                              <?php echo $grades->grade; ?>
                              <div class="dropdown-divider2"></div>
                            </div>
                            <?php } ?>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-3 col-12">
                        <div class="form-group">
                          <label for="Mobile">Comment here</label>
                          <textarea class="form-control summernote-simple bio" id="reportcardComment" name="reportcardComment" placeholder="Lesson note here..."  required="required"> </textarea>
                        </div>
                      </div>
                      <div class="col-lg-2 col-12">
                        <button type="submit" id="postRcComment" name="postRcComment" class="btn btn-primary btn-block">Save Changes
                        </button>
                      </div>
                    </div>
                    <div class="fetchReportCardComment table-responsive" style="height: 30vh;"></div>
                  </div>

                  <div class="tab-pane fade show" id="lockMarkAutomatically" role="tabpanel" aria-labelledby="home-tab13">
                    <div class="dropdown-divider"></div>
                    <div class="lockMarkAutomatically"> </div>
                    <div class="dropdown-divider"></div>
                  </div>

                  <div class="tab-pane fade show" id="enableapprovemark" role="tabpanel" aria-labelledby="home-tab14">
                    <div class="dropdown-divider"></div>
                    <div class="enableApproveMark"> </div>
                    <div class="dropdown-divider"></div>
                  </div>

                  <div class="tab-pane fade show" id="socialPages" role="tabpanel" aria-labelledby="home-tab10">
                    <form method="POST" action="<?php echo base_url() ?>setting/">
                    <div class="row">
                      <div class="col-lg-3 col-6">
                        <div class="form-group">
                          <label for="Mobile">Facebook</label>
                            <input class="form-control" id="term" 
                            required="required" name="facebooklink" type="text" placeholder="Facebook Link">
                       </div>
                     </div>
                     <div class="col-lg-3 col-6">
                        <div class="form-group">
                          <label for="Mobile">Twitter Link</label>
                            <input class="form-control" id="term" 
                            required="required" name="twitterlink" type="text" placeholder="Twitter Link">
                       </div>
                     </div>
                     <div class="col-lg-3 col-6">
                        <div class="form-group">
                          <label for="Mobile">Instagram</label>
                            <input class="form-control" id="term" 
                            required="required" name="instagramlink" type="text" placeholder="Instagram Link">
                       </div>
                     </div>
                     <div class="col-lg-3 col-6">
                        <div class="form-group">
                          <label for="Mobile">Telegram Link</label>
                            <input class="form-control" id="term" 
                            required="required" name="telegramlink" type="text" placeholder="Telegram Link">
                       </div>
                     </div>
                     <div class="col-lg-12 col-12">
                        <button type="submit" id="postsocial" name="postsocial" class="btn btn-primary btn-block">Save Social Pages
                       </button>
                    </div>
                  </div>
                  </form>
                   <div class="table-responsive">
                      <table class="table table-striped table-md">
                        <tr>
                          <th>Facebook</th>
                          <th>Twitter</th>
                          <th>Telegram</th>
                          <th>Instagram</th>
                          <th>Date Created</th>
                        </tr>
                        <?php foreach($social_pages as $social_page) {?>
                        <tr>
                          <td><?php echo $social_page->facebook;?></td>
                          <td><?php echo $social_page->twitter;?></td>
                          <td><?php echo $social_page->telegram;?></td>
                          <td><?php echo $social_page->instagram;?></td>
                           <td><?php echo $social_page->date_created;?></td>
                        </tr>
                        <?php } ?>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
            </div>
          </div>
        </section>
      </div>
      <?php include('footer.php'); ?>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/summernote/summernote-bs4.js"></script>
  <script src="<?php echo base_url(); ?>assets/izitoast/js/iziToast.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>
  <script type="text/javascript">
  $(document).ready(function(){
    enableMarkAuto();
    function enableMarkAuto() {
      $.ajax({
        method:'POST',
        url:'<?php echo base_url() ?>setting/enableMarkAuto/',
        cache: false,
        beforeSend: function() {
          $('.enableApproveMark').html( 'Checking...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="54" height="54" id="loa">'
          );
        },
        success: function(html){
         $('.enableApproveMark').html(html);
        }
      })
    }
  
  $(document).on('click', "input[name='enableapprovemark']", function() {
    var markon=$(this).attr("value");
      if($(this).is(':checked')){
        $.ajax({
          url:"<?php echo base_url() ?>setting/saveEnableMarkApprove/",
          method:"POST",
          data:({
            markon:markon
          }),
          success: function(){
            iziToast.success({
              title: 'Approve Mark On.',
              message: '',
              position: 'bottomCenter'
            });
          }
        });
      }else{
        $.ajax({
          url:"<?php echo base_url() ?>setting/deleteEnableMarkApprove/",
          method:"POST",
          data:({
             markon:markon
          }),
          success: function(){
            iziToast.success({
              title: 'Approve Mark Off.',
              message: '',
              position: 'bottomCenter'
            });
          }
        });
      }
    });
  });
</script>
  <script type="text/javascript">
  $(document).ready(function(){
    checkMarkAutoLock();
    function checkMarkAutoLock() {
      $.ajax({
        method:'POST',
        url:'<?php echo base_url() ?>setting/lockMarkAutomatically/',
        cache: false,
        beforeSend: function() {
          $('.lockMarkAutomatically').html( 'Checking...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="54" height="54" id="loa">'
          );
        },
        success: function(html){
         $('.lockMarkAutomatically').html(html);
        }
      })
    }
  
  $(document).on('click', "input[name='lockmarkautoOn']", function() {
    var lockmark=$(this).attr("value");
      if($(this).is(':checked')){
        $.ajax({
          url:"<?php echo base_url() ?>setting/saveLockMarkAuto/",
          method:"POST",
          data:({
            lockmark:lockmark
          }),
          success: function(){
            iziToast.success({
              title: 'Mark',
              message: 'Will locked automatically',
              position: 'bottomCenter'
            });
          }
        });
      }else{
        $.ajax({
          url:"<?php echo base_url() ?>setting/deleteLockMarkAuto/",
          method:"POST",
          data:({
             lockmark:lockmark
          }),
          success: function(){
            iziToast.success({
              title: 'Mark',
              message: 'lock deleted successfully',
              position: 'bottomCenter'
            });
          }
        });
      }
    });
  });
</script>
  <script type="text/javascript">
  $(document).ready(function(){
    checkNewYear();
    function checkNewYear() {
      $.ajax({
        method:'POST',
        url:'<?php echo base_url() ?>setting/checkNewAcademicYear',
        cache: false,
        beforeSend: function() {
          $('.checkNewYear').html( 'Checking...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="54" height="54" id="loa">'
          );
        },
        success: function(html){
         $('.checkNewYear').html(html);
        }
      })
    }
  });
  $(document).on('click', '#prepareEveryThing', function() { 
    if (confirm("Are you sure you want to move last year setting?")) {
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>setting/moveSetting/",
        cache: false,
        beforeSend: function() {
          $('.checkNewYear').html( 'Starting form branch, Please wait...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="54" height="54" id="loa">'
          );
        },
        success: function(html) {
          $('.checkNewYear').html(html);
        }
      });
    } else {
      return false;
    }
  });
  $(document).on('click', '#moveKgsubjectObjective', function() { 
    swal({
      title: 'Are you sure you want to move KG Subject Objective?',
      text: '',
      icon: 'warning',
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>setting/movingSubjectObjective/",
          cache: false,
          beforeSend: function() {
            $('.checkNewYear').html( 'Please wait...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="54" height="54" id="loa">'
            );
          },
          success: function(html) {
            $('.checkNewYear').html(html);
          }
        });
      } else {
        return false;
      }
    });
  });
  $(document).on('click', '#moveBasicSkill', function() { 
    if (confirm("Are you sure you want to move last year Basic Skill?")) {
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>setting/movingBasicSkill/",
        cache: false,
        beforeSend: function() {
          $('.checkNewYear').html( 'Please wait...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="54" height="54" id="loa">'
          );
        },
        success: function(html) {
          $('.checkNewYear').html(html);
        }
      });
    } else {
      return false;
    }
  });
</script>
<script type="text/javascript">
  $(document).ready(function(){
    loadSchoolAssesment();
    function loadSchoolAssesment() {
      $.ajax({
        method:'POST',
        url:'<?php echo base_url() ?>setting/fetchAssesment/',
        cache: false,
        beforeSend: function() {
          $('.fetchSchoolAssesment').html( 'Loading Division...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="24" height="24" id="loa">'
          );
        },
        success: function(html){
         $('.fetchSchoolAssesment').html(html);
        }
      })
    }
    $("#postAssesment").on("click",function(event){
      var assesmentEval=$("#schoolAssesmentEva").val();
      var assesmentName=$("#schoolAssesmentName").val();
      var assesmentEndDate=$("#assesmentEndDate").val();
      assesmentGrade=[];
      $("input[name='assesementGrade']:checked").each(function(i){
        assesmentGrade[i]=$(this).val();
      });
      if($("#schoolAssesmentName").val()!==''){
        $.ajax({
          url:"<?php echo base_url() ?>setting/saveSchoolAssesment/",
          method:"POST",
          data:({
            assesmentEval:assesmentEval,
            assesmentName:assesmentName,
            assesmentGrade:assesmentGrade,
            assesmentEndDate:assesmentEndDate
          }),
          beforeSend:function(){
            $("#postAssesment").attr("disabled","disabled");
          },
          success: function(){
            loadSchoolAssesment();
            $("#schoolAssesmentName").val('');
            $("#postAssesment").removeAttr("disabled");
          }
        });
      }
    });
    $(document).on('click', '.deleteAssesment', function() { 
      var sasname = $(this).attr("id");
      swal({
        title: 'Are you sure you want to delete this assesment name?',
        text: '',
        icon: 'warning',
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
          $.ajax({
            method: "POST",
            url: "<?php echo base_url(); ?>setting/deleteAssesment/",
            data: ({
                sasname: sasname
            }),
            cache: false,
            success: function(html) {
              loadSchoolAssesment();
            }
          });
        } else {
          return false;
        }
      });
    });
    $(document).on('click', '.deleteAssesmentSasName', function() { 
      var sasname = $(this).attr("id");
      var sasgrade = $(this).attr("value");
      swal({
        title: 'Are you sure you want to delete this assesment name?',
        text: '',
        icon: 'warning',
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
          $.ajax({
            method: "POST",
            url: "<?php echo base_url(); ?>setting/deleteAssesmentName/",
            data: ({
                sasname: sasname,
                sasgrade:sasgrade
            }),
            cache: false,
            success: function(html) {
              loadSchoolAssesment();
            }
          });
        } else {
          return false;
        }
      });
    });
  });

  /*report card comment starts*/
  $(document).ready(function(){
    loadreportcardComment();
    function loadreportcardComment() {
      $.ajax({
        method:'POST',
        url:'<?php echo base_url() ?>setting/fetchrcComment/',
        cache: false,
        beforeSend: function() {
          $('.fetchReportCardComment').html( 'Loading Division...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="24" height="24" id="loa">'
          );
        },
        success: function(html){
         $('.fetchReportCardComment').html(html);
        }
      })
    }
    $("#postRcComment").on("click",function(event){
      var minValue=$("#minValue").val();
      var maxValue=$("#maxValue").val();
      var reportcardComment=$("#reportcardComment").val();
      commentGrade=[];
      $("input[name='commentGrade']:checked").each(function(i){
        commentGrade[i]=$(this).val();
      });
      if($("#reportcardComment").val()!==''){
        $.ajax({
          url:"<?php echo base_url() ?>setting/saveReportcardComment/",
          method:"POST",
          data:({
            minValue:minValue,
            maxValue:maxValue,
            reportcardComment:reportcardComment,
            commentGrade:commentGrade
          }),
          beforeSend:function(){
            $("#postRcComment").attr("disabled","disabled");
          },
          success: function(){
            loadreportcardComment();
            $("#reportcardComment").val('');
            $("#postRcComment").removeAttr("disabled");
          }
        });
      }
    });
    $(document).on('click', '.deleteCommentValue', function() { 
      var commentValue = $(this).attr("id");
      var mingradevalue = $(this).attr("value");
      var maxgradevalue = $(this).attr("name");
      if (confirm("Are you sure you want to delete this Comment?")) {
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>setting/deleteRCcomment/",
          data: ({
              mingradevalue: mingradevalue,
              maxgradevalue: maxgradevalue,
              commentValue:commentValue
          }),
          cache: false,
          success: function(html) {
            loadreportcardComment();
          }
        });
      } else {
        return false;
      }
    });
  });
</script>
<script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass();
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='white']").addClass("active");
      $(".selectgroup-input[value|='1']").prop("checked", true);
    } else {
      $("body").removeClass();
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='black']").addClass("active");
      $(".selectgroup-input[value|='2']").prop("checked", true);
    }
  });
</script>
<script type="text/javascript" language="javascript"> 
  var bgcolor_now=document.getElementById("bgcolor_now").value;
  if (bgcolor_now == "1") {
    $("body").removeClass();
    $("body").addClass("light");
    $("body").addClass("light-sidebar");
    $("body").addClass("theme-white");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='white']").addClass("active");
    $(".selectgroup-input[value|='1']").prop("checked", true);
  }else {
    $("body").removeClass();
    $("body").addClass("dark");
    $("body").addClass("dark-sidebar");
    $("body").addClass("theme-black");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='black']").addClass("active");
    $(".selectgroup-input[value|='2']").prop("checked", true);
  } 
</script> 
<!-- save division starts -->
<script type="text/javascript">
  $(document).ready(function(){
    loadDivision();
    function loadDivision() {
      $.ajax({
        method:'POST',
        url:'<?php echo base_url() ?>setting/fetchDivision/',
        cache: false,
        beforeSend: function() {
          $('.fetchDivision').html( 'Loading Division...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="24" height="24" id="loa">'
          );
        },
        success: function(html){
         $('.fetchDivision').html(html);
        }
      })
    }
    $("#postDivision").on("click",function(event){
      if($("#divisionName").val()!=''){
        var divisionName=$("#divisionName").val();
        $.ajax({
          url:"<?php echo base_url() ?>setting/saveSchoolDivision/",
          method:"POST",
          data:({
            divisionName:divisionName
          }),
          beforeSend:function(){
            $("#divisionName").attr("disabled","disabled");
          },
          success: function(){
            loadDivision();
            $("#divisionName").val('');
            $("#divisionName").removeAttr("disabled");
          }
        });
      }else{
        alert('Please enter necessary fields.');
      }
    });
    $(document).on('click', '.deleteDivision', function() { 
      var r_id = $(this).attr("id");
      if (confirm("Are you sure you want to delete this division ?")) {
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>setting/deleteDivision/",
          data: ({
              r_id: r_id
          }),
          cache: false,
          success: function(html) {
            $(".drange" + r_id).fadeOut('slow');
            loadDivision();
          }
        });
      } else {
        return false;
      }
    });
    /*delete academic year*/
    $(document).on('click', '.deleteyear', function() { 
      var yid = $(this).attr("value");
      if (confirm("Are you sure you want to delete this Academic Year ?")) {
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>setting/deleteyear/",
          data: ({
              yid: yid
          }),
          cache: false,
          success: function(html) {
            $(".delete_year" + yid).fadeOut('slow');
          }
        });
      } else {
        return false;
      }
    });
  });
</script>
<!-- Save policy Starts -->
<script type="text/javascript">
  $(document).ready(function(){
    load_promotion_policy();
    function load_promotion_policy() {
      $.ajax({
        method:'POST',
        url:'<?php echo base_url() ?>fetch_promotion_policy/',
        cache: false,
        beforeSend: function() {
          $('#fetch_promotion_policy').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="14" height="14" id="loa">'
          );
        },
        success: function(html){
         $('#fetch_promotion_policy').html(html);
        }
      })
    }
    $("#save_policy").on("submit",function(event){
      event.preventDefault();
      if($("#policy_average").val()!=''){
        var policy_average=$("#policy_average").val();
        policy_grade=[];
        $("input[name='policy_grade']:checked").each(function(i){
          policy_grade[i]=$(this).val();
        });
        $.ajax({
          url:"<?php echo base_url() ?>Save_promotion_policy/",
          method:"POST",
          data:({
            policy_average:policy_average,
            policy_grade: policy_grade
          }),
          beforeSend:function(){
            $("#post_policy").attr("disabled","disabled");
          },
          success: function(){
            load_promotion_policy();
            $("#save_policy")[0].reset();
            $("#post_policy").removeAttr("disabled");
          }
        });
      }else{
        alert('Please enter necessary fields.');
      }
    });
  });
</script>
<!-- Save promotion Policy Ends -->
<!-- Rank policy Starts -->
<script type="text/javascript">
  $(document).on('click', "input[name='totalGradeName']", function() {
    var grade=$(this).attr("value");
    var rowname=$(this).attr("id");
      if($(this).is(':checked')){
        $.ajax({
          url:"<?php echo base_url() ?>setting/saveTotalPolicy/",
          method:"POST",
          data:({
            grade: grade,
            rowname:rowname
          }),
          beforeSend:function(){
            $("#post_rank_policy").attr("disabled","disabled");
          },
          success: function(){
            iziToast.success({
              title: 'Rank Policy',
              message: 'saved successfully',
              position: 'topRight'
            });
          }
        });
      }else{
        $.ajax({
          url:"<?php echo base_url() ?>setting/deleteTotalPolicy/",
          method:"POST",
          data:({
            grade: grade,
            rowname:rowname
          }),
          beforeSend:function(){
            $("#post_rank_policy").attr("disabled","disabled");
          },
          success: function(){
            iziToast.success({
              title: 'Rank Policy',
              message: 'deleted successfully',
              position: 'topRight'
            });
          }
        });
      }
  });
  $(document).on('click', "input[name='averageGradeName']", function() {
    var grade=$(this).attr("value");
    var rowname=$(this).attr("id");
      if($(this).is(':checked')){
        $.ajax({
          url:"<?php echo base_url() ?>setting/saveAveragePolicy/",
          method:"POST",
          data:({
            grade: grade,
            rowname:rowname
          }),
          beforeSend:function(){
            $("#post_rank_policy").attr("disabled","disabled");
          },
          success: function(){
            iziToast.success({
              title: 'Average Policy',
              message: 'saved successfully',
              position: 'topRight'
            });
          }
        });
      }else{
        $.ajax({
          url:"<?php echo base_url() ?>setting/deleteAveragePolicy/",
          method:"POST",
          data:({
            grade: grade,
            rowname:rowname
          }),
          beforeSend:function(){
            $("#post_rank_policy").attr("disabled","disabled");
          },
          success: function(){
            iziToast.success({
              title: 'Average Policy',
              message: 'deleted successfully',
              position: 'topRight'
            });
          }
        });
      }
  });
  $(document).on('click', "input[name='rankGradeName']", function() {
    var grade=$(this).attr("value");
    var rowname=$(this).attr("id");
      if($(this).is(':checked')){
        $.ajax({
          url:"<?php echo base_url() ?>setting/saveRankPolicy/",
          method:"POST",
          data:({
            grade: grade,
            rowname:rowname
          }),
          beforeSend:function(){
            $("#post_rank_policy").attr("disabled","disabled");
          },
          success: function(){
            iziToast.success({
              title: 'Rank Policy',
              message: 'saved successfully',
              position: 'topRight'
            });
          }
        });
      }else{
        $.ajax({
          url:"<?php echo base_url() ?>setting/deleteRankPolicy/",
          method:"POST",
          data:({
            grade: grade,
            rowname:rowname
          }),
          beforeSend:function(){
            $("#post_rank_policy").attr("disabled","disabled");
          },
          success: function(){
            iziToast.success({
              title: 'Rank Policy',
              message: 'deleted successfully',
              position: 'topRight'
            });
          }
        });
      }
  });
  </script>
<!-- Save rank Ends -->
<!-- Letter policy Starts -->
<script type="text/javascript">
  $(document).ready(function(){
    load_letter_policy();
    function load_letter_policy() {
      $.ajax({
        method:'POST',
        url:'<?php echo base_url() ?>setting/fetchLetterPolicy/',
        cache: false,
        beforeSend: function() {
          $('#fetch_letter_policy').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="24" height="24" id="loa">'
          );
        },
        success: function(html){
         $('#fetch_letter_policy').html(html);
        }
      })
    }
    $("#save_letter_policy").on("submit",function(event){
      event.preventDefault();
      if($(".letter_grade").val()!=''){
        startRange=$('#startRange').val();
        endRange=$('#endRange').val();
        valtext=$('#valtext').val();
        letter_grade=[];
        $("input[name='letter_grade']:checked").each(function(i){
          letter_grade[i]=$(this).val();
        });
        $.ajax({
          url:"<?php echo base_url() ?>setting/saveLetterPolicy/",
          method:"POST",
          data:({
            letter_grade: letter_grade,
            startRange:startRange,
            endRange:endRange,
            valtext:valtext
          }),
          beforeSend:function(){
            $("#post_letter_policy").attr("disabled","disabled");
          },
          success: function(){
            load_letter_policy();
            $("#save_letter_policy")[0].reset();
            $("#post_letter_policy").removeAttr("disabled");
          }
        });
      }else{
        alert('Please enter necessary fields.');
      }
    });
    $(document).on('click', '.deleteLetterPolicy', function() { 
      var r_id = $(this).attr("id");
      if (confirm("Are you sure you want to delete this Range ?")) {
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>setting/deleteLetterPolicy",
          data: ({
              r_id: r_id
          }),
          cache: false,
          success: function(html) {
            $(".drange" + r_id).fadeOut('slow');
            load_letter_policy();
          }
        });
      } else {
        return false;
      }
    });

  });
</script>
<!-- Save rank Ends -->
<script>
  $(document).ready(function() {
    loadQuareter();
    function loadQuareter() {
      $.ajax({
        method:'POST',
        url:'<?php echo base_url() ?>setting/fetchQuarter/',
        cache: false,
        beforeSend: function() {
          $('.placeOfQuarter').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="24" height="24" id="loa">'
          );
        },
        success: function(html){
          $('.placeOfQuarter').html(html);
        }
      })
    }
    $('#comment_form').on('submit', function(event) {
      event.preventDefault();
      if ($('#term').val() != '') {
        var form_data = $(this).serialize();
        $.ajax({
          url: "<?php echo base_url(); ?>setting",
          method: "POST",
          data: form_data,
          beforeSend: function() {
            $('#posterm').attr("disabled", "disabled");
          },
          success: function(data) {
            loadQuareter();
            $('#comment_form')[0].reset();
            $("#posterm").removeAttr("disabled");
          }
        })
      } else {
        alert("Please write your quarter/Term Name.");
      }
    });    
    $(document).on('click', '.deleteterm', function() { 
      var term_id = $(this).attr("id");
      if (confirm("Are you sure you want to delete this term ?")) {
        $.ajax({
          method: "GET",
          url: "<?php echo base_url(); ?>setting",
          data: ({
              term_id: term_id
          }),
          cache: false,
          success: function(html) {
            $(".delete_mem" + term_id).fadeOut('slow');
          }
        });
      } else {
          return false;
      }
    });
  });
</script>
<script type="text/javascript">
    $(document).on('click', '.editerm', function() { 
      var term_id = $(this).attr("id");
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>setting/fetchTermToEdit/",
          data: ({
              term_id: term_id
          }),
          cache: false,
          success: function(html) {
            $('.placeOfQuarterGS').html(html);
          }
        });
    });
    
</script>
<script type="text/javascript">
  $(document).on('click', '.saveEditedQuarter', function() { 
      loadQuarter();
      function loadQuarter() {
        $.ajax({
          method:'POST',
          url:'<?php echo base_url() ?>setting/fetchQuarter/',
          cache: false,
          beforeSend: function() {
            $('.placeOfQuarter').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="24" height="24" id="loa">'
            );
          },
          success: function(html){
            $('.placeOfQuarter').html(html);
          }
        })
      }
      var termName = $('.termName').val();
      var termStartDate = $('.termStartDate').val();
      var termEndDate = $('.termEndDate').val();
      var termID=$('.termID').val();
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>setting/updateQuarter/",
          data: ({
            termName: termName,
            termStartDate:termStartDate,
            termEndDate:termEndDate,
            termID:termID
          }),
          cache: false,
          success: function(html) {
            loadQuarter();
          }
        });
    });
</script>
<script>
  $(document).ready(function() {  
    function unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_notification/",
        method: "POST",
        data: ({
            view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.notification-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-notification').html(data.unseen_notification);
          }
        }
      });
    }  
    function inbox_unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
        method: "POST",
        data: ({
            view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.inbox-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-inbox').html(data.unseen_notification);
          }
        }
      });
    }
    unseen_notification();
    inbox_unseen_notification();
    $(document).on('click', '.seen_noti', function() {
      $('.count-new-notification').html('');
      inbox_unseen_notification('yes');
    });
    $(document).on('click', '.seen', function() {
      $('.count-new-inbox').html('');
      inbox_unseen_notification('yes');
    });
    setInterval(function() {
      unseen_notification();
      inbox_unseen_notification();
    }, 5000);
  });
</script>
</body>
</html>