<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
  </title>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/pretty-checkbox.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/izitoast/css/iziToast.min.css">
<link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"><div class="loaderIcon"></div></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
       <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="card row">
              <div class="card-header col-12">
                <?php include('bgcolor.php'); ?>
                <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">
                <ul class="nav nav-tabs" id="myTab2" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link show active" id="home-tab0" data-toggle="tab" href="#bsCateShow" role="tab" aria-selected="true">Basic Skill Categories</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="home-tab1" data-toggle="tab" href="#bsnameShow" role="tab" aria-selected="false">Basic Skill Names</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="home-tab2" data-toggle="tab" href="#bstypeShow" role="tab" aria-selected="false">Bsic Skill Type</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="home-tab3" data-toggle="tab" href="#contypeShow" role="tab" aria-selected="false">Conduct Type</a>
                  </li>
                </ul>
                <div class="tab-content tab-bordered" id="myTab3Content">
                  <div class="tab-pane fade show active" id="bsCateShow" role="tabpanel" aria-labelledby="home-tab0">
                    <form method="POST" id="save_baskillCate">
                      <div class="row">
                        <div class="col-lg-5 col-6">
                         <div class="form-group">
                           <input type="text" class="form-control" id="bsnamecate" name="bsnamecate" placeholder="Basic skill category ...">
                          </div>
                        </div>
                        <div class="col-lg-5 col-6">
                          <div class="form-group">
                            <label for="Mobile"></label>
                            <?php foreach($grade as $grades){ ?>
                              <?php echo $grades->grade; ?>
                              <div class="pretty p-icon p-jelly p-round p-bigger">
                               <input id="categrade" type="checkbox" name="categrade" value="<?php echo $grades->grade; ?>">
                               <div class="state p-info">
                                  <i class="icon material-icons"></i>
                                  <label></label>
                               </div>
                             </div>
                            <?php } ?>
                          </div>
                        </div>
                        <div class="col-lg-2 col-12">
                          <button type="submit" name="postCategory" class="btn btn-primary btn-block">Save Category
                            </button>
                        </div>
                      </div>
                    </form>
                    <div id="bskillCategory" class="table-responsive" style="height:45vh;"> </div>
                  </div>
                  <div class="tab-pane fade show" id="bsnameShow" role="tabpanel" aria-labelledby="home-tab1">
                    <form method="POST" id="save_baskill">
                      <div class="row">
                        <div class="col-lg-3 col-6">
                         <div class="form-group">
                           <input type="text" class="form-control" id="bsname" name="bsname" placeholder="Basic skill name ...">
                          </div>
                        </div>
                        <div class="col-lg-3 col-6">
                          <div class="form-group">
                            <select class="form-control" required="required" name="linkcategory" id="linkcategory">
                            <option>Select Category</option>
                            <?php foreach($bscategory as $bscategorys){ ?>
                              <option value="<?php echo $bscategorys->bscategory; ?>"><?php echo $bscategorys->bscategory; ?></option>
                            <?php } ?>
                          </select>
                          </div>
                        </div>
                        <div class="col-lg-4 col-12">
                          <div class="form-group">
                            <label for="Mobile"></label>
                            <?php foreach($grade as $grades){ ?>
                              <?php echo $grades->grade; ?>
                              <div class="pretty p-icon p-jelly p-round p-bigger">
                               <input id="eva_grade" type="checkbox" name="grade" value="<?php echo $grades->grade; ?>">
                               <div class="state p-info">
                                  <i class="icon material-icons"></i>
                                  <label></label>
                               </div>
                             </div>
                            <?php } ?>
                            
                          </div>
                        </div>
                        <div class="col-lg-2 col-12">
                          <button type="submit" name="postevaluation" class="btn btn-primary btn-block">Save
                            </button>
                        </div>
                      </div>
                    </form>
                    <div id="bskillDataShow" class="table-responsive" style="height:45vh;"> </div>
                  </div>
                  <div class="tab-pane fade show" id="bstypeShow" role="tabpanel" aria-labelledby="home-tab2">
                    <div class="row">
                      <div class="col-lg-6 col-6">
                        <div class="form-group">
                          <label for="Mobile">Basic Skill Type</label>
                         <input class="form-control" id="bstype" name="bstype" type="text" placeholder="Basic skill type here">
                        </div>
                      </div>
                      <div class="col-lg-6 col-6">
                        <div class="form-group">
                          <label for="Mobile">Type Description</label>
                         <input class="form-control" id="bstypedecs" name="bstypedecs" type="text" placeholder="Basic skill description here">
                        </div>
                      </div>
                      <div class="col-lg-10 col-12">
                        <div class="form-group">
                          <label for="Mobile"></label>
                          <?php foreach($grade as $grades){ ?>
                            <?php echo $grades->grade; ?>
                            <div class="pretty p-icon p-jelly p-round p-bigger">
                             <input id="bsgrade" type="checkbox" name="bsgrade" value="<?php echo $grades->grade; ?>">
                             <div class="state p-info">
                                <i class="icon material-icons"></i>
                                <label></label>
                             </div>
                           </div>
                          <?php } ?>
                        </div>
                      </div>
                      <div class="col-lg-2 col-12">
                        <a id="infobstype"></a>
                        <button type="button" class="btn btn-primary btn-block" id="savebstype">Save</button>
                      </div>
                    </div>
                    <div class="table-responsive" id="bskilltype" style="height:45vh;">  </div>
                  </div>
                  <!--  -->
                  <div class="tab-pane fade show" id="contypeShow" role="tabpanel" aria-labelledby="home-tab3">
                    <div class="row">
                      <div class="col-lg-6 col-6">
                        <div class="form-group">
                          <label for="Mobile">Conduct Type</label>
                         <input class="form-control" id="cotype" name="cotype" type="text" placeholder="Conduct type here">
                        </div>
                      </div>
                      <div class="col-lg-6 col-6">
                        <div class="form-group">
                          <label for="Mobile">Type Description</label>
                         <input class="form-control" id="contypedecs" name="contypedecs" type="text" placeholder="Conduct description here">
                        </div>
                      </div>
                      <div class="col-lg-10 col-12">
                        <div class="form-group">
                          <label for="Mobile"></label>
                          <?php foreach($grade as $grades){ ?>
                            <?php echo $grades->grade; ?>
                            <div class="pretty p-icon p-jelly p-round p-bigger">
                             <input id="congrade" type="checkbox" name="congrade" value="<?php echo $grades->grade; ?>">
                             <div class="state p-info">
                                <i class="icon material-icons"></i>
                                <label></label>
                             </div>
                           </div>
                          <?php } ?>
                        </div>
                      </div>
                      <div class="col-lg-2 col-12">
                        <a id="infocontype"></a>
                        <button type="button" class="btn btn-primary btn-block" id="savecontype">Save</button>
                      </div>
                    </div>
                    <div class="card-body table-responsive" id="contype" style="height:45vh;">  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
      <?php include('footer.php'); ?>
    </div>
  </div>
  <!-- General JS Scripts -->
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/izitoast/js/iziToast.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>
</body>
<script type="text/javascript">
  $(document).ready(function(){
    $(document).on('click', "input[name='putbsCatLeftRow']", function() {
      var catName = $(this).attr("value");
      if($(this).is(':checked')){
        var catStatus = 1;
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>Basicskill/updateCatLeftRow/",
          data: ({
            catName: catName,
            catStatus:catStatus
          }),
          cache: false,
          success: function(html) {
            iziToast.success({
              title: 'Category status changed successfully',
              message: '',
              position: 'bottomCenter'
            });
          }
        });
      }else{
        var catStatus = 0;
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>Basicskill/updateCatRightRow/",
          data: ({
            catName: catName,
            catStatus:catStatus
          }),
          cache: false,
          success: function(html) {
            iziToast.success({
              title: 'Category status changed successfully',
              message: '',
              position: 'bottomCenter'
            });
          }
        });
      }
    });
  });
</script>
<script type="text/javascript">
  $(document).on('change', '.bssubOrderJo', function() {
    var suborder=$(this).find('option:selected').attr('value');
    var subject=$(this).find('option:selected').attr('id');
    $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Basicskill/updateCatOrder/",
        data: ({
          suborder:suborder,
          subject:subject
        }),
        success: function(data) {
          iziToast.success({
            title: 'Subject Order',
            message: 'Updated successfully',
            position: 'topRight'
          });
        }
    });
  });
</script>
<script type="text/javascript">
  $(document).ready(function(){
    loadcatedata();
    function loadcatedata()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>Basicskill/fetchBsCategory/",
        method:"POST",
        beforeSend: function() {
          $('#bskillCategory').html( 'Loading Basic Skill Category...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success:function(data){
          $('#bskillCategory').html(data);
        }
      })
    }
    $('#save_baskillCate').on('submit', function(event) {
      event.preventDefault();
      var bsnamecate=$('#bsnamecate').val();
      id=[];
      $("input[name='categrade']:checked").each(function(i){
        id[i]=$(this).val();
      });
      if($('#bsnamecate').val() =='' || id.length == 0)
      {
        swal('Oooops, Please type category.!', {
          icon: 'error',
        });
      }else{
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>Basicskill/insertBsCategory/",
          data: ({
            bsnamecate:bsnamecate,
            grade:id
          }),
          cache: false,
          success: function(html){
            $('#bsnamecate').val('');
            $('#categrade').prop('checked',false);
            loadcatedata();
          }
        });
      }
    });
  });
</script>
<script type="text/javascript">
  function loadcatedata()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>Basicskill/fetchBsCategory/",
        method:"POST",
        beforeSend: function() {
          $('#bskillCategory').html( 'Loading Basic Skill Category...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success:function(data){
          $('#bskillCategory').html(data);
        }
      })
    }
  $(document).on('click', '.deleteCAT', function() {
    var delte_id=$(this).attr("value");
    swal({
      title: 'Are you sure you want to delete this Basic skill category?',
      text: '',
      icon: 'warning',
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>Basicskill/deleteBsCategory/",
          data: ({
            delte_id: delte_id
          }),
          cache: false,
          success: function(html){
            $('.deleteCAT' + delte_id).fadeOut('slow');
            loadcatedata();
          }
        });
      }
    });
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    load_contypedata();
    function load_contypedata()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>Basicskill/fetchConductType/",
        method:"POST",
        beforeSend: function() {
          $('#contype').html( 'Loading Basic Skill Type...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success:function(data){
          $('#contype').html(data);
        }
      })
    }
    $(document).on('click', '#savecontype', function() {
      var cotype=$('#cotype').val();
      var contypedecs=$('#contypedecs').val();
      id=[];
      $("input[name='congrade']:checked").each(function(i){
        id[i]=$(this).val();
      });
      if($('#cotype').val() =='' || id.length == 0)
      {
        swal('Oooops, Please type conduct value!', {
          icon: 'error',
        });
      }else{
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>Basicskill/insertConType/",
          data: ({
            cotype:cotype,
            contypedecs:contypedecs,
            grade:id
          }),
          cache: false,
          success: function(html){
            $('#cotype').val('');
            $('#contypedecs').val('');
            $('#congrade').prop('checked',false);
            load_contypedata();
          }
        });
      }
    });
  });
   $(document).on('click', '.deletecontype', function() {
    var delte_id=$(this).attr("value");
    var delte_desc=$(this).attr("id");
    swal({
      title: 'Are you sure you want to delete this Conduct Type?',
      text: '',
      icon: 'warning',
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>Basicskill/deleteConType/",
          data: ({
            delte_id: delte_id,
            delte_desc:delte_desc
          }),
          cache: false,
          success: function(html){
            $('.deleteCon' + delte_id +delte_desc).fadeOut('slow');
            load_contypedata();
          }
        });
      }
    });
  });
</script>


<script type="text/javascript">
  $(document).ready(function(){
    load_bstypedata();
    function load_bstypedata()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>Basicskill/fetchBasicSkillsType/",
        method:"POST",
        beforeSend: function() {
          $('#bskilltype').html( 'Loading Basic Skill Type...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success:function(data){
          $('#bskilltype').html(data);
        }
      })
    }
    $(document).on('click', '#savebstype', function() {

      var bstype=$('#bstype').val();
      var bstypedecs=$('#bstypedecs').val();
      id=[];
      $("input[name='bsgrade']:checked").each(function(i){
        id[i]=$(this).val();
      });
      if($('#bstype').val() =='' || id.length == 0)
      {
        swal('Oooops, Please type Basic skill types!', {
          icon: 'error',
        });
      }else{
        $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Basicskill/insertBsType/",
        data: ({
          bstype:bstype,
          bstypedecs:bstypedecs,
          grade:id
        }),
        cache: false,
        success: function(html){
          $('#bstype').val('');
          $('#bstypedecs').val('');
          load_bstypedata();
        }
      });
    }
  });
  $(document).on('click', '.editbaskilltype', function() {
    var bstype=$(this).attr('value');
      $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>Basicskill/editBsType/",
      data: ({
        bstype:bstype
      }),
      cache: false,
      beforeSend: function() {
        $('#bskilltype').html( 'Loading Basic Skill Type...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
      },
      success: function(data){
        $('#bskilltype').html(data);
      }
    });
  });
  $(document).on('click', '#saveBsType', function() {
    var bstypeId=$(this).attr('value');
    var bstypeName=$('.bstypeInfo').val();
    var bstypeDesc=$('.bstdescInfo').val();
      $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>Basicskill/updateBsType/",
      data: ({
        bstypeId:bstypeId,
        bstypeName:bstypeName,
        bstypeDesc:bstypeDesc
      }),
      cache: false,
      success: function(data){
        load_bstypedata();
      }
    });
  });
});
   $(document).on('click', '.deletebaskilltype', function() {
    var delte_id=$(this).attr("value");
    swal({
      title: 'Are you sure you want to delete this Basic skill Type?',
      text: '',
      icon: 'warning',
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>Basicskill/deleteBsType/",
          data: ({
            delte_id: delte_id
          }),
          cache: false,
          success: function(html){
            $('.delete_bs' + delte_id).fadeOut('slow');
            load_bstypedata();
          }
        });
      }
    });
  });
</script>
<script type="text/javascript">
  $(document).ready(function(){
    load_data();
    function load_data()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>Basicskill/fetchBasicSkills/",
        method:"POST",
        beforeSend: function() {
          $('#bskillDataShow').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success:function(data){
          $('#bskillDataShow').html(data);
        }
      })
    }
    $('#save_baskill').on('submit', function(event) {
      event.preventDefault();
      var bsname=$('#bsname').val();
      var linkcategory=$('#linkcategory').val();
      id=[];
      $("input[name='grade']:checked").each(function(i){
        id[i]=$(this).val();
      });
      if( id.length == 0 || $('#bsname').val() =='')
      {
        swal('Oooops, Please select necessary fields!', {
          icon: 'error',
        });
      }else{
        $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Basicskill/",
        data: ({
          id: id,
          bsname:bsname,
          linkcategory:linkcategory
        }),
        cache: false,
        success: function(html){
          $('#save_baskill')[0].reset();
          load_data();
        }
      });
    }
  });
  $(document).on('click', "input[name='addOnSubRowGs']", function() {
    var bsGrade=$(this).attr('id');
    var bsName=$(this).attr('class');
    var bsValue=$(this).attr('value');
    if($(this).is(':checked')){
      $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>Basicskill/putOnSubjectRow/",
      data: ({
        bsGrade:bsGrade,
        bsName:bsName,
        bsValue:bsValue
      }),
      cache: false,
      success: function(html){
        iziToast.success({
          title: 'Basicskill',
          message: 'Updated successfully',
          position: 'topRight'
        });
      }
    });
    }else{
      $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>Basicskill/deleteputOnSubjectRow/",
      data: ({
        bsGrade:bsGrade,
        bsName:bsName,
        bsValue:bsValue
      }),
      cache: false,
      success: function(html){
        iziToast.success({
          title: 'Basicskill',
          message: 'Updated successfully',
          position: 'topRight'
        });
      }
    });
    }
  });
  $(document).on('click', '.editbaskill', function() {
    var bs=$(this).attr('value');
      $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>Basicskill/editbaskill/",
      data: ({
        bs:bs
      }),
      cache: false,
      beforeSend: function() {
        $('#bskillDataShow').html( 'Saving changes...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
      },
      success: function(data){
        $('#bskillDataShow').html(data);
      }
    });
  });
  $(document).on('click', '#saveBsInfo', function() {
    var bsInfo=$('.bsInfo').val();
    var bsnameInfo=$('#bsnameInfo').val();
      $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>Basicskill/updateBs/",
      data: ({
        bsInfo:bsInfo,
        bsnameInfo:bsnameInfo
      }),
      cache: false,
      success: function(data){
        load_data();
      }
    });
  });
});
</script>
<script type="text/javascript">
  function load_data()
  {
    $.ajax({
      url:"<?php echo base_url(); ?>Basicskill/fetchBasicSkills",
      method:"POST",
      beforeSend: function() {
        $('#bskillDataShow').html( 'Deleting...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="44" height="44" id="loa">');
      },
      success:function(data){
        $('#bskillDataShow').html(data);
      }
    })
  }
  $(document).on('click', '.deletebaskill', function() {
    var delte_id=$(this).attr("value");
    swal({
      title: 'Are you sure you want to delete this Basic skill?',
      text: '',
      icon: 'warning',
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>Basicskill/",
          data: ({
            delte_id: delte_id
          }),
          cache: false,
          success: function(html){
            $('.delete_bs' + delte_id).fadeOut('slow');
            load_data();
          }
        });
      }
    });
  });
</script>
<script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass();
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='white']").addClass("active");
      $(".selectgroup-input[value|='1']").prop("checked", true);
    } else {
      $("body").removeClass();
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='black']").addClass("active");
      $(".selectgroup-input[value|='2']").prop("checked", true);
    }
  });
</script>
<script type="text/javascript" language="javascript"> 
  var bgcolor_now=document.getElementById("bgcolor_now").value;
  if (bgcolor_now == "1") {
    $("body").removeClass();
    $("body").addClass("light");
    $("body").addClass("light-sidebar");
    $("body").addClass("theme-white");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='white']").addClass("active");
    $(".selectgroup-input[value|='1']").prop("checked", true);
  }else {
    $("body").removeClass();
    $("body").addClass("dark");
    $("body").addClass("dark-sidebar");
    $("body").addClass("theme-black");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='black']").addClass("active");
    $(".selectgroup-input[value|='2']").prop("checked", true);
  } 
</script> 
<script>
  $(document).ready(function() {  
    function unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_notification/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.notification-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-notification').html(data.unseen_notification);
          }
        }
      });
    }  
    function inbox_unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.inbox-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-inbox').html(data.unseen_notification);
          }
        }
      });
    }
    unseen_notification();
    inbox_unseen_notification();
    $(document).on('click', '.seen_noti', function() {
      $('.count-new-notification').html('');
      inbox_unseen_notification('yes');
    });
    $(document).on('click', '.seen', function() {
      $('.count-new-inbox').html('');
      inbox_unseen_notification('yes');
    });
    setInterval(function() {
      unseen_notification();
      inbox_unseen_notification();
    }, 5000);
  });
</script>
</html>