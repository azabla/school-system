<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/summernote/summernote-bs4.css">
  <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"><div class="loaderIcon"></div></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <?php include('headerdashboard.php'); ?>
      <div class="main-contentDashboard">
        <section class="section">
          <?php include('bgcolor.php'); ?>
          <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">

          <div class="row">
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-12">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                  <div class="align-items-center justify-content-between">
                    <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="card-content">
                          <h5 class="font-25 text-center" id="ENS" > <a href="<?php echo base_url(); ?>home/?admin-home-page/" class="btn btn-primary"><i data-feather="home"></i> Home </a></h5>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php if($_SESSION['usertype']==='superAdmin'){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                  <h5 class="font-15 text-center" id="ENS"><a class="btn btn-primary" data-toggle="collapse" href="#userGroup" role="button" aria-expanded="false" aria-controls="collapseExample">
                    <i data-feather="user-plus"></i><span>User Group</span>
                  </a></h5>
                </div>
                <div class="collapse text-center" id="userGroup">
                  <p> <a class="nav-link" href="<?php echo base_url(); ?>usergroup/"><i class=" fas fa-check-circle"></i> Add User Group</a>  <a class="nav-link" href="<?php echo base_url(); ?>userpermission/"><i class=" fas fa-check-circle"></i> User Permission</a></p>
                </div>
              </div>
            </div>
            <?php } ?>
            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){  ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                      <h5 class="font-15 text-center" id="ENS"><a class="btn btn-primary" data-toggle="collapse" href="#userStudent" role="button" aria-expanded="false" aria-controls="collapseExample"> <i data-feather="users"></i><span> Student</span>
                      </a></h5>
                </div>
                <div class="collapse text-center" id="userStudent">
                  <p>
                  <?php $uperStuDE=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentDE' order by id ASC ");  if($uperStuDE->num_rows()>0){  ?>
                     <a class="nav-link" href="<?php echo base_url(); ?>student/"><i data-feather="user-check"></i> Manage Student</a>
                  <?php } $uperStupro=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentPr' order by id ASC ");  if($uperStupro->num_rows()>0){ ?>
                    <a class="nav-link" href="<?php echo base_url() ?>registration/"><i data-feather="user-check"></i> Student Promotion</a> 
                  <?php } $uperStuPl=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentPl' order by id ASC ");  if($uperStuPl->num_rows()>0){ ?>
                    <h5 class="font-15 text-center" id="ENS"><a class="btn btn-default" data-toggle="collapse" href="#userStudentPlacement" role="button" aria-expanded="false" aria-controls="collapseExample"> <i data-feather="user-check"></i><span> Student Placement</span>
                  </a></h5>
                  <div class="collapse text-center" id="userStudentPlacement">
                    <a class="nav-link" href="<?php echo base_url(); ?>manualplacement/"><i class=" fas fa-check-circle"></i> Manual Placement</a>
                    <a href="<?php echo base_url(); ?>automaticplacement/" class="nav-link"><i class=" fas fa-check-circle"></i> Automatic Placement</a>
                  </div>
                  <?php } $uperStuPl=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='Studentbp' order by id ASC ");  if($uperStuPl->num_rows()>0){ ?>
                    <a class="nav-link" href="<?php echo base_url(); ?>branchplacement/"><i data-feather="user-check"></i> Branch Placement</a>
                  <?php } $uperStuView=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentVE' order by id ASC "); if($uperStuView->num_rows()>0){ ?>
                    <h5 class="font-15 text-center" id="ENS"><a class="btn btn-default" data-toggle="collapse" href="#userStudentRecordReport" role="button" aria-expanded="false" aria-controls="collapseExample"> <i data-feather="user-check"></i><span> Record Report</span>
                  </a></h5>
                    <div class="collapse text-center" id="userStudentRecordReport">
                      <a class="nav-link" href="<?php echo base_url(); ?>divisinrecordreport/"><i class=" fas fa-check-circle"></i> <span>By Division</span> </a>
                      <a class="nav-link" href="<?php echo base_url(); ?>graderecordreport/"><i class=" fas fa-check-circle"></i> <span>By Grade</span> </a>
                      <a class="nav-link" href="<?php echo base_url(); ?>sectionrecordreport/"><i class=" fas fa-check-circle"></i> <span>By Section</span> </a>
                      <a class="nav-link" href="<?php echo base_url(); ?>summaryrecordreport/"><i class=" fas fa-check-circle"></i> <span>Summary</span> </a>
                      <a class="nav-link" href="<?php echo base_url(); ?>nosection/"><i class=" fas fa-check-circle"></i> No.of Section</a>
                      <a class="nav-link" href="<?php echo base_url(); ?>similaruserid/"><i class=" fas fa-check-circle"></i> Similar ID</a>
                    </div>

                    <h5 class="font-15 text-center" id="ENS"><a class="btn btn-default" data-toggle="collapse" href="#userStudentGenderReport" role="button" aria-expanded="false" aria-controls="collapseExample"> <i data-feather="user-check"></i><span> Gender Report</span>
                  </a></h5>
                    <div class="collapse text-center" id="userStudentGenderReport">
                      <a class="nav-link" href="<?php echo base_url(); ?>gradereport/"><i class=" fas fa-check-circle"></i><span> By Grade</span> </a>
                      <a class="nav-link" href="<?php echo base_url(); ?>report/"><i class=" fas fa-check-circle"></i><span> By Section</span> </a>
                    </div>

                    <h5 class="font-15 text-center" id="ENS"><a class="btn btn-default" data-toggle="collapse" href="#userStudentphoneBook" role="button" aria-expanded="false" aria-controls="collapseExample"> <i data-feather="user-check"></i><span> Phone Book</span>
                  </a></h5>
                    <div class="collapse text-center" id="userStudentphoneBook">
                      <a href="<?php echo base_url(); ?>gradephonebook/" class="nav-link"><i class=" fas fa-check-circle"></i><span> By Grade </a>
                      <a href="<?php echo base_url(); ?>phonebook/" class="nav-link"><i class=" fas fa-check-circle"></i><span> By Section </a>
                    </div>
                    <?php } $gradeGroup=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='gradeGroup' order by id ASC "); if($gradeGroup->num_rows()>0){ ?>
                      <a class="nav-link" href="<?php echo base_url(); ?>gradegroup/"><i data-feather="user-check"></i> <span>Grade Group</span> </a>
                  <?php } $uperStuDrop=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentDrop' order by id ASC "); if($uperStuDrop->num_rows()>0){  ?>
                    <a class="nav-link" href="<?php echo base_url(); ?>dropoutstudents/"><i data-feather="user-check"></i> <span>Dropout Student</span> </a>
                  <?php }?>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>
            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                  <h5 class="font-15 text-center" id="ENS"><a class="btn btn-primary" data-toggle="collapse" href="#staffPlacement" role="button" aria-expanded="false" aria-controls="collapseExample">
                    <i data-feather="user-plus"></i><span> Staff & Placement</span>
                  </a></h5>
                </div>
                <div class="collapse text-center" id="staffPlacement">
                  <p> 
                    <?php $userpStaffDe=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='staffDE' order by id ASC ");  
                    if($userpStaffDe->num_rows()>0){ ?>
                    <a class="nav-link" href="<?php echo base_url(); ?>staffs/"><i class=" fas fa-check-circle"></i> Staffs List</a>
                    <?php } $userpStaffDP=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='directorPl' order by id ASC "); if($userpStaffDP->num_rows()>0){?>
                      <a class="nav-link" href="<?php echo base_url(); ?>directorplacement/"><i class=" fas fa-check-circle"></i> Director Placement</a>
                    <?php } $userpStaffTP=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='staffPl' order by id ASC "); if($userpStaffTP->num_rows()>0){?>
                      <a class="nav-link" href="<?php echo base_url(); ?>placement/"><i class=" fas fa-check-circle"></i> Teacher Placement</a>
                    <?php } $userpStaffHrP=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='hoomeroomPl' order by id ASC "); if($userpStaffHrP->num_rows()>0){?>
                      <a class="nav-link" href="<?php echo base_url(); ?>homeroomplacement/"><i class=" fas fa-check-circle"></i> Homeroom Placement</a> 
                    <?php } $userpStaffPhone=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='staffPhone' order by id ASC "); if($userpStaffPhone->num_rows()>0) { ?>
                      <a class="nav-link" href="<?php echo base_url(); ?>staffphone/"><i class=" fas fa-check-circle"></i> Staffs phone List</a> 
                  <?php } ?>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>
            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='Subject' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                  <h5 class="font-15 text-center" id="ENS"><a class="btn btn-primary" data-toggle="collapse" href="#mangeSubject" role="button" aria-expanded="false" aria-controls="collapseExample">
                    <i data-feather="book-open"></i><span> Manage Subject</span>
                  </a></h5>
                  
                </div>
                <div class="collapse text-center" id="mangeSubject">
                  <p> 
                    <a class="nav-link" href="<?php echo base_url(); ?>subject/"><i class=" fas fa-check-circle"></i> Grade Subject(s) List</a>
                    <a class="nav-link" href="<?php echo base_url(); ?>ordersubject/"><i class=" fas fa-check-circle"></i> Subject(s) Order</a>
                    <a class="nav-link" href="<?php echo base_url(); ?>kgsubject/"><i class=" fas fa-check-circle"></i> KG Subject(s) List</a>
                    <a class="nav-link" href="<?php echo base_url(); ?>subjectobjectives/"><i class=" fas fa-check-circle"></i> KG Subject(s) Objectives</a>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>
            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='IDCard' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS"><a class="btn btn-primary" data-toggle="collapse" href="#mangeIDCARD" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-plus"></i><span> ID CARD</span>
                    </a></h5>
                </div>
                <div class="collapse text-center" id="mangeIDCARD">
                  <p>
                    <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='IDCard' and allowed='StaffIDCard' order by id ASC ");  
                    if($usergroupPermission->num_rows()>0){ ?>
                    <a class="nav-link" href="<?php echo base_url(); ?>staffidcard/"><i class=" fas fa-check-circle"></i> Staff ID</a>
                     <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='IDCard' and allowed='StudentIDCard' order by id ASC ");if($usergroupPermission->num_rows()>0){ ?>
                    <a class="nav-link" href="<?php echo base_url(); ?>idcard/"><i class=" fas fa-check-circle"></i> Student ID</a>
                  <?php }?>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>
            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='Evaluation' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS"><a class="btn btn-primary" data-toggle="collapse" href="#manageEvaluation" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="briefcase"></i><span> Evaluation </span>
                    </a></h5>
                </div>
                <div class="collapse text-center" id="manageEvaluation">
                  <p>
                    <a class="nav-link" href="<?php echo base_url(); ?>evaluation/"><i class=" fas fa-check-circle"></i><span> Evaluation</span> </a>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>
            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Attendance' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS"><a class="btn btn-primary" data-toggle="collapse" href="#manageAttendance" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Manage Attendance </span>
                    </a></h5>
                </div>
                <div class="collapse text-center" id="manageAttendance">
                  <p>
                    <?php $userPerStuAtt=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Attendance' and allowed='studentAttendance' order by id ASC ");  if($userPerStuAtt->num_rows()>0){ ?>
                    <a class="nav-link" href="<?php echo base_url(); ?>attendance/"><i class=" fas fa-check-circle"></i> <span>Student Attendance</span> </a>
                    <?php } $userPerStaAtt=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Attendance' and allowed='staffAttendance' order by id ASC ");  if($userPerStaAtt->num_rows()>0){ ?>
                       <a class="nav-link" href="<?php echo base_url(); ?>staffattendance/"> <i class=" fas fa-check-circle"></i> <span>Staff Attendance</span> </a>
                    <?php } ?>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='communicationbook' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){  ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS"><a class="btn btn-primary" data-toggle="collapse" href="#communicationbook" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Communication Book </span>
                    </a></h5>
                  
                </div>
                <div class="collapse text-center" id="communicationbook">
                  <p>
                   <a class="nav-link" href="<?php echo base_url(); ?>communicationbook/?admin-communication-book/"><i class=" fas fa-check-circle"></i><span>Communication Book</span> </a>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='lessonplan' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS"><a class="btn btn-primary" data-toggle="collapse" href="#LessonPlan" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Lesson Plan </span>
                    </a></h5>
                </div>
                <div class="collapse text-center" id="LessonPlan">
                  <p>
                    <?php $upAddLplan=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='lessonplan' and allowed='addlessonplan' order by id ASC ");  if($upAddLplan->num_rows()>0){ ?>
                      <a class="nav-link" href="<?php echo base_url(); ?>addlessonplan/?lesson-plan-page/"> <i class=" fas fa-check-circle"></i> <span>Add Lesson Plan</span> </a>
                    <?php } $upViewLplan=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='lessonplan' and allowed='viewlessonplan' order by id ASC ");  if($upViewLplan->num_rows()>0){ ?>
                      <a class="nav-link" href="<?php echo base_url(); ?>viewlessonplan/"> <i class=" fas fa-check-circle"></i> <span>View Lesson Plan</span> </a>
                    <?php }?>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='homeworkworksheet' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#HomeworkWorksheet" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Homework & Worksheet </span>
                      </a>
                    </h5>
                </div>
                <div class="collapse text-center" id="HomeworkWorksheet">
                  <p>
                    <a class="nav-link" href="<?php echo base_url(); ?>addlesson/"><i class=" fas fa-check-circle"></i> <span>Add HW/Worksheet</span> </a>
                    <a class="nav-link" href="<?php echo base_url(); ?>viewlesson/"><i class=" fas fa-check-circle"></i> <span>View HW/Worksheet</span> </a>
                    <a class="nav-link" href="<?php echo base_url(); ?>viewansweredworksheet/"><i class=" fas fa-check-circle"></i> <span>Answered Worksheet</span> </a>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='studentexam' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#studentExam" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Student Exam </span>
                      </a>
                    </h5>
                  
                </div>
                <div class="collapse text-center" id="studentExam">
                  <p>
                   <a href="#" class="menu-toggle nav-link has-dropdown"> <i class=" fas fa-check-circle"></i> <span>Exam</span> </a>
                   <a class="nav-link" href="<?php echo base_url(); ?>exam/"> <i class=" fas fa-check-circle"></i><span>Add Exam</span> </a>
                   <a class="nav-link" href="<?php echo base_url(); ?>viewexam/"><i class=" fas fa-check-circle"></i> <span>View Exam</span> </a>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#studentMark" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Manage Mark </span>
                      </a>
                    </h5>
                </div>
                <div class="collapse text-center" id="studentMark">
                  <p>
                    <?php $markformat=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='studentmarkformat' order by id ASC ");  
                    if($markformat->num_rows()>0){ ?>
                      <a class="nav-link" href="<?php echo base_url(); ?>exportmarkformat/"><i class=" fas fa-check-circle"></i> <span>Prepare Mark Format</span> </a>
                      <a class="nav-link" href="<?php echo base_url(); ?>exportmanualmarkformat/?admin-manual-mark-format-page/"><i class=" fas fa-check-circle"></i> <span>Manual Mark Format</span> </a>
                    <?php } $uaddMark=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='addstudentmark' order by id ASC ");  
                    if($uaddMark->num_rows()>0){ ?>
                      <a class="nav-link" href="<?php echo base_url(); ?>adjusttable/"><i class=" fas fa-check-circle"></i> <span>Adjust Table For Mark</span> </a>
                      <a class="nav-link" href="<?php echo base_url(); ?>addexam/"><i class=" fas fa-check-circle"></i> <span>Add New result(Online)</span> </a>
                      <a class="nav-link" href="<?php echo base_url(); ?>addmark/"><i class=" fas fa-check-circle"></i> <span>Edit/Delete Mark result</span> </a>
                     <?php } $approveMark=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='approvemark' order by id ASC ");  
                    if($approveMark->num_rows()>0){ ?>  
                      <a class="nav-link" href="<?php echo base_url(); ?>approvemark/"><i class=" fas fa-check-circle"></i> <span>Approve Mark</span> </a>
                    <?php } $uaddMark=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='viewstudentmark' order by id ASC ");  
                    if($uaddMark->num_rows()>0){ ?>
                       <a class="nav-link" href="<?php echo base_url(); ?>ngmarkresult/"><i class=" fas fa-check-circle"></i> <span>View NG/Zero Result</span> </a>
                       <a class="nav-link" href="<?php echo base_url(); ?>rowmarkresult/"><i class=" fas fa-check-circle"></i> <span>Raw Mark Result</span> </a>
                       <a class="nav-link" href="<?php echo base_url(); ?>markresult/"><i class=" fas fa-check-circle"></i> <span>View Mark Result</span> </a>
                    <?php } ?>
                      <p>
                        <h5 class="font-15 text-center" id="ENS">
                          <a class="btn btn-default" data-toggle="collapse" href="#studentMarkAnalysis" role="button" aria-expanded="false" aria-controls="collapseExample">
                          <i data-feather="user-check"></i><span> Mark Result Analysis </span>
                          </a>
                        </h5>
                      </p>
                      <div class="collapse text-center" id="studentMarkAnalysis">
                        <p>
                          <a class="nav-link" href="<?php echo base_url(); ?>subjectmarkanalysis/"><i class=" fas fa-check-circle"></i> <span>By Subject</span> </a>
                          <a class="nav-link" href="<?php echo base_url(); ?>markanalysis/"><i class=" fas fa-check-circle"></i> <span>By Assesment</span> </a>
                        </p>
                      </div>
                      <a class="nav-link" href="<?php echo base_url(); ?>markprogress/"><i class=" fas fa-check-circle"></i> <span>Mark Progress</span> </a>
                      <?php $userpStaffAI=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='activeInactiveDiv' order by id ASC "); 
                      if($userpStaffAI->num_rows()>0){ ?>
                         <a class="nav-link" href="<?php echo base_url(); ?>markstatus/"><i class=" fas fa-check-circle"></i> <span>Lock Division</span> </a>
                      <?php } $userpStaffAI=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='lockstudentmark' order by id ASC "); if($userpStaffAI->num_rows()>0){?>
                        <a class="nav-link" href="<?php echo base_url(); ?>lockunlockstudentmark/?lock-unlock-page"><i class=" fas fa-check-circle"></i> <span>Lock Mark</span> </a>
                      <?php }?>
                    </p>
                </div>
              </div>
            </div>
            <?php } ?>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='studentbasicskill' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#studentBskill" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Student Basic Skill </span>
                      </a>
                    </h5>
                </div>
                <div class="collapse text-center" id="studentBskill">
                  <p>
                   <a class="nav-link" href="<?php echo base_url(); ?>basicskill/"><i class=" fas fa-check-circle"></i> <span>Add BS Name & Type</span> </a>
                   <a class="nav-link" href="<?php echo base_url(); ?>exportbsformate/"><i class=" fas fa-check-circle"></i> <span>Export BS format</span> </a>
                   <a class="nav-link" href="<?php echo base_url(); ?>importbs/"><i class=" fas fa-check-circle"></i> <span>Import BS format</span> </a>
                   <a class="nav-link" href="<?php echo base_url(); ?>viewstudentbs/"><i class=" fas fa-check-circle"></i> <span>View Student BS</span> </a>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>
            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='studentbasicskill' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#importExport" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Student Basic Skill </span>
                      </a>
                    </h5>
                </div>
                <div class="collapse text-center" id="importExport">
                  <p>
                   <?php $exportFile=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='ImportExport' and allowed='exportFile' order by id ASC ");  if($exportFile->num_rows()>0){ ?>
                    <a class="nav-link" href="<?php echo base_url(); ?>export/"><i class=" fas fa-check-circle"></i> Export Format</a>
                  <?php } $importFile=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='ImportExport' and allowed='importFile' order by id ASC ");  if($importFile->num_rows()>0){ ?>
                    <a class="nav-link" href="<?php echo base_url(); ?>import/"><i class=" fas fa-check-circle"></i> Import File</a>
                  <?php } ?>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' order by id ASC "); 
            if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#cardRoster" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Student Card & Roster </span>
                      </a>
                    </h5>
                </div>
                <div class="collapse text-center" id="cardRoster">
                  <p>
                    <?php $rpPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='reportcard' order by id ASC "); 
                  if($rpPermission->num_rows()>0){  ?>
                    <a class="nav-link" href="<?php echo base_url(); ?>reportcard/"><i class=" fas fa-check-circle"></i> Grade Report Card</a>
                    <a class="nav-link" href="<?php echo base_url(); ?>kgreportcard/"><i class=" fas fa-check-circle"></i> KG Report Card</a>
                    <?php } $raPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='rankReport' order by id ASC "); 
                    if($raPermission->num_rows()>0){ ?>
                    <p>
                      <h5 class="font-15 text-center" id="ENS">
                        <a class="btn btn-default" data-toggle="collapse" href="#rankReport" role="button" aria-expanded="false" aria-controls="collapseExample">
                        <i data-feather="user-check"></i><span> Student Rank Report </span>
                        </a>
                      </h5>
                    </p>
                    
                    <div class="collapse text-center" id="rankReport">
                      <p>
                        <a class="nav-link" href="<?php echo base_url(); ?>branchrankreport/"><i class=" fas fa-check-circle"></i> <span>By Branch</span> </a>
                         <a class="nav-link" href="<?php echo base_url(); ?>graderankreport/"><i class=" fas fa-check-circle"></i> <span>By Grade</span> </a>
                        <a class="nav-link" href="<?php echo base_url(); ?>rankreport/"><i class=" fas fa-check-circle"></i> <span>By Section</span>
                        </a>
                      </p>
                    </div>
                  <?php } $roPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='roster' order by id ASC "); 
                  if($roPermission->num_rows()>0){?>
                    <a class="nav-link" href="<?php echo base_url(); ?>roster/"><i class=" fas fa-check-circle"></i> Student Roster</a>
                    <?php } $trPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='transcript' order by id ASC "); 
                  if($trPermission->num_rows()>0){?>
                    <a class="nav-link" href="<?php echo base_url(); ?>transcript/"><i class=" fas fa-check-circle"></i> Transcript</a>
                    <?php }  $stPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='Statistics' order by id ASC "); 
                  if($stPermission->num_rows()>0){ ?>
                    <a class="nav-link" href="<?php echo base_url(); ?>markstatistics/"><i class=" fas fa-check-circle"></i> Report Statistics</a>
                    <?php } ?>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='feemanagment' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){  ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#feemanagment" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Fee Management </span>
                      </a>
                    </h5>
                </div>
                <div class="collapse text-center" id="feemanagment">
                  <p>
                    <a class="nav-link" href="<?php echo base_url(); ?>category/"><i class=" fas fa-check-circle"></i> Fee Category</a>
                    <a class="nav-link" href="<?php echo base_url(); ?>payment/"><i class=" fas fa-check-circle"></i> Add Fee</a>
                    <a class="nav-link" href="<?php echo base_url(); ?>paymentreport/"><i class=" fas fa-check-circle"></i> Fee Report</a>
                    <a class="nav-link" href="<?php echo base_url(); ?>payroll/"><i class=" fas fa-check-circle"></i> Staff Payroll</a>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>
            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='elibrary' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){  ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#libraryOther" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> E-Library & Other </span>
                      </a>
                    </h5>
                  
                </div>
                <div class="collapse text-center" id="libraryOther">
                  <p>
                    <a class="nav-link" href="#"> <i class=" fas fa-check-circle"></i> <span>Transportation</span> </a>
                    <a class="nav-link" href="#"> <i class=" fas fa-check-circle"></i> <span>Inventory</span> </a>
                    <a class="nav-link" href="<?php echo base_url(); ?>library/"> <i class=" fas fa-check-circle"></i> <span>E-Library</span> </a>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#chatMessage" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Messages & Mail </span>
                      </a>
                    </h5>
                  
                </div>
                <div class="collapse text-center" id="chatMessage">
                  <p>
                    <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='Chat' order by id ASC "); 
                    if($usergroupPermission->num_rows()>0){ ?>
                    <a class="nav-link" href="<?php echo base_url(); ?>chat/"><i class=" fas fa-check-circle"></i> Live Chat </a>
                    <a class="nav-link" href="<?php echo base_url(); ?>videochat/"><i class=" fas fa-check-circle"></i> Video Chat </a>
                    <a class="nav-link" href="<?php echo base_url(); ?>compose/"><i class=" fas fa-check-circle"></i> Compose</a>
                    <?php } ?>
                    <a class="nav-link" href="<?php echo base_url(); ?>inbox/"><i class=" fas fa-check-circle"></i> Inbox</a>
                    <a class="nav-link" href="<?php echo base_url(); ?>sent/"><i class=" fas fa-check-circle"></i> Sent</a>
                  </p>
                </div>
              </div>
            </div>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='schoolfiles' order by id ASC "); 
            if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#schoolFile" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> School Files</span>
                      </a>
                    </h5>
                  
                </div>
                <div class="collapse text-center" id="schoolFile">
                  <p>
                    <a class="nav-link" href="<?php echo base_url(); ?>schoolparents/"><i class=" fas fa-check-circle"></i> <span>School Parents</span> </a>
                    <a class="nav-link" href="#"><i class=" fas fa-check-circle"></i> <span>School Award</span> </a>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='websitemanagment' order by id ASC "); 
            if($usergroupPermission->num_rows()>0){  ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#websiteManagment" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Website Management</span>
                      </a>
                    </h5>
                  
                </div>
                <div class="collapse text-center" id="websiteManagment">
                  <p>
                    <a class="nav-link" href="<?php echo base_url(); ?>photogallery/"><i class=" fas fa-check-circle"></i> <span>Gallery</span> </a>
                    <a class="nav-link" href="<?php echo base_url(); ?>employment/"><i class=" fas fa-check-circle"></i> <span>Vacancy</span> </a>
                    <a class="nav-link" href="<?php echo base_url(); ?>blog/"> <i class=" fas fa-check-circle"></i> <span>News</span> </a>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>
            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='summerclass' order by id ASC "); 
            if($usergroupPermission->num_rows()>0){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#summerClassManage" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Summar Class</span>
                      </a>
                    </h5>
                  
                </div>
                <div class="collapse text-center" id="summerClassManage">
                  <p>
                    <a class="nav-link" href="<?php echo base_url(); ?>summerclass/?admin-summer-class-page/"><i class=" fas fa-check-circle"></i> <span>Summer class</span> </a>
                  </p>
                </div>
              </div>
            </div>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='teacherperformance' order by id ASC "); if($usergroupPermission->num_rows()>0){ ?>
              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                  
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#TeacherPerformance" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Teacher Performance</span>
                      </a>
                    </h5>
                  
                </div>
                <div class="collapse text-center" id="TeacherPerformance">
                  <p>
                    <a class="nav-link" href="<?php echo base_url(); ?>teachersperformance/?admin-teacher-performance-page/"><i class=" fas fa-check-circle"></i> <span>Teacher Performance</span> </a>
                  </p>
                </div>
              </div>
            </div>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='taskspage' order by id ASC "); 
            if($usergroupPermission->num_rows()>0){  ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#tasksManagment" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Other Tasks</span>
                      </a>
                    </h5>
                </div>
                <div class="collapse text-center" id="tasksManagment">
                  <p>
                    <a class="nav-link" href="#"><i class=" fas fa-check-circle"></i>  <span>Competition</span> </a>
                    <a class="nav-link" href="<?php echo base_url() ?>lineupschedule/"><i class=" fas fa-check-circle"></i> <span>LineUp Schedule</span> </a>
                    <a class="nav-link" href="<?php echo base_url() ?>timetable/"><i class=" fas fa-check-circle"></i> <span>Generate TimeTable </span> </a>
                    <a class="nav-link" href="#"><i class=" fas fa-check-circle"></i> <span>Certificate of the student </span> </a>
                    <a class="nav-link" href="#"><i class=" fas fa-check-circle"></i> <span>Appointment Letter</span> </a>

                    <p>
                      <h5 class="font-15 text-center" id="ENS">
                        <a class="btn btn-default" data-toggle="collapse" href="#examSchedule" role="button" aria-expanded="false" aria-controls="collapseExample">
                        <i data-feather="user-check"></i><span> Exam Schedule</span>
                        </a>
                      </h5>
                    </p>
                    <div class="collapse text-center" id="examSchedule">
                      <p>
                        <a class="nav-link" href="<?php echo base_url(); ?>examscheduler/"><i class=" fas fa-check-circle"></i> <span>Generate Schedule</span> </a>
                        <a class="nav-link" href="<?php echo base_url(); ?>viewexamscheduler/"><i class=" fas fa-check-circle"></i> <span>View Exam Schedule</span> </a>                          
                      </p>
                    </div>
                    <a class="nav-link" href="<?php echo base_url() ?>experience/"><i class=" fas fa-check-circle"></i> <span>Employee Experience</span> </a>
                    <a class="nav-link" href="#"><i class=" fas fa-check-circle"></i> <span>Sporting events </span> </a>
                    <a class="nav-link" href="#"><i class=" fas fa-check-circle"></i> <span>Classroom schedules </span> </a>
                    <a class="nav-link" href="#"><i class=" fas fa-check-circle"></i> <span>Field trip schedules</span> </a>
                    <a class="nav-link" href="#"><i class=" fas fa-check-circle"></i> <span>Themes</span> </a>
                  </p>
                </div>
              </div>
            </div>
            <?php } ?>

            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15 text-center" id="ENS" > <a class="btn btn-primary" href="<?php echo base_url(); ?>documents/"><i data-feather="file"></i><span>My Documents</span> </a></h5>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php if($_SESSION['usertype']==='superAdmin'){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15 text-center" id="ENS" >  <a class="btn btn-primary" href="<?php echo base_url(); ?>setting/"><i data-feather="settings"></i> <span>Setting</span> </a></h5>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php } ?>
            <?php if($_SESSION['usertype']==='superAdmin'){ ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                  <div class="align-items-center justify-content-between">
                    <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15 text-center" id="ENS" >  <a class="btn btn-primary" href="<?php echo base_url(); ?>loggeduser/"><i data-feather="log-in"></i> <span>Logs</span> </a></h5>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php } ?>

            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12 col-6">
              <div class="card btn btn-default">
                <div class="card-statistic-4 card-header">
                    <h5 class="font-15 text-center" id="ENS">
                      <a class="btn btn-primary" data-toggle="collapse" href="#darkMode" role="button" aria-expanded="false" aria-controls="collapseExample">
                      <i data-feather="user-check"></i><span> Dark Mode</span>
                      </a>
                    </h5>
                </div>
                <div class="collapse text-center" id="darkMode">
                  <p>
                    <a class="nav-link" href="#"> <label class="selectgroup-item">
                      <input type="radio" id="changecolor" name="value" value="1" class="selectgroup-input-radio select-layout" checked>
                      <i data-feather="sun"></i>Light </label></a>

                    <a class="nav-link" href="#"> <label class="selectgroup-item">
                      <input type="radio" id="changecolor" name="value" value="2" class="selectgroup-input-radio select-layout">
                      <i data-feather="moon"></i> Dark </label></a>
                  </p>
                </div>
              </div>
            </div>

            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12">
              <div class="text-center" id="ENS">
                <?php include('footer.php'); ?>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/summernote/summernote-bs4.js"></script>
  <script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass("dark");
      $("body").removeClass("dark-sidebar");
      $("body").removeClass("theme-black");
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
    } else {
      $("body").removeClass("light");
      $("body").removeClass("light-sidebar");
      $("body").removeClass("theme-white");
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
    }
  });
</script>
<script type="text/javascript" language="javascript"> 
  var bgcolor_now=document.getElementById("bgcolor_now").value;
  if (bgcolor_now == "1") {
    $("body").removeClass("dark");
    $("body").removeClass("dark-sidebar");
    $("body").removeClass("theme-black");
    $("body").addClass("light");
    $("body").addClass("light-sidebar");
    $("body").addClass("theme-white");
  }else {
    $("body").removeClass("light");
    $("body").removeClass("light-sidebar");
    $("body").removeClass("theme-white");
    $("body").addClass("dark");
    $("body").addClass("dark-sidebar");
    $("body").addClass("theme-black"); 
  } 
</script>
<script>
  $(document).ready(function() { 
    function unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_notification/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.notification-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-notification').html(data.unseen_notification);
          }
        }
      });
    }  
    function inbox_unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.inbox-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-inbox').html(data.unseen_notification);
          }
        }
      });
    }
    unseen_notification();
    inbox_unseen_notification();
    $(document).on('click', '.seen_noti', function() {
        $('.count-new-notification').html('');
        inbox_unseen_notification('yes');
    });
    $(document).on('click', '.seen', function() {
        $('.count-new-inbox').html('');
        inbox_unseen_notification('yes');
    });
    setInterval(function() {
      unseen_notification();
      inbox_unseen_notification();
    }, 5000);

  });
</script>
</body>

</html>