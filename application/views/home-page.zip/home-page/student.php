<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
   <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"><div class="loaderIcon"></div></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
       <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="row">
              <div class="col-lg-12">
                <div class="row">
                  <div class="col-lg-2 col-2">
                    <button type="submit" name="addnew" class="btn btn-outline-link btn-sm"> <a href="#" class="nav-link nav-link-lg"  data-toggle="modal" data-target="#newstudent" ><i data-feather="plus-circle"></i></a>
                    </button> 
                  </div>
                  <div class="col-lg-2 col-4">
                    <button type="submit" id="bulkyEditStudent" name="bulkyEditStudent" class="btn btn-default btn-sm pull-right"> <a href="#" class="nav-link"  data-toggle="modal" data-target="#editGroupStudent" >Group Edit<i class="fas fa-user-edit"></i> </a> </button>
                  </div>
                  <div class="col-lg-8 col-6">
                    <form method="POST" action="<?php echo base_url(); ?>student/downloadStuData/">
                      <button type="submit" id="downloadStuData" name="downloadStuData" class="btn btn-success btn-sm pull-right"> Download Student Data <i data-feather="download"></i>
                      </button>
                    </form>
                  </div>
                </div>
                <?php include('bgcolor.php'); ?>
                <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">
                <div class="card">
                  <div class="resetPasswordInfo"></div>
                  <div class="card-header">
                    <div class="row">
                      <div class="col-lg-4 col-6">
                        <p class="lastID"></p>
                      </div>
                      <div class="col-lg-4 col-6"><div class="nofstudents" id="nofstudents"></div></div>
                      <div class="col-lg-4 col-12">
                        <input type="text" name="searchStudent" id="searchStudent" class="form-control typeahead" placeholder="Search Student (Name, Id , Grade . . . ) ">
                      </div>
                    </div>
                  </div>
                  <div class="card-header">
                    <div class="row">
                      <div class="col-lg-2 col-6">
                         <div class="form-group">
                           <select class="form-control selectric" required="required" name="academicyear" id="grands_academicyear">
                            <option>--Year--</option>
                            <?php foreach($academicyear as $academicyears){ ?>
                              <option value="<?php echo $academicyears->year_name;?>">
                              <?php echo $academicyears->year_name;?>
                              </option>
                            <?php }?>
                           </select>
                          </div>
                         </div>
                         <div class="col-lg-3 col-6">
                          <div class="form-group">
                           <select class="form-control" required="required" name="branch" id="grands_branchit">
                           <option>--- Branch ---</option>
                           
                           </select>
                          </div>
                         </div>
                         <div class="col-lg-3 col-6">
                          <div class="form-group">
                           <select class="form-control grands_gradesec" name="gradesec" id="grands_gradesec">
                           <option>--- Section ---</option>
                           </select>
                          </div>
                         </div>
                         <div class="col-lg-2 col-6">
                          <div class="form-group">
                           <select class="form-control grands_grade" name="grands_grade" id="grands_grade">
                           <option>--- Grade ---</option>
                          </select>
                          </div>
                         </div>
                       <div class="col-lg-2 col-12">
                        <button class="btn btn-primary btn-block" 
                        type="submit" id="fetchStudent" name="viewmark">View</button>
                      </div>
                    </div>
                  <div class="listStudentShow table-responsive" id="student_view" style="height:40vh;"></div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <div class="modal fade" id="editGroupStudent" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
              <div class="infoChangeServicePlace"></div>
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="card">
                <div class="card-header">
                  
                
                  <ul class="nav nav-tabs" id="myTab2" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active" id="home-tab1" data-toggle="tab" href="#feedSubject" role="tab" aria-selected="true">Custom Group Edit</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab2" data-toggle="tab" href="#feedMergedSubject" role="tab" aria-selected="false">Default Group Edit</a>
                    </li>
                  </ul>
                  <div class="tab-content tab-bordered" id="myTab3Content">
                    <div class="tab-pane fade show active" id="feedSubject" role="tabpanel" aria-labelledby="home-tab1">
                      <div class="modal-body">
                        <div class="card">
                          <div class="">
                            <div class="row"> 
                              <div class="col-lg-6 col-12">
                                <div class="card-header">
                                  <input type="text" class="form-control typeahead" id="searchStudentForTransportPlace" name="searchStudentForTransportPlace" placeholder="Search Student Id,Name">
                                  <div class="table-responsive" style="height:15vh;">
                                    <div class="searchPlaceHere"></div> 
                                  </div>
                                </div>
                              </div>
                              <div class="col-lg-6 col-12">
                                <textarea class="form-control" id="selectStudentForTransportPlace" name="selectStudentForTransportPlace" col="12">  </textarea>
                                <button class="btn btn-default RemoveAll" id="removeAll" type="submit"><i class="fas fa-angle-double-left"></i></button>
                              </div> 
                              <div class="col-lg-6 col-6">
                                <div class="card-header">
                                  <select class="form-control" required="required" name="takeActionOption" id="takeActionOption">
                                    <option>Select Action</option>
                                    <option value="sectionGroup">Change Section(With Mark)</option>
                                    <option value="gradeGroup">Change Grade</option>
                                    <option value="branchGroup">Change Branch</option>
                                    <option value="deleteGroup">Delete Group</option>
                                    <option value="dropGroup">Drop(Archive) Group</option>
                                    <option value="adjustTransPlace">Adjust Transport Place</option>
                                  </select>
                                </div>
                              </div>
                              <div class="col-lg-6 col-6">
                                <div class="card-header">
                                  <button type ="submit" class="btn btn-primary btn-block" id="saveNewTransportPlace" name="saveNewTransportPlace" >Save Changes</button>
                                </div>
                              </div>
                                <div class="col-md-6 col-6 form-group">
                                  <div class="card-header">
                                    <input type ="text" class="form-control" id="newSection" disabled="disabled" name="newSection" placeholder="New section(A,B etc)..." > 
                                  </div>
                                </div>
                                <div class="col-md-6 col-6 form-group">
                                  <div class="card-header">
                                    <input type ="text" class="form-control" id="newGrade" disabled="disabled" name="newGrade" placeholder="New Grade(4,5 etc)..." > 
                                  </div>
                                </div>
                                <div class="col-md-6 col-6 form-group">
                                  <div class="card-header">
                                    <input type ="text" class="form-control" id="newBranch" disabled="disabled" name="newBranch" placeholder="New Branch..." > 
                                  </div>
                                </div>
                                <div class="col-md-6 col-6 form-group">
                                  <div class="card-header">
                                    <input type ="text" class="form-control" id="newServicePlace" disabled="disabled" name="newServicePlace" placeholder="New Service Place..." > 
                                  </div>
                                </div>
                            </div>
                            <div class="editGroupStudenthere" id="editGroupStudenthere"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="tab-pane fade show" id="feedMergedSubject" role="tabpanel" aria-labelledby="home-tab2">
                      <div class="infoForChangeDefaultGroupEdit"></div>
                      <div class="row">
                        <div class="col-lg-4 col-6">
                          <div class="form-group">
                            <select class="form-control selectric" required="required" name="groupbranch" id="groupbranch">
                             <option></option>
                            <?php foreach ($branch as $branchs) { ?>
                             <option value="<?php echo $branchs->name;  ?>"><?php echo $branchs->name; ?></option>
                            <?php  } ?>
                            </select>
                          </div>
                        </div>

                        <div class="col-lg-4 col-6">
                          <div class="form-group">
                           <select class="form-control groupgrade" name="grands_grade" id="groupgrade">
                           <option>--- Grade ---</option>
                          </select>
                          </div>
                        </div>
                        <div class="col-lg-4 col-6">
                          <div class="form-group">
                           <select class="form-control groupgradesec" name="gradesec" id="groupgradesec">
                           <option>--- Section ---</option>
                           </select>
                          </div>
                        </div>
                        <div class="col-lg-6 col-6">
                          <select class="form-control" required="required" name="takeDefaultActionOption" id="takeDefaultActionOption">
                            <option>Select Action</option>
                            <!-- <option value="changeBranchGroup">Change Branch</option> -->
                            <option value="deleteBranchGroup">Delete Group</option>
                            <option value="dropBranchGroup">Drop(Archive) Group</option>
                            <option value="undropBranchGroup">Re-register(Unarchive) Group</option>
                            <!-- <option value="adjustBranchTransPlace">Adjust Transport Place</option> -->
                          </select>
                        </div>
                        <div class="col-lg-6 col-12">
                          <button class="btn btn-primary btn-block" type="submit" id="changeDefaultGroup">Save Changes</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="modal fade" id="printStudentViewModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">
                  <button class="btn btn-default" onclick="codespeedyStudentView()" name="printlessonplan" type="submit" id="">
                      <span class="text-warning">Print <i class="fas fa-print"></i></span>
                  </button></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="StudentViewPrintHere" id="StudentViewPrintHere"> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php include('footer.php'); ?>
    </div>
  </div>
  <!-- General JS Scripts -->
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>
</body>
  <script type="text/javascript">
    $(document).on('click', '#changeDefaultGroup', function() {
      event.preventDefault();
      var groupBranch=$('#groupbranch').val();
      var groupGrade=$('#groupgrade').val(); 
      var groupSection=$('#groupgradesec').val();
      var actionType=$('#takeDefaultActionOption').val();
      if($('#groupgrade').val()!='' || $('#groupgradesec').val()!=''){
        swal({
          title: 'Are you sure you want to change this student status?',
          text: '',
          icon: 'warning',
          buttons: true,
          dangerMode: true,
        })
      .then((willDelete) => {
        if (willDelete) {
          $.ajax({
            url: "<?php echo base_url(); ?>student/changeDefaultGroupEdit/",
            method: "POST",
            data: ({
              groupBranch: groupBranch,
              groupGrade:groupGrade,
              groupSection:groupSection,
              actionType:actionType
            }),
            beforeSend: function() {
              $('.infoForChangeDefaultGroupEdit').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">' );
            },
            success: function(html) {
              $(".infoForChangeDefaultGroupEdit").html(html);
              swal('Status Changed Successfully!', {
                icon: 'success',
              });
            }
          });
        }
      });
    }else{
      swal('Please select all necessary fields!', {
        icon: 'error',
      });
    }
  });
  </script>
  <script type="text/javascript">
  $(document).ready(function() {  
    $("#groupbranch").bind("change", function() {
      var branchit=$('#groupbranch').val();
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>student/filterGradeForGroup/",
        data: ({
            branchit: branchit
        }),
        beforeSend: function() {
          $('.groupgradesec').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(data) {
          $(".groupgradesec").html(data);
        }
      });
    });
  });
  $(document).ready(function() {  
    $("#groupbranch").bind("change", function() {
      var branchit=$('#groupbranch').val();
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Student/filterOnlyGradeFromBranchForGroup/",
        data: ({
            branchit: branchit
        }),
        beforeSend: function() {
          $('.groupgrade').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(data) {
          $(".groupgrade").html(data);
        }
      });
    });
  });
</script>

  <script type="text/javascript">
    $(document).ready(function() { 
      $('#searchStudentForTransportPlace').on("keyup",function() {
        $searchItem=$('#searchStudentForTransportPlace').val();
        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>student/searchStudentsToTransportService/",
          data: "searchItem=" + $("#searchStudentForTransportPlace").val(),
          beforeSend: function() {
            $('.searchPlaceHere').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">' );
          },
          success: function(data) {
            $(".searchPlaceHere").html(data);
          }
        });
      });
    });
    $(document).on('click', '.saveThisStudentToGroupEdit', function() {
      event.preventDefault();
      var oldText=$('#selectStudentForTransportPlace').val();
      var stuID=$(this).attr("value");
      var newText=oldText+stuID+"\n";
      $("#selectStudentForTransportPlace").val(newText);   
    });
    $(document).on('click', '#removeAll', function() {
      event.preventDefault();
      $("#selectStudentForTransportPlace").val('');   
    });
  </script>
  <script type="text/javascript">
    $(document).on('change', '#takeActionOption', function() {
      var abtype=$(this).val();
      if($(this).val()=='adjustTransPlace'){
        $("input[name='newServicePlace']:disabled").each(function(i){
          $(this).removeAttr("disabled","disabled");
        });
      }else{
       $("#newServicePlace").attr("disabled","disabled");
      }
      if($(this).val()=='sectionGroup'){
        $("input[name='newSection']:disabled").each(function(i){
          $(this).removeAttr("disabled","disabled");
        });
      }else{
       $("#newSection").attr("disabled","disabled");
      }
      if($(this).val()=='gradeGroup'){
        $("input[name='newGrade']:disabled").each(function(i){
          $(this).removeAttr("disabled","disabled");
        });
      }else{
       $("#newGrade").attr("disabled","disabled");
      }
      if($(this).val()=='branchGroup'){
        $("input[name='newBranch']:disabled").each(function(i){
          $(this).removeAttr("disabled","disabled");
        });
      }else{
       $("#newBranch").attr("disabled","disabled");
      }
    });
    $(document).on('click', '#saveNewTransportPlace', function() {
      event.preventDefault();
      var takeAction=$('#takeActionOption').val(); 
      var newServiceTransPlace=$('#newServicePlace').val();
      var newSection=$('#newSection').val();
      var newGrade=$('#newGrade').val();
      var branchGroup=$('#newBranch').val();
      var newServicePlace=$('#selectStudentForTransportPlace').val();
      var stuIdArray=newServicePlace.split(/(\s+)/);
      swal({
        title: 'Are you sure?',
        text: '',
        icon: 'warning',
        buttons: true,
        dangerMode: true,
      })
    .then((willDelete) => {
      if (willDelete) {
        swal('Status Changed Successfully!', {
          icon: 'success',
        });
        $.ajax({
          url: "<?php echo base_url(); ?>student/saveNewTransportPlace/",
          method: "POST",
          data: ({
            stuIdArray: stuIdArray,
            newServiceTransPlace:newServiceTransPlace,
            takeAction:takeAction,
            newSection:newSection,
            newGrade:newGrade,
            branchGroup:branchGroup
          }),
          beforeSend: function() {
            $('.infoChangeServicePlace').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">' );
          },
          success: function(data) {
            $(".infoChangeServicePlace").html(data);
          }
        });
      }
    });
  });
  </script>
 <script type="text/javascript">
  function codespeedyAttendancePrint(){
    var print_div = document.getElementById("prinThiStudentAttendance");
    var print_area = window.open();
    print_area.document.write(print_div.innerHTML);
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" type="text/css" />');
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css" type="text/css" />');
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css" type="text/css" />');
    print_area.document.close();
    print_area.focus();
    print_area.print();
  }
</script>
<script type="text/javascript">
  $(document).on('click', '#viewStuAttendance', function() {
    event.preventDefault();
    var stuID=$(this).attr("value");
    var yearattende=$(this).attr("name");
    $.ajax({
      url: "<?php echo base_url(); ?>student/fecthThiStudentAttendance/",
      method: "POST",
      data: ({
        stuID: stuID,
        yearattende:yearattende
      }),
      beforeSend: function() {
        $('.listStudentShow').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">' );
      },
      success: function(data) {
        $(".listStudentShow").html(data);
      }
    })
  });
</script>
<!-- Grade change script starts-->
<script type="text/javascript">
  $(document).ready(function() {  
    $("#grands_academicyear").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>student/filterGradesecfromBranch/",
        data: "academicyear=" + $("#grands_academicyear").val(),
        beforeSend: function() {
          $('#grands_branchit').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(data) {
          $("#grands_branchit").html(data);
        }
      });
    });
  });
  $(document).ready(function() { 
    $('#searchStudent').on("keyup",function() {
      $searchItem=$('#searchStudent').val();
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>student/searchStudent/",
        data: "searchItem=" + $("#searchStudent").val(),
        beforeSend: function() {
          $('.listStudentShow').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">' );
        },
        success: function(data) {
          $(".listStudentShow").html(data);
        }
      });
    });
  });
</script>
<script type="text/javascript">
  $(document).ready(function() {  
    $("#grands_branchit").bind("change", function() {
      var branchit=$('#grands_branchit').val();
      var grands_academicyear=$('#grands_academicyear').val();
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>student/Filter_grade_from_branch/",
        data: ({
            branchit: branchit,
            grands_academicyear:grands_academicyear
        }),
        beforeSend: function() {
          $('.grands_gradesec').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(data) {
          $(".grands_gradesec").html(data);
        }
      });
    });
  });
  $(document).ready(function() {  
    $("#grands_branchit").bind("change", function() {
      var branchit=$('#grands_branchit').val();
      var grands_academicyear=$('#grands_academicyear').val();
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Student/filterOnlyGradeFromBranch/",
        data: ({
            branchit: branchit,
            grands_academicyear:grands_academicyear
        }),
        beforeSend: function() {
          $('.grands_grade').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(data) {
          $(".grands_grade").html(data);
        }
      });
    });
  });
</script>
<!-- Grade change script ends -->
<script type="text/javascript">
  $(document).on('click', '#fetchStudent', function() {
    event.preventDefault();
    var gs_branches=$('#grands_branchit').val();
    var gs_gradesec=$('.grands_gradesec').val();
    var onlyGrade=$('.grands_grade').val();
    var grands_academicyear=$('#grands_academicyear').val();
    if ($('.grands_gradesec').val() != '' || $('.grands_grade').val() != '') {
      $.ajax({
        url: "<?php echo base_url(); ?>student/Fecth_thistudent/",
        method: "POST",
        data: ({
          gs_branches: gs_branches,
          gs_gradesec:gs_gradesec,
          onlyGrade:onlyGrade,
          grands_academicyear:grands_academicyear
        }),
        beforeSend: function() {
          $('.listStudentShow').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">' );
        },
        success: function(data) {
          $(".listStudentShow").html(data);
        }
      })
    }else {
      swal('All fields are required.', {
        icon: 'error',
      });
    }
  });
</script>
<script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass();
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='white']").addClass("active");
      $(".selectgroup-input[value|='1']").prop("checked", true);
    } else {
      $("body").removeClass();
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='black']").addClass("active");
      $(".selectgroup-input[value|='2']").prop("checked", true);
    }
  });
</script>
<script type="text/javascript" language="javascript"> 
  var bgcolor_now=document.getElementById("bgcolor_now").value;
  if (bgcolor_now == "1") {
    $("body").removeClass();
    $("body").addClass("light");
    $("body").addClass("light-sidebar");
    $("body").addClass("theme-white");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='white']").addClass("active");
    $(".selectgroup-input[value|='1']").prop("checked", true);
  }else {
    $("body").removeClass();
    $("body").addClass("dark");
    $("body").addClass("dark-sidebar");
    $("body").addClass("theme-black");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='black']").addClass("active");
    $(".selectgroup-input[value|='2']").prop("checked", true);
  } 
</script> 
<script type="text/javascript">
  $(document).on('click', '#downloadStuData', function() {
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>student/downloadStuData/",
        cache: false,
        success: function(html) {
          $("#downloadStuData").html('Download Finished.');
          window.open('<?php echo base_url(); ?>student/downloadStuData/','_blanck');
        }
      });
  });
</script>
<script type="text/javascript">
  $(document).on('click', '.deletestudent', function() {
    var post_id = $(this).attr("id");
    swal({
      title: 'Are you sure?',
      text: 'Once deleted, you will not be able to recover this student file!',
      icon: 'warning',
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {
        swal('Student Deleted Successfully!', {
          icon: 'success',
        });
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>student/",
          data: ({
            post_id: post_id
          }),
          cache: false,
          success: function(html) {
            $(".delete_mem" + post_id).fadeOut('slow');
          }
        });
      }
    });
  });
</script>
<script type="text/javascript">
  $(document).on('click', '.dropstudent', function() {
    var drop_id = $(this).attr("id");
    swal({
      title: 'Are you sure?',
      text: 'Once Droped, you will not be able to see this student file!',
      icon: 'warning',
      buttons: true,
      dangerMode: true,
    })

    .then((willDelete) => {
      if (willDelete) {
        swal('Student Droped Successfully!', {
          icon: 'success',
        });
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>student/",
          data: ({
            drop_id: drop_id
          }),
          cache: false,
          success: function(html) {
            $(".delete_mem" + drop_id).fadeOut('slow');
          }
        });
      }
    });
  });
</script>
<script type="text/javascript">
  $(document).on('click', '.editstudent', function() {
    var editedId = $(this).attr("id");
    var newAcademicYear=$(this).attr("value");
    $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>student/editstudent/",
      data: ({
        editedId: editedId,
        newAcademicYear:newAcademicYear
      }),
      cache: false,
      beforeSend: function() {
        $('.listStudentShow').html( '<img src="<?php echo base_url() ?>img/loader.gif" alt="" width="74" height="74" id="loa">');
      },
      success: function(html) {
        $(".listStudentShow").html(html);
      }
    });
  });
</script>
<script type="text/javascript">
  $(document).on('click', '.viewStudentPrint', function() {
    var editedId = $(this).attr("id");
    $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>student/viewStudentPrint/",
      data: ({
        editedId: editedId
      }),
      cache: false,
      beforeSend: function() {
        $('.StudentViewPrintHere').html( '<img src="<?php echo base_url() ?>img/loader.gif" alt="" width="74" height="74" id="loa">');
      },
      success: function(html) {
        $(".StudentViewPrintHere").html(html);
      }
    });
  });
</script>
<script type="text/javascript">
  function codespeedyStudentView(){
    var print_div = document.getElementById("StudentViewPrintHere");
    var print_area = window.open();
    print_area.document.write(print_div.innerHTML);
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" type="text/css" />');
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css" type="text/css" />');
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css" type="text/css" />');
    print_area.document.close();
    print_area.focus();
    print_area.print();
  }
</script>
<script type="text/javascript">
  $(document).on('click', '.resetPassword', function() {
    var editedId = $(this).attr("id");
    $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>student/resetPassword/",
      data: ({
        editedId: editedId
      }),
      cache: false,
      beforeSend: function() {
        $('.resetPasswordInfo').html( 'Reseting...');
      },
      success: function(html) {
        $(".resetPasswordInfo").html(html);
      }
    });
  });
</script>
<script type="text/javascript">
  $(document).on('submit', '#updateStuForm', function(e) {
    e.preventDefault();
    $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>student/updateStudents/",
      data:new FormData(this),
      processData:false,
      contentType:false,
      cache: false,
      async:false,
      beforeSend: function() {
        $('.resetPasswordInfo').html( '<span class="text-info">Updating...</span>');
      },
      success: function(html){
         $(".resetPasswordInfo").html(html);
      }
    });
  });
</script>
<script type="text/javascript">
  $(document).on('click', '#savenewstudent', function() {
    var fathermobile=$("#fathermobile").val();
    var fname=$("#fname").val();
    var lname=$("#lname").val();
    var gfname=$("#gfname").val();
    var gender=$("#gender").val();
    var profile=$("#profile").val();
    var usertype=$("#usertype").val();
    var mobile=$("#mobile").val();
    var email=$("#email").val();
    var grade=$("#grade").val();
    var branch=$("#branch").val();
    var stuid=$("#stuid").val();
    var sec=$("#sec").val();
    var dob=$("#dob").val();
    var city=$("#city").val();
    var subcity=$("#subcity").val();
    var woreda=$("#woreda").val();
    var password=$("#password").val();
    var password2=$("#password2").val();
    var academicyear=$("#academicyear").val();
    if ($('#fname').val() != '' && $('#lname').val() != '' && $('#gfname').val() != '' && $('#grade').val() != '' && $('#sec').val() != ''  && $('#password').val() != ''  && $('#password2').val() != '') {
      if($('#password').val()==$('#password2').val()){
      $.ajax({
        url: "<?php echo base_url(); ?>register_new_student/",
        method: "POST",
        data: ({
          fathermobile: fathermobile, fname: fname, 
          lname: lname, gfname: gfname,gender: gender,
          usertype: usertype,branch: branch,stuid:stuid,
          profile: profile, mobile: mobile,
          email: email,grade: grade, sec: sec,dob: dob,
          city: city, subcity: subcity,woreda: woreda,
          password: password, password2: password2,
          academicyear: academicyear,
        }),
        cache: false,
        beforeSend: function() {
          $('#msg').html( '<img src="<?php echo base_url() ?>img/loader.gif" alt="" width="74" height="74" id="loa">'
            );
        },
        success: function(html) {
          $('#msg').html(html);
        }
      });
    }else{
      swal('Password does not match!', {
        icon: 'error',
      });
    }
    }else{
      swal('Please fill all fields!', {
        icon: 'error',
      });
    }
  });
</script>
<script>
  $(document).ready(function() { 
    function nofstudents(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>nOfStudents/",
        method: "POST",
        data: ({
            view: view
        }),
        success: function(html) {
          $('.nofstudents').html(html);
        }
      });
    }
    function last_student_ID(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>last_student_ID/",
        method: "POST",
        data: ({
            view: view
        }),
        success: function(html) {
          $('.lastID').html(html);
        }
      });
    } 
    function unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_notification/",
        method: "POST",
        data: ({
            view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.notification-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-notification').html(data.unseen_notification);
          }
        }
      });
    }  
    function inbox_unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
        method: "POST",
        data: ({
            view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.inbox-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-inbox').html(data.unseen_notification);
          }
        }
      });
    }
    nofstudents();
    unseen_notification();
    inbox_unseen_notification();
    last_student_ID();
    $(document).on('click', '.seen_noti', function() {
        $('.count-new-notification').html('');
        inbox_unseen_notification('yes');
    });
    $(document).on('click', '.seen', function() {
        $('.count-new-inbox').html('');
        inbox_unseen_notification('yes');
    });
    setInterval(function() {
      unseen_notification();
      inbox_unseen_notification();
      last_student_ID();
      nofstudents();
    }, 5000);
  });
  </script>
</html>