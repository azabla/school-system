         <div class="sidebar-brand">
          <a href="#"> <img alt="image" src="<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>" style="height:35px;width:35px;border-radius: 3em;" class="header-logo" /> 
              <!-- <span class="logo-name"> 
                <?php foreach($schools as $school) {
                  echo $school->name;} ?>
              </span> -->
            </a>
          </div>
          <ul class="sidebar-menu">
            <li class="dropdown">
              <a href="<?php echo base_url(); ?>dashboard/?dashboard-page/" class="nav-link">
                <i data-feather="monitor"></i><span>Dashboard</span></a>
            </li>
            <li class="dropdown">
              <a href="<?php echo base_url(); ?>home/?admin-home-page/" class="nav-link"><i data-feather="home"></i><span>Home</span></a>
            </li>
            <?php if($_SESSION['usertype']==='superAdmin'){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="user-plus"></i><span>Manage User Group</span>
              </a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="<?php echo base_url(); ?>usergroup/">Add User Group</a>
                </li>
                <li><a class="nav-link" href="<?php echo base_url(); ?>userpermission/">User Permission</a>
                </li>
              </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){  ?>
            <li class="dropdown">
               <a href="" class="menu-toggle nav-link has-dropdown"><i data-feather="users"></i><span>Student(s)</span>
                </a>
              <ul class="dropdown-menu">
                <?php $uperStuDE=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentDE' order by id ASC ");  if($uperStuDE->num_rows()>0){  ?>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>student/">Manage Student</a>
                  </li>
                <?php } $uperStupro=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentPr' order by id ASC ");  if($uperStupro->num_rows()>0){ ?>
                  <li><a class="nav-link" href="<?php echo base_url() ?>registration/">Student Promotion</a>
                  </li>
                <?php } $uperStuPl=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentPl' order by id ASC ");  if($uperStuPl->num_rows()>0){ ?>
                  <li class="dropdown">
                    <a href="" class="menu-toggle nav-link has-dropdown"><span>Student Placement</span>
                    </a>
                    <ul class="dropdown-menu">
                      <li><a class="nav-link" href="<?php echo base_url(); ?>manualplacement/">Manual Placement</a>
                      </li>
                      <li><a href="<?php echo base_url(); ?>automaticplacement/" class="nav-link">Automatic Placement</a>
                      </li>
                    </ul>
                  </li>
                <?php } $uperStuPl=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='Studentbp' order by id ASC ");  if($uperStuPl->num_rows()>0){ ?>
                  <li> <a class="nav-link" href="<?php echo base_url(); ?>branchplacement/">Branch Placement</a> </li>
                <?php }  $uperStuView=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentVE' order by id ASC "); if($uperStuView->num_rows()>0){ ?>
                <li class="dropdown">
                  <a href="" class="menu-toggle nav-link has-dropdown"><span>Record Report</span>
                  </a>
                  <ul class="dropdown-menu">
                    <li>
                      <a class="nav-link" href="<?php echo base_url(); ?>divisinrecordreport/"><span>By Division</span>
                      </a>
                    </li>
                    <li>
                      <a class="nav-link" href="<?php echo base_url(); ?>graderecordreport/"><span>By Grade</span>
                      </a>
                    </li>
                    <li>
                      <a class="nav-link" href="<?php echo base_url(); ?>sectionrecordreport/"><span>By Section</span>
                      </a>
                    </li>
                    <li>
                      <a class="nav-link" href="<?php echo base_url(); ?>summaryrecordreport/"><span>Summary</span>
                      </a>
                    </li>
                  </ul>
                </li>
                <li class="dropdown">
                  <a href="" class="menu-toggle nav-link has-dropdown"><span>Transport Report</span>
                  </a>
                  <ul class="dropdown-menu">
                    <li>
                      <a class="nav-link" href="<?php echo base_url(); ?>gradetransportreport/"><span>By Grade</span>
                      </a>
                    </li>
                    <li>
                      <a class="nav-link" href="<?php echo base_url(); ?>sectiontransportreport/"><span>By Section</span>
                      </a>
                    </li>
                  </ul>
                </li>
                 <li> <a class="nav-link" href="<?php echo base_url(); ?>nosection/">No.of Section</a>
                </li>
                <li class="dropdown">
                  <a href="" class="menu-toggle nav-link has-dropdown"><span>Gender Report</span>
                  </a>
                  <ul class="dropdown-menu">                    
                    <li>
                      <a class="nav-link" href="<?php echo base_url(); ?>gradereport/"><span>By Grade</span>
                      </a>
                    </li>
                    <li>
                      <a class="nav-link" href="<?php echo base_url(); ?>report/"><span>By Section</span>
                      </a>
                    </li>
                  </ul>
                </li>
                <li class="dropdown">
                  <a href="" class="menu-toggle nav-link has-dropdown"><span>Phone Book</span>
                  </a>
                  <ul class="dropdown-menu">
                    <li> <a href="<?php echo base_url(); ?>gradephonebook/" class="nav-link">By Grade
                    </a>
                    </li>
                    <li> <a href="<?php echo base_url(); ?>phonebook/" class="nav-link">By Section
                    </a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>usernameandpassword/"><span>Username & Password</span>
                  </a>
                </li>
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>similaruserid/"><span>Similar UserId</span>
                  </a>
                </li>
              <?php } $gradeGroup=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='gradeGroup' order by id ASC "); if($gradeGroup->num_rows()>0){ ?>
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>gradegroup/"><span>Grade Group</span>
                  </a>
                </li>
              <?php } $uperStuDrop=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentDrop' order by id ASC "); if($uperStuDrop->num_rows()>0){ ?>
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>dropoutstudents/"><span>Dropout Students</span>
                  </a>
                </li>
              <?php } ?>
              </ul>
            </li>
          <?php }  $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' order by id ASC ");  
          if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
               <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="users"></i><span>Staffs & Placement</span>
                </a>
              <ul class="dropdown-menu">
                <?php $userpStaffDe=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='staffDE' order by id ASC ");  
                if($userpStaffDe->num_rows()>0){ ?>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>staffs/">Staffs List</a> </li>
                <?php } $userpStaffDP=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='directorPl' order by id ASC "); if($userpStaffDP->num_rows()>0){ ?>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>directorplacement/">Director Placement</a> </li>
                <?php } $userpStaffTP=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='staffPl' order by id ASC "); if($userpStaffTP->num_rows()>0){ ?>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>placement/">Teacher Placement</a> </li>
                <?php } $userpStaffHrP=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='hoomeroomPl' order by id ASC "); if($userpStaffHrP->num_rows()>0){ ?>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>homeroomplacement/">Homeroom Placement</a> </li>
                <?php } $userpStaffPhone=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='staffPhone' order by id ASC "); if($userpStaffPhone->num_rows()>0) { ?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>staffphone/">Staffs phone List</a> </li>
                <?php } ?>
              </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='Subject' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
              <li class="dropdown">
               <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="book"></i><span>Subject(s)</span>
                </a>
                <ul class="dropdown-menu">
                  <li><a class="nav-link" href="<?php echo base_url(); ?>subject/">Grade Subject(s) List</a>
                  </li>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>ordersubject/">Subject(s) Order</a>
                  </li>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>kgsubject/">KG Subject(s) List</a>
                  </li>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>subjectobjectives/">KG Subject(s) Objectives</a>
                  </li>
                </ul>
              </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='IDCard' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
               <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="list"></i><span>ID Card</span>
                </a>
              <ul class="dropdown-menu">
                 <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='IDCard' and allowed='StaffIDCard' order by id ASC ");  
                 if($usergroupPermission->num_rows()>0){ ?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>staffidcard/">Staff ID</a>
                </li>
              <?php } ?>
              <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='IDCard' and allowed='StudentIDCard' order by id ASC ");if($usergroupPermission->num_rows()>0){ ?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>idcard/">Student ID</a>
                </li>
              <?php } ?>
              </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='Evaluation' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>evaluation/"><i data-feather="briefcase"></i><span>Evaluation</span>
              </a>
            </li>
            <?php }  $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Attendance' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <i data-feather="user-check"></i>
                <span>Attendance</span>
              </a>
            <ul class="dropdown-menu">
              <?php $userPerStuAtt=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Attendance' and allowed='studentAttendance' order by id ASC ");  if($userPerStuAtt->num_rows()>0){ ?>
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>attendance/"><i data-feather="user-check"></i>
                <span>Student Attendance</span>
              </a>
             </li>
             <?php } $userPerStaAtt=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Attendance' and allowed='staffAttendance' order by id ASC ");  if($userPerStaAtt->num_rows()>0){?>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>staffattendance/">
                <i data-feather="user-check"></i>
                <span>Staff Attendance</span>
              </a>
             </li>
           <?php }  ?>
             </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='communicationbook' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>communicationbook/?admin-communication-book/"><i data-feather="message-square"></i><span>Communication Book</span>
              </a>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='lessonplan' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <i data-feather="book-open"></i>
                <span>Manage Lesson Plan</span>
              </a>
            <ul class="dropdown-menu">
              <?php $upAddLplan=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='lessonplan' and allowed='addlessonplan' order by id ASC ");  if($upAddLplan->num_rows()>0){ ?>
              <li>
                <a class="nav-link" href="<?php echo base_url(); ?>dailylessonplan/?daily-lesson-plan-page/">
                  <span>Daily Lesson Plan</span>
                </a>
              </li>
              <li>
                <a class="nav-link" href="<?php echo base_url(); ?>addlessonplan/?lesson-plan-page/">
                  <span>Add Annual Lesson Plan</span>
                </a>
              </li>
            <?php } $upViewLplan=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='lessonplan' and allowed='viewlessonplan' order by id ASC ");  if($upViewLplan->num_rows()>0){?>
              <li>
                <a class="nav-link" href="<?php echo base_url(); ?>viewlessonplan/">
                  <span>View Annual Lesson Plan</span>
                </a>
              </li>
            <?php } ?>
            </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='homeworkworksheet' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <i data-feather="book-open"></i>
                <span>Homework/Worksheet</span>
              </a>
            <ul class="dropdown-menu">
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>addlesson/">
                <span>Add HW/Worksheet</span>
              </a>
             </li>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>viewlesson/">
                <span>View HW/Worksheet</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>viewansweredworksheet/">
                <span>Answered Worksheet</span>
              </a>
             </li>
             </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='studentexam' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
             <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <i data-feather="code"></i>
                <span>Exam</span>
              </a>
            <ul class="dropdown-menu">
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>exam/">
                <i data-feather="code"></i>
                <span>Add Exam</span>
              </a>
             </li>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>viewexam/"><i data-feather="code"></i>
                <span>View Exam</span>
              </a>
             </li>
             </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <i data-feather="layout"></i><span>Mark</span>
              </a>
            <ul class="dropdown-menu">
              <?php $markformat=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='studentmarkformat' order by id ASC ");  if($markformat->num_rows()>0){ ?>
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>exportmarkformat/">
                <span>Prepare Mark Format</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>exportmanualmarkformat/?admin-manual-mark-format-page/">
                <span>Manual Mark Format</span>
              </a>
             </li>
              <?php } $uaddMark=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='addstudentmark' order by id ASC ");  if($uaddMark->num_rows()>0){ ?>
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>adjusttable/">
                <span>Adjust Table For Mark</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>addexam/">
                <span>Add New result(Online)</span>
              </a>
             </li>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>addmark/">
                <span>Edit/Delete Mark result</span>
              </a>
            </li>
          <?php } $approveMark=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='approvemark' order by id ASC ");  
          if($approveMark->num_rows()>0){ ?>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>approvemark/">
                <span>Approve Mark</span>
              </a>
            </li>
           <?php } $uaddMark=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='viewstudentmark' order by id ASC ");  if($uaddMark->num_rows()>0){ ?>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>ngmarkresult/">
                <span>View NG/Zero Result</span>
              </a>
              </li>
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>rowmarkresult/">
                <span>Raw Mark Result</span>
              </a>
              </li>
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>markresult/">
                <span>View Mark Result</span>
              </a>
              </li>
              <li class="dropdown">
                <a href="" class="menu-toggle nav-link has-dropdown"><span>Mark Result Analysis</span>
                </a>
                <ul class="dropdown-menu">
                  <li>
                    <a class="nav-link" href="<?php echo base_url(); ?>subjectmarkanalysis/"><span>By Subject</span>
                    </a>
                  </li>
                  <li>
                    <a class="nav-link" href="<?php echo base_url(); ?>markanalysis/"><span>By Assesment</span>
                    </a>
                  </li>
                </ul>
              </li>
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>markprogress/">
                <span>Mark Progress</span>
              </a>
              </li>
              <?php } $userpStaffAI=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='activeInactiveDiv' order by id ASC "); if($userpStaffAI->num_rows()>0){ ?>
              <li>
                <a class="nav-link" href="<?php echo base_url(); ?>markstatus/">
                  <span>Lock Division</span>
                </a>
              </li>
              <?php } $userpStaffAI=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='lockstudentmark' order by id ASC "); if($userpStaffAI->num_rows()>0){ ?>
                <li>
                <a class="nav-link" href="<?php echo base_url(); ?>lockunlockstudentmark/?lock-unlock-page">
                  <span>Lock/Unlock Mark</span>
                </a>
              </li>
              <?php } ?>
             </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='studentbasicskill' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>

              <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
              <i data-feather="clipboard"></i><span>Basic Skill & Conduct</span>
              </a>
            <ul class="dropdown-menu">
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>basicskill/"><span>Add BS Name & Type</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>exportbsformate/"><span>Export BS format</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>importbs/"><span>Import BS format</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>viewstudentbs/"><span>View Student BS</span>
              </a>
             </li>
             </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='ImportExport' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="arrow-down-circle"></i><span>Import & Export</span></a>
              <ul class="dropdown-menu">
                <?php $exportFile=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='ImportExport' and allowed='exportFile' order by id ASC ");  if($exportFile->num_rows()>0){ ?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>export/"><i data-feather="arrow-down-circle"></i>Export</a></li>
              <?php } $importFile=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='ImportExport' and allowed='importFile' order by id ASC ");  if($importFile->num_rows()>0){?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>import/"><i data-feather="arrow-up-circle"></i>Import</a></li>
              <?php } ?>
              </ul>
            </li>
             <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="grid"></i><span>Card & Roster</span></a>
              <ul class="dropdown-menu">
                 <?php $rpPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='reportcard' order by id ASC "); 
                  if($rpPermission->num_rows()>0){ ?>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>reportcard/">Grade Report Card</a></li>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>kgreportcard/">KG Report Card</a></li>
                <?php } $raPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='rankReport' order by id ASC "); 
                  if($raPermission->num_rows()>0){ ?>
                <li class="dropdown">
                  <a href="" class="menu-toggle nav-link has-dropdown"><span>Rank Report</span>
                  </a>
                  <ul class="dropdown-menu">
                    <li>
                      <a class="nav-link" href="<?php echo base_url(); ?>branchrankreport/"><span>By Branch</span>
                      </a>
                    </li>
                    <li>
                      <a class="nav-link" href="<?php echo base_url(); ?>graderankreport/"><span>By Grade</span>
                      </a>
                    </li>
                    <li>
                      <a class="nav-link" href="<?php echo base_url(); ?>rankreport/"><span>By Section</span>
                      </a>
                    </li>
                  </ul>
                </li>
                <?php } $roPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='roster' order by id ASC "); 
                  if($roPermission->num_rows()>0){ ?>
                    <li><a class="nav-link" href="<?php echo base_url(); ?>roster/">Student Roster</a></li>
                  <?php } $trPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='transcript' order by id ASC "); 
                  if($trPermission->num_rows()>0){ ?>
                    <li><a class="nav-link" href="<?php echo base_url(); ?>transcript/">Transcript</a></li>
                  <?php }  $stPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='Statistics' order by id ASC "); 
                  if($stPermission->num_rows()>0){ ?>
                    <li><a class="nav-link" href="<?php echo base_url(); ?>markstatistics/">Report Statistics</a></li>
                  <?php } ?>
              </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='feemanagment' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="dollar-sign"></i><span>Fee Management</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="<?php echo base_url(); ?>category/">Fee Category</a></li>
                <li><a class="nav-link" href="<?php echo base_url(); ?>payment/">Add Fee</a></li>
                <li><a class="nav-link" href="<?php echo base_url(); ?>paymentreport/">Fee Report</a></li>

                <li><a class="nav-link" href="<?php echo base_url(); ?>payroll/">Staff Payroll</a></li>
              </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='elibrary' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="activity"></i><span>Other Management</span></a>
              <ul class="dropdown-menu">
                <li>
                  <a class="nav-link" href="#">
                    <i data-feather="truck"></i><span>Transportation</span>
                  </a>
                </li>
                <li>
                  <a class="nav-link" href="#">
                    <i data-feather="book"></i><span>Inventory</span>
                  </a>
                </li>
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>library/">
                    <i data-feather="book"></i><span>E-Library</span>
                  </a>
                </li>
              </ul>
            </li>
            <?php } ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Messages</span></a>
              <ul class="dropdown-menu">
                <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='Chat' order by id ASC "); 
                if($usergroupPermission->num_rows()>0){ ?>
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>chat/">
                    Live Chat
                  </a>
                </li>
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>videochat/">
                    Video Chat
                  </a>
                </li>
                <li><a class="nav-link" href="<?php echo base_url(); ?>compose/">Compose</a></li>
                <?php }else{?>
                <?php } ?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>inbox/">Inbox</a></li>
                <li><a class="nav-link" href="<?php echo base_url(); ?>sent/">Sent</a></li>
              </ul>
            </li>
            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='schoolfiles' order by id ASC "); 
                if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="file"></i><span>School Files</span></a>
              <ul class="dropdown-menu">
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>schoolparents/"><i data-feather="users"></i><span>School Parents</span>
                  </a>
                </li>
                 <li>
                  <a class="nav-link" href="#"><i data-feather="gift"></i><span>School Award</span>
                  </a>
                </li>
              </ul>
            </li>
             <?php } ?>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>documents/"><i data-feather="file"></i><span>My Documents</span>
              </a>
            </li>
             <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='websitemanagment' order by id ASC "); if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="link"></i><span>Website Managment</span></a>
              <ul class="dropdown-menu">
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>photogallery/"><i data-feather="image"></i><span>Gallery</span>
                  </a>
                </li>
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>employment/"><i data-feather="user-plus"></i><span>Vacancy</span>
                  </a>
                </li>
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>blog/">
                    <i data-feather="external-link"></i><span>News</span>
                  </a>
                </li>
              </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='taskspage' order by id ASC "); if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <i data-feather="activity"></i>
                <span>Tasks</span>
              </a>
            <ul class="dropdown-menu">
              <li>
              <a class="nav-link" href="#">
                <span>Competition</span>
              </a>
              </li>
              <li>
                <a class="nav-link" href="<?php echo base_url() ?>lineupschedule/">
                  <span>LineUp Schedule </span>
                </a>
              </li>
              <li>
                <a class="nav-link" href="<?php echo base_url() ?>timetable/">
                  <span>Generate TimeTable </span>
                </a>
              </li>
              <li>
              <a class="nav-link" href="#">
                <span>Certificate of the student </span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="#">
                <span>Appointment Letter</span>
              </a>
             </li>

            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <span>Exam Schedule</span></a>
              <ul class="dropdown-menu">
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>examscheduler/">
                    <span>Generate Schedule</span>
                  </a>
                </li>
                <li>
                  <a class="nav-link" href="<?php echo base_url(); ?>viewexamscheduler/">
                    <span>View Exam Schedule</span>
                  </a>
                </li>
              </ul>
            </li>
             <li>
              <a class="nav-link" href="<?php echo base_url() ?>experience/">
                <span>Employee Experience</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="#">
                <span>Sporting events </span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="#">
                <span>Classroom schedules </span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="#">
                <span>Field trip schedules</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="#">
                <span>Themes</span>
              </a>
             </li>
             
             </ul>
            </li>
            <?php } ?>
              
              <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='summerclass' order by id ASC "); if($usergroupPermission->num_rows()>0){ ?>
              <li>
                <a class="nav-link" href="<?php echo base_url(); ?>summerclass/?admin-summer-class-page/"><i data-feather="user-plus"></i><span>Summer class</span>
                </a>
              </li>
              <?php }  $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='teacherperformance' order by id ASC "); if($usergroupPermission->num_rows()>0){ ?>
              <li>
                <a class="nav-link" href="<?php echo base_url(); ?>teachersperformance/?admin-teacher-performance-page/"><i data-feather="user-plus"></i><span>Teacher Performance</span>
                </a>
              </li>
              <?php } if($_SESSION['usertype']==='superAdmin'){ ?>
              <li>
                <a class="nav-link" href="<?php echo base_url(); ?>setting/"><i data-feather="settings"></i><span>Setting</span>
                </a>
              </li>
              <li>
                <a class="nav-link" href="<?php echo base_url(); ?>loggeduser/"><i data-feather="log-in"></i><span>Logs</span>
                </a>
              </li>
            <?php } ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="moon"></i><span>Dark Mode</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="#">
                  <label class="selectgroup-item">
                    <input type="radio" id="changecolor" name="value" value="1" class="selectgroup-input-radio select-layout" checked>
                    <i data-feather="sun"></i>Light
                  </label></a>
                </li>
                <li><a class="nav-link" href="#">
                  <label class="selectgroup-item">
                    <input type="radio" id="changecolor" name="value" value="2" class="selectgroup-input-radio select-layout">
                   <i data-feather="moon"></i> Dark
                  </label></a>
                </li>
              </ul>
            </li>
          </ul>