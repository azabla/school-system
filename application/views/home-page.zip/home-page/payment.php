<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
   <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
  </title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/custom.css">
<link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
       <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="row">
              <div class="col-12">
                <form action="<?php echo base_url()?>payment/" method="POST">
                      <?php if(isset($_SESSION['success'])){ ?>
                          <span class="text-success">
                              <?php echo $_SESSION['success']; ?>
                          </span>
                          <?php  }
                          elseif(isset($_SESSION['error'])) { ?>
                          <span class="text-danger">
                              <?php echo $_SESSION['error']; ?>  
                          </span>
                      <?php } ?>
                    <div class="row">
                      <div class="col-lg-2">
                       <div class="form-group">
                        <label for="Mobile">Select Grade</label>
                         <select class="form-control selectric"
                         required="required" name="gradesec" 
                         id="gradesec">
                         <option></option>
                          <?php foreach($gradesec as $gradesecs){ ?>
                            <option value="<?php echo $gradesecs->gradesec;?>">
                            <?php echo $gradesecs->gradesec;?>
                            </option>
                          <?php }?>
                         </select>
                        </div>
                      </div>
                      <div class="col-lg-3">
                        <div class="form-group">
                      <label for="Mobile">Payment Receipt</label>
                         <input type="text" required="required" name="receipt" class="form-control">
                        </div>
                     </div>
                     <div class="col-lg-3">
                        <div class="form-group">
                      <label for="Mobile">Select Payment Type</label>
                         <select class="form-control selectric"
                         required="required" name="ptype" 
                         id="ptype">
                         <option></option>
                          <?php foreach($payment_category as $payment_categorys){ ?>
                            <option value="<?php echo $payment_categorys->name;?>">
                            <?php echo $payment_categorys->name;?>
                            </option>
                          <?php }?>
                         </select>
                        </div>
                     </div>
                     <div class="col-lg-2">
                        <div class="form-group">
                        <label for="Mobile">Select Month</label>
                         <select class="form-control selectric"
                         required="required" name="month" 
                         id="month">
                         <option></option>
                          <?php foreach($month as $months){ ?>
                            <option value="<?php echo $months->name;?>">
                            <?php echo $months->name;?>
                            </option>
                          <?php }?>
                         </select>
                        </div>
                     </div>
                    <div class="col-lg-2">
                        <div class="form-group">
                         <label for="ac">Academic year</label>
                          <select class="form-control selectric"
                            required="required" name="acy" 
                            id="acy">
                            <?php foreach($academicyear as $academicyears){ ?>
                              <option>
                                <?php echo $academicyears->year_name ?>
                              </option>
                            <?php } ?>
                          </select>
                            <span class="text-danger"> 
                            <?php echo form_error('acg'); ?>
                            </span>
                        </div>
                     </div>
                  </div>
                  <div class="list card-body">
                  </div>
                </form>
                <div class="card">
                  <div class="card-header">
                   <h4>Paid List</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <form action="<?php echo base_url()?>payment/" method="POST">
                      <table class="table table-striped table-hover" id="tableExport" style="width:100%;">
                        <thead>
                          <tr>
                            <th>Student Name</th>
                            <th>Grade</th>
                            <th>Payment Type</th>
                            <th>Paid Month</th>
                            <th>Receipt</th>
                            <th>Status</th>
                            <th>Date Inserted</th>
                            <th>User</th>
                            <th>Method</th>
                            <th>Delete</th>
                          </tr>
                        </thead>
                        <tbody>
                           <?php foreach($payment as $payments){ ?>
                          <tr>
                            <td><img src="<?php echo base_url(); ?>/profile/<?php echo $payments->profile; ?>"style="width: 23px;height: 23px;border-radius: 3em;"> <?php echo $payments->fname;echo ' ';echo $payments->mname ?></td>
                            <td><?php echo $payments->gradesecc; ?></td>
                            <td><?php echo $payments->paymentype; ?></td>
                            <td><?php echo $payments->month; ?></td>
                            <td><?php echo $payments->payment_receipt; ?></td>
                            <td><span class="text-success">
                              <i data-feather="check"></i>Paid</span>
                           </td>
                            <td><?php echo $payments->date_created; ?></td>
                            <td><?php echo $payments->byuser; ?></td>
                            <td><?php echo $payments->method; ?></td>
                            <td>
                              <button type="submit" 
                              onclick="return confirm('Are you sure you want to delete this Payment ?')"
                              value="<?php  echo $payments->pid; ?>" name="deletepayment" class="btn btn-danger">Delete</button>
                            </td>
                          </tr>
                          <?php }?>
                        </tbody>
                      </table>
                    </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
      <footer class="main-footer">
        <div class="footer-left">
         Call:+251967829025 &nbsp;&nbsp;
          Copyright &copy<?php echo date('Y');?>
          <a href="https://www.grandstande.com" target="_blanck">GrandStand</a>
          All rights are Reserved.
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
<script type="text/javascript">
     $(document).ready(function() {  
        $("#gradesec").bind("change", function() {
            $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>Filter_gradesec_for_payment/",
                data: "gradesec=" + $("#gradesec").val(),
                 beforeSend: function() {
                    $('.list').html(
                        '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">'
                    );
                },
                success: function(data) {
                    $(".list").html(data);
                }
            });
        });
    });
</script>
  
<script>
    $(document).ready(function() {  
    function unseen_notification(view = '') { 
            $.ajax({
                url: "<?php echo base_url() ?>fetch_unseen_notification/",
                method: "POST",
                data: ({
                    view: view
                }),
                dataType: "json",
                success: function(data) {
                    $('.notification-show').html(data.notification);
                    if (data.unseen_notification > 0) {
                        $('.count-new-notification').html(data.unseen_notification);
                    }
                }
            });
        }  
        function inbox_unseen_notification(view = '') { 
            $.ajax({
                url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
                method: "POST",
                data: ({
                    view: view
                }),
                dataType: "json",
                success: function(data) {
                    $('.inbox-show').html(data.notification);
                    if (data.unseen_notification > 0) {
                        $('.count-new-inbox').html(data.unseen_notification);
                    }
                }
            });
        }
        unseen_notification();
        inbox_unseen_notification();
        $(document).on('click', '.seen_noti', function() {
            $('.count-new-notification').html('');
            inbox_unseen_notification('yes');
        });
        $(document).on('click', '.seen', function() {
            $('.count-new-inbox').html('');
            inbox_unseen_notification('yes');
        });
        setInterval(function() {
          unseen_notification();
          inbox_unseen_notification();
        }, 5000);

    });
    </script>
</body>

</html>