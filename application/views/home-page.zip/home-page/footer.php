<footer class="main-footer">
        <div class="footer-left">
         Call:+251967829025 &nbsp;&nbsp;
          Copyright &copy <?php echo date('Y');?>
          <a href="https://www.grandstande.com" target="_blanck">Myschool SMS (Grandstande Inc.)</a>
          All rights are Reserved.
        </div>
        <div class="footer-right">
                <small class="badge badge-info">Software Level: Premium</small>
        </div>

</footer>