<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
   <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <link rel="stylesheet" href="<?php  echo base_url(); ?>assets/css/pretty-checkbox.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/izitoast/css/iziToast.min.css">
  <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
       <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <?php include('bgcolor.php'); ?>
            <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">
            <div class="card">
            <div class="card-body">
                <ul class="nav nav-tabs" id="myTab2" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link" id="home-tab1" data-toggle="tab" href="#startSummerClassPage" role="tab" aria-selected="true"> Start Sum. class</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" id="home-tab2" data-toggle="tab" href="#SummerClassStudent" role="tab" aria-selected="true"> Student</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="home-tab3" data-toggle="tab" href="#SummerClassSubject" role="tab" aria-selected="true"> Subject</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="home-tab4" data-toggle="tab" href="#SummerClassEvaluation" role="tab" aria-selected="true"> Evaluation</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="home-tab5" data-toggle="tab" href="#SummerPlacement" role="tab" aria-selected="true"> Teacher Placement</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="home-tab6" data-toggle="tab" href="#SummerClassMark" role="tab" aria-selected="true"> Mark</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="home-tab7" data-toggle="tab" href="#summerReportCard" role="tab" aria-selected="false">Card</a>
                  </li>
                </ul>
                <div class="tab-content tab-bordered" id="myTab3Content">
                  <div class="tab-pane fade show" id="startSummerClassPage" role="tabpanel" aria-labelledby="home-tab1">
                    <div id="listSummerClassStatus"></div>
                  </div>
                  <div class="tab-pane fade show active" id="SummerClassStudent" role="tabpanel" aria-labelledby="home-tab2">
                    <div class="row">
                      <div class="col-2">
                        <div class="list-group" id="list-tab" role="tablist">
                          <a class="list-group-item list-group-item-action active" id="list-view-student" data-toggle="list" href="#list-viewstu" role="tab">
                          View Student
                          </a>
                          <a class="list-group-item list-group-item-action" id="list-import-student" data-toggle="list" href="#list-importstudent" role="tab">
                          Import Student
                          </a>
                        </div>
                      </div>  
                      <div class="col-10">
                        <div class="tab-content" id="nav-tabContent">
                          <!-- view student starts -->
                          <div class="tab-pane fade show active" id="list-viewstu" role="tabpanel" aria-labelledby="list-view-student">
                            <form method="POST" id="comment_formSummer">
                              <div class="row">
                                <div class="col-lg-2 col-6">
                                   <div class="form-group">
                                     <select class="form-control selectric" required="required" name="academicyear" id="grands_academicyearSummer">
                                      <?php foreach($academicyear as $academicyears){ ?>
                                        <option value="<?php echo $academicyears->year_name;?>">
                                        <?php echo $academicyears->year_name;?>
                                        </option>
                                      <?php }?>
                                     </select>
                                    </div>
                                   </div>
                                   <div class="col-lg-3 col-6">
                                    <div class="form-group">
                                     <select class="form-control"
                                     required="required" name="branch"
                                     id="grands_branchitSummer">
                                     <option>--- Branch ---</option>
                                      <?php foreach($branch as $branchs){ ?>
                                        <option value="<?php echo $branchs->name;?>">
                                        <?php echo $branchs->name;?>
                                        </option>
                                      <?php }?>
                                     </select>
                                    </div>
                                   </div>
                                   <div class="col-lg-3 col-6">
                                    <div class="form-group">
                                     <select class="form-control grands_gradesecSummer" required="required" name="gradesec" id="grands_gradesecSummer">
                                     <option>--- Grade ---</option>
                                     </select>
                                    </div>
                                   </div>
                                 <div class="col-lg-2 col-6">
                                  <button class="btn btn-primary btn-lg btn-block" 
                                  type="submit" name="viewmark">View</button>
                                </div>
                              </div>
                            </form>
                            <div class="listSummerStudentShow table-responsive" id="student_view" style="height:40vh;"></div>
                          </div>
                          <div class="tab-pane fade show" id="list-importstudent" role="tabpanel" aria-labelledby="list-import-student">
                            <form id="uploadSummerStudent" method="post" enctype="multipart/form-data">
                              <div class="row">
                                <div class="form-group">
                                  <div class="col-lg-4">
                                       
                                    <div id="image-preview" class="image-preview">
                                      <label for="addmark" id="image-label">Choose File
                                        <i data-feather="paperclip"></i>
                                      </label>
                                      <input type="file" required="required" name="importSummerClassStudent" id="importSummerClassStudent"/>
                                    </div>
                                    
                                  </div>
                                </div>
                                <div class="col-lg-4">
                                  <button type="submit" name="insertSummerStudent" id="insertSummerStudent" class="btn btn-outline-primary"> Save student </button>
                                </div>
                                <div class="col-lg-4" id="importStudentInfo"> </div>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="dropdown-divider"></div>
                  </div>
                  <div class="tab-pane fade show" id="SummerClassSubject" role="tabpanel" aria-labelledby="home-tab3">
                    <form method="POST" id="saveNewSummerSubject">
                      <div class="row">
                        <div class="col-lg-4 col-6">
                          <div class="form-group">
                            <label for="Mobile">Subject Name</label>
                            <input class="form-control summerSubjectName" id="summerSubjectName" required="required" type="text" placeholder="Subject name here">
                          </div>
                        </div>
                        <div class="col-lg-6 col-6 table-responsive" id="summerGrade" style="height: 20vh;">
                          <label for="Mobile"><h6>Grade</h6></label>
                          <div class="row">
                            <?php foreach($grade as $grades){ ?>
                            <div class="col-lg-6">
                              <div class="form-group">
                                <?php echo $grades->grade; ?>
                                <div class="pretty p-icon p-jelly p-round p-bigger">
                                  <input type="checkbox" name="summerSubjectGrade" value="<?php echo $grades->grade; ?>" id="customCheck1 summerSubjectGrade">
                                  <div class="state p-info">
                                    <i class="icon material-icons"></i>
                                    <label></label>
                                  </div>
                                </div>
                                #
                                <div class="pretty p-icon p-jelly p-round p-bigger">
                                  <input type="checkbox" name="summerSubjectLetter" value="#" id="customCheck1 summerSubjectLetter">
                                  <div class="state p-info">
                                    <i class="icon material-icons"></i>
                                    <label></label>
                                  </div>
                                </div>
                                A
                                <div class="pretty p-icon p-jelly p-round p-bigger">
                                  <input type="checkbox" name="summerSubjectLetter" value="A" id="customCheck1 summerSubjectLetter">
                                  <div class="state p-info">
                                    <i class="icon material-icons"></i>
                                    <label></label>
                                  </div>
                                </div>
                              </div>
                              <hr>
                            </div>
                            <?php } ?>
                          </div>
                        </div>
                        <div class="col-lg-2 col-12">
                          <div class="form-group">
                            <button type="submit" name="postSummerSubject" class="btn btn-primary btn-block"> Save subject
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                    <div class="summerSubjectList table-responsive" id="summerSubjecttshere" style="height: 30vh;"></div>
                  </div>
                  <div class="tab-pane fade show" id="SummerClassEvaluation" role="tabpanel" aria-labelledby="home-tab4">
                    <form id="saveSummerevaluation" method="POST">
                      <div class="row">
                        <div class="col-lg-3 col-6">
                          <div class="form-group">
                            <label for="evname">Evaluation Name</label>
                            <input class="form-control summerevaName" name="summerevaName" type="text" placeholder="Evaluation name (Test,Final)...">
                          </div>
                         </div>
                        <div class="col-lg-3 col-6">
                          <div class="form-group">
                            <label for="Mobile">Percentage
                            </label>
                            <input class="form-control summerevaPercent" name="summerevaPercent" type="text" placeholder="Value here(In Number)...">
                          </div>
                        </div>
                        <div class="col-lg-4 col-12 table-responsive" style="height: 100px;">
                          <div class="form-group">
                            <label for="Mobile">Select grade</label><br>
                            <div class="row">
                            <?php foreach($grade as $grades){ ?>
                              <div class="col-lg-6">
                              <div class="pretty p-icon p-jelly p-round p-bigger">
                               <input id="summerevaGrade" type="checkbox" name="summerevaGrade" value="<?php echo $grades->grade; ?>">
                               <div class="state p-info">
                                  <i class="icon material-icons"></i>
                                  <label></label>
                               </div>
                               </div>
                                <?php echo $grades->grade; ?>
                                <div class="dropdown-divider2"></div>
                              </div>
                            <?php } ?>
                          </div>
                          </div>
                        </div>
                        <div class="col-lg-2 col-12 pull-right">
                          <button type="submit" name="postSummerEvaluation" class="btn btn-primary btn-block">Save Evaluation
                          </button>
                            <a href="#" class="saveSummerInfo"></a>
                        </div>
                      </div>
                    </form>
                    <div class="table-responsive" id="summerEvaluationData" style="height: 40vh;"></div>
                  </div>
                  <div class="tab-pane fade show" id="SummerPlacement" role="tabpanel" aria-labelledby="home-tab5">
                    <form id="saveSummerPlacement" method="POST">
                      <div class="row">
                        <div class="form-group col-lg-2 col-6">
                          <div class="form-group">
                            <label for="Mobile">Academic Year</label>
                            <select class="form-control selectric" required="required" name="summerAcademicyear" id="summerAcademicyear">
                            <?php foreach($academicyear as $academicyears){ ?>
                              <option><?php echo $academicyears->year_name ?></option>
                            <?php } ?>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-4 col-6">
                         <div class="form-group">
                            <label for="Staff">
                            Select staff to assign </label>
                           <select class="form-control selectric" required="required" name="summerStaff" id="summerStaff">
                           <option></option>
                            <?php foreach($staffs as $staff) { ?>
                            <option value="<?php echo $staff->username;?>"><?php echo $staff->username;echo '(';
                            echo $staff->fname.' '.$staff->mname;echo ')';
                            ?></option>
                          <?php }?>
                           </select>
                         </div>
                        </div>
                        <div class="col-lg-3 col-12 table-responsive" style="height: 20vh;">
                          <div class="form-group">
                            <label for="Grade"> Select grade to assign</label><br>
                            <div class="row">
                              <?php foreach($gradesec as $gradesecs){ ?>
                              <div class="col-lg-6 col-6">
                                <div class="pretty p-icon p-jelly p-round p-bigger">
                                  <input type="checkbox" name="summerGradePlacement" value="<?php echo $gradesecs->gradesec;?>" class="summerGradePlacement" id="customCheck1">
                                  <div class="state p-info">
                                    <i class="icon material-icons"></i>
                                    <label></label>
                                  </div>
                                </div>
                                <?php echo $gradesecs->gradesec; ?>
                                <div class="dropdown-divider2"></div>
                              </div>
                              <?php } ?>
                            </div>
                          </div>
                        </div>
                        <div class="col-lg-3 col-12 table-responsive" style="height: 20vh;">
                          <div class="form-group">
                            <label for="subject">Select subject to assign </label><br>
                            <?php foreach($subjects as $subject){ ?>
                              <div class="pretty p-icon p-jelly p-round p-bigger">
                                  <input type="checkbox" name="summerSubject" value="<?php echo $subject->Subj_name;?>" class="summerSubject" id="customCheck1">
                                  <div class="state p-info">
                                    <i class="icon material-icons"></i>
                                    <label></label>
                                  </div>
                              </div><?php echo $subject->Subj_name ;?>
                              <div class="dropdown-divider2"></div>
                            <?php } ?>
                          </div>
                        </div>
                        <div class="col-lg-12 col-12 pull-right">
                          <div class="form-group">
                            <button type="submit" name="postSummerPlacement" class="btn btn-primary btn-block ">Save Placement </button>
                          </div>
                        </div>
                      </div>
                    </form>
                    <div class="fetchSummerPacement table-responsive" style="height: 40vh;"></div>
                  </div>
                  <div class="tab-pane fade show" id="SummerClassMark" role="tabpanel" aria-labelledby="home-tab6">
                    <div class="row">
                      <div class="col-2">
                        <div class="list-group" id="list-tab" role="tablist">
                          <a class="list-group-item list-group-item-action active" id="list-view-mark" data-toggle="list" href="#list-viewMark" role="tab">
                          View Mark
                          </a>
                          <a class="list-group-item list-group-item-action" id="list-add-mark" data-toggle="list" href="#list-addMark" role="tab">
                          Add Mark
                          </a>
                          <a class="list-group-item list-group-item-action" id="list-delete-mark" data-toggle="list" href="#list-deleteMark" role="tab">
                          Edit Mark
                          </a>
                          <a class="list-group-item list-group-item-action" id="list-export-mark" data-toggle="list" href="#list-exportMark" role="tab">
                          Export Format
                          </a>
                        </div>
                      </div>  
                      <div class="col-10">
                        <div class="tab-content" id="nav-tabContent">
                          <div class="tab-pane fade show active" id="list-viewMark" role="tabpanel" aria-labelledby="list-view-mark">
                            <form method="POST" id="summerMarkViewForm">
                              <div class="row">
                                  <div class="col-lg-3 col-6">
                                    <div class="form-group">
                                      <select class="form-control" required="required" name="SummerMarkBranch" id="SummerMarkBranch">
                                        <option>--- Branch ---</option>
                                          <?php foreach($branch as $branchs){ ?>
                                          <option value="<?php echo $branchs->name;?>">
                                            <?php echo $branchs->name;?>
                                          </option>
                                          <?php }?>
                                      </select>
                                    </div>
                                  </div>
                                <div class="col-lg-3 col-6">
                                  <div class="form-group">
                                    <select class="form-control summerMarkGradesec" required="required" name="summerMarkGradesec" id="summerMarkGradesec">
                                      <option>--- Grade ---</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="col-lg-4 col-6">
                                  <div class="form-group">
                                    <select class="form-control summerMarkSubject" name="summerMarkSubject" required="required">
                                      <option>--- Select Subject ---</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="col-lg-2 col-6">
                                  <button class="btn btn-primary btn-block" type="submit" name="viewSummerMark">View
                                  </button>
                                </div>
                              </div>
                            </form>
                            <div class="viewSummerMark table-responsive" id="viewSummerMark" style="height:40vh;"></div>
                          </div>
                          <div class="tab-pane fade show" id="list-addMark" role="tabpanel" aria-labelledby="list-add-mark">
                            <form id="uploadSummerMark" method="post" enctype="multipart/form-data">
                              <div class="row">
                                <div class="form-group">
                                  <div class="col-lg-4">
                                    <div id="image-preview" class="image-preview">
                                      <label for="uploadSummerStudentMark" id="image-label">Choose File
                                        <i data-feather="paperclip"></i>
                                      </label>
                                      <input type="file" required="required" name="uploadSummerMark" id="uploadSummerStudentMark"/>
                                    </div>
                                  </div>
                                </div>
                                <div class="col-lg-4">
                                  <button type="submit" name="insertSummerMark" id="insertSummerMark" class="btn btn-primary"> Save mark </button>
                                </div>
                                <div class="col-lg-4" id="uploadMarkInfo"> </div>
                              </div>
                            </form>
                          </div>
                          <div class="tab-pane fade show" id="list-deleteMark" role="tabpanel" aria-labelledby="list-delete-mark">
                            <form method="GET" id="deleteSummerMarkForm">
                              <div class="row">
                                <div class="col-lg-3 col-6">
                                  <div class="form-group">
                                   <select class="form-control selectric" required="required" name="deleteSummerMarkBranch" id="deleteSummerMarkBranch">
                                   <option>--- Branch ---</option>
                                    <?php foreach($branch as $branchs){ ?>
                                      <option value="<?php echo $branchs->name;?>">
                                      <?php echo $branchs->name;?>
                                      </option>
                                    <?php }?>
                                   </select>
                                  </div>
                                </div>
                                <div class="col-lg-3 col-6">
                                  <div class="form-group">
                                     <select class="form-control selectric deleteSummerMarkGradesec" required="required" name="deleteSummerMarkGradesec" id="deleteSummerMarkGradesec">
                                     <option>--- Grade ---</option>
                                     </select>
                                  </div>
                                </div>
                                <div class="col-lg-3 col-6">
                                  <div class="form-group">
                                    <select class="form-control deleteSummerMarkSubject" name="deleteSummerMarkSubject" required="required">
                                      <option>--- Select Subject ---</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="col-lg-2 col-6">
                                  <button class="btn btn-primary btn-block" 
                                  type="submit" name="viewmark">View</button>
                                </div>
                              </div>
                            </form>
                            <div class="deleteSummerMark table-responsive" id="deleteSummerMark" style="height:50vh;"></div>
                          </div>
                          <div class="tab-pane fade show" id="list-exportMark" role="tabpanel" aria-labelledby="list-export-mark">                            
                            <form method="POST" action="<?php echo base_url(); ?>summerclass/exportSummerMarkFormat/">
                              <div class="row">
                                <div class="col-lg-4 col-6">
                                  <div class="form-group">
                                    <select class="form-control selectric" required="required" name="SummerBranchFormat"  id="SummerBranchFormat">
                                     <option>--- Select Branch ---</option>
                                      <?php foreach($branch as $branchs){ ?>
                                        <option value="<?php echo $branchs->name;?>">
                                        <?php echo $branchs->name;?>
                                        </option>
                                      <?php }?>
                                     </select>
                                  </div>
                                </div>
                                <div class="col-lg-4 col-6">
                                  <div class="form-group">
                                    <select class="form-control" required="required" name="summerGradesecformat"  id="summerGradesecformat">
                                      <option>--- Select Grade ---</option>
                                    
                                    </select>
                                  </div>
                                </div>
                                <div class="col-lg-4 col-12">
                                  <button class="btn btn-primary btn-block" type="submit" name="gethisgradeSummerFormate">Get</button>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade show" id="summerReportCard" role="tabpanel" aria-labelledby="home-tab7">
                    <form method="POST" id="reportCardformSummer">
                      <div class="row">
                        <div class="col-lg-2 col-6">
                          <div class="form-group">
                            <select class="form-control selectric" required="required" name="summerRCAC" id="summerRCAC">
                              <?php foreach($academicyear as $academicyears){ ?>
                              <option value="<?php echo $academicyears->year_name;?>">
                                <?php echo $academicyears->year_name;?>
                              </option>
                              <?php }?>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-3 col-6">
                          <div class="form-group">
                            <select class="form-control" required="required" name="summerRCBR" id="summerRCBR">
                              <option>--- Branch ---</option>
                              <?php foreach($branch as $branchs){ ?>
                                <option value="<?php echo $branchs->name;?>">
                                <?php echo $branchs->name;?>
                                </option>
                              <?php }?>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-3 col-6">
                          <div class="form-group">
                            <select class="form-control summerRCGR" required="required" name="gradesec" id="summerRCGR">
                              <option>--- Grade ---</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-2 col-6">
                          <button class="btn btn-primary btn-block btn-lg" type="submit" name="viewreport">View</button>
                        </div>
                        <div class="col-lg-2">
                          <button class="btn btn-default pull-right" name="gethisSummerreport" onclick="codespeedy()">
                          <span class="text-black">
                            <i data-feather="printer"></i>
                          </span>
                          </button>
                        </div>
                      </div>
                    </form>
                    <div class="listSummerReportCard table-responsive" id="reportCardView" style="height:40vh;"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <form method="POST" id="comment_form_updateSummer">
        <div class="modal fade" id="editmarkSummer" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Edit Mark Value</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body" id="editmarkhere_gsSummer">
              </div>
              <div class="modal-footer bg-whitesmoke br">
                <button type="submit" name="updatesubject" class="btn btn-primary savegrandsubject">Save</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
      </form>
      </div>
      <footer class="main-footer">
        <div class="footer-left">
         Call:+251967829025 &nbsp;&nbsp;
          Copyright &copy<?php echo date('Y');?>
          <a href="https://www.grandstande.com" target="_blanck">Grandstand IT Solution Plc</a>
          All rights are Reserved.
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/izitoast/js/iziToast.min.js"></script>
</body>
<script type="text/javascript">
  function codespeedy(){
    var print_div = document.getElementById("reportCardView");
    var print_area = window.open();
    print_area.document.write(print_div.innerHTML);
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" type="text/css" />');
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css" type="text/css" />');
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css" type="text/css" />');
    print_area.document.close();
    print_area.focus();
    print_area.print();
  }
</script>
<script type="text/javascript">
  $('#reportCardformSummer').on('submit', function(event) {
    event.preventDefault();
    var gradesec=$('#summerRCGR').val();
    var branch=$('#summerRCBR').val();
    var reportaca=$('#summerRCAC').val();
      if ($('#summerRCGR').val() != '' && $('#summerRCBR').val() != '' ) {
        $.ajax({
          url: "<?php echo base_url(); ?>Summerclass/fetchSummerReportcard/",
          method: "POST",
          data: ({
            gradesec:gradesec,
            branch:branch,
            reportaca:reportaca
          }),
          async: false,
          cache: false,
          dataType: 'json',
          beforeSend: function() {
            $('.listSummerReportCard').html('Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
          },
          success: function(data) {
            $(".listSummerReportCard").html(data);
          }
        })
      }else {
        alert("All fields are required");
      }
  });
</script>
<script type="text/javascript">
  $(document).ready(function() {  
    $("#summerRCBR").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Summerclass/filterGradeFromBranch/",
        data: "branchit=" + $("#summerRCBR").val(),
        beforeSend: function() {
          $('#summerRCGR').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="64" height="64" id="loa">' );
        },
        success: function(data) {
          $("#summerRCGR").html(data);
        }
      });
    });
  });
</script>
<script>
  $('#comment_form_updateSummer').on('submit', function(event) {
    event.preventDefault();
    load_mark();
    var outof=$(".outofSummer").val();
    var mid=$(".midSummer").val();
    var value=$(".correct_mark_gsSummer").val();
    var gradesec=$(".gSecSummer").val();
    var year=$(".aYearSummer").val();
    var branch=$(".gsBranchSummer").val();
    function load_mark(){
      $.ajax({
        method:"POST",
        url:"<?php echo base_url() ?>Summerclass/FetchUpdatedMark/",
        data: ({
          mid: mid,
          gradesec:gradesec,
          year:year,
          branch:branch
        }),
        cache: false,
        beforeSend: function() {
          $('.jossMarkSummer'+mid).html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="14" height="14" id="loa">'
          );
        },
        success:function(html){
          $('.jossMarkSummer' + mid).html(html);
          //$('.fade').fadeOut('slow');
        }
      });
    }
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Summerclass/updateMarkNow/",
        data: ({
          mid: mid,
          outof:outof,
          value:value,
          gradesec:gradesec,
          year:year,
          branch:branch
        }),
        cache: false,
        beforeSend: function() {
          $('.info-markSummer').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(html){
          $('.info-markSummer').html(html);
          load_mark();
        }
      });
  });
</script>
<script>
  $(document).on('click', '.edit_mark_gsSummer', function() {
      var edtim=$(this).attr("value");
      var gradesec=$('.jo_gradesecSummer').val();
      var academicyear=$('.jo_yearSummer').val();
      var branch=$('.jo_branchSummer').val();
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Summerclass/fetchMarkToEdit/",
        data: ({
          edtim: edtim,
          gradesec:gradesec,
          academicyear:academicyear,
          branch:branch
        }),
        cache: false,
        beforeSend: function() {
          $('#editmarkhere_gsSummer').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(html){
          $('#editmarkhere_gsSummer').html(html);
        }
    });
  });
</script>
<script>
  $(document).on('click', '.delete_selected_gradeSummer', function() {
    if(confirm('Are you sure you want to delete this Grade mark?')){
      var subject=$(".jo_subjectSummer").val();
      var gradesec=$(".jo_gradesecSummer").val();
      var branch=$(".jo_branchSummer").val();
      var year=$(".jo_yearSummer").val();

      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Summerclass/deleteThisGradeMark/",
        data: ({
          subject: subject,
          gradesec:gradesec,
          branch:branch,
          year:year
        }),
        cache: false,
        beforeSend: function() {
          $('.deleteSummerMark').html( 'Deleting...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">' );
        },
        success: function(html){
          $('.deleteSummerMark').html(html);
          iziToast.success({
            title: 'This Grade Mark',
            message: 'Deleted successfully',
            position: 'topRight'
          });
        }
      }); 
    }else{
      return false;
    }
  });
</script>
<script>
  $(document).on('click', '.delete_selectedSummer', function() {
    if(confirm('Are you sure you want to delete this subject mark?')){
      var subject=$(".jo_subjectSummer").val();
      var gradesec=$(".jo_gradesecSummer").val();
      var branch=$(".jo_branchSummer").val();
      var year=$(".jo_yearSummer").val();
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Summerclass/deleteThismark/",
        data: ({
          subject: subject,
          gradesec:gradesec,
          branch:branch,
          year:year
        }),
        cache: false,
        beforeSend: function() {
          $('.deleteSummerMark').html( 'Deleting...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">' );
        },
        success: function(html){
          $('.deleteSummerMark').html(html);
          iziToast.success({
            title: 'This Subject Mark',
            message: 'Deleted successfully',
            position: 'topRight'
          });
        }
      }); 
    }else{
      return false;
    }
  });
</script>
<script>
  $(document).on('click', '.gs_delete_marknameSummer', function() {
    if(confirm('Are you sure you want to delete this mark?')){
      var subject=$(".jo_subjectSummer").val();
      var gradesec=$(".jo_gradesecSummer").val();
      var branch=$(".jo_branchSummer").val();
      var year=$(".jo_yearSummer").val();
      var markname=$(this).attr("value");
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Summerclass/deleteMarkName/",
        data: ({
          subject: subject,
          gradesec:gradesec,
          branch:branch,
          year:year,
          markname: markname
        }),
        cache: false,
        beforeSend: function() {
          $('.deleteSummerMark').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(html){
          $('.deleteSummerMark').html(html);
        }
      }); 
    }else{
      return false;
    }
  });
</script>
<script type="text/javascript">
  $(document).ready(function() {  
    $("#SummerBranchFormat").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Summerclass/filterGradeFromBranch/",
        data: "branchit=" + $("#SummerBranchFormat").val(),
        beforeSend: function() {
          $('#summerGradesecformat').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="64" height="64" id="loa">' );
        },
        success: function(data) {
          $("#summerGradesecformat").html(data);
        }
      });
    });
  });
</script>
<script type="text/javascript">
  $('#deleteSummerMarkForm').on('submit', function(event) {
    event.preventDefault();
    var gs_branches=$('#deleteSummerMarkBranch').val();
    var gs_gradesec=$('.deleteSummerMarkGradesec').val();
    var gs_subject=$('.deleteSummerMarkSubject').val();
    if ($('.gradesec').val() != '') {
      $.ajax({
        url: "<?php echo base_url(); ?>Summerclass/fetchSummerGradeMark/",
        method: "GET",
        data: ({
          gs_branches: gs_branches,
          gs_gradesec:gs_gradesec,
          gs_subject:gs_subject
        }),
        dataType:'json',
        beforeSend: function() {
          $('.deleteSummerMark').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">' );
        },
        success: function(data) {
          $(".deleteSummerMark").html(data);
        }
      })
    }else {
      alert("All fields are required");
    }
  });
</script>
<script type="text/javascript">
  $(document).ready(function() {  
    $("#deleteSummerMarkBranch").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Summerclass/filterGradeFromBranch/",
        data: "branchit=" + $("#deleteSummerMarkBranch").val(),
        beforeSend: function() {
          $('.deleteSummerMarkGradesec').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="64" height="64" id="loa">' );
        },
        success: function(data) {
          $(".deleteSummerMarkGradesec").html(data);
        }
      });
    });
  });
</script>
<script type="text/javascript">
  $(document).ready(function() {  
    $("#deleteSummerMarkGradesec").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Summerclass/filterSubjectFromSummer/",
        data: "gradesec=" + $("#deleteSummerMarkGradesec").val(),
        beforeSend: function() {
          $('.deleteSummerMarkSubject').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(data) {
          $(".deleteSummerMarkSubject").html(data);
        }
      });
    });
  });
</script>
<!-- import mark starts -->
<script type="text/javascript">  
  $(document).ready(function(){  
    $('#uploadSummerMark').on("submit", function(e){  
      e.preventDefault(); 
      $.ajax({  
        url:"<?php echo base_url(); ?>Summerclass/importSummerMark/",  
        method:"POST",  
        data:new FormData(this),  
        contentType:false,         
        cache:false,           
        processData:false,          
        beforeSend: function() {
          $('#uploadMarkInfo').html( 'Saving...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success: function(data){  
          $('#uploadMarkInfo').html(data);
          $("#uploadSummerMark")[0].reset();   
        }  
      })  
    });  
  });  
 </script>
 <script type="text/javascript">
  $(document).ready(function() {  
    $("#SummerMarkBranch").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Summerclass/filterGradeFromBranch/",
        data: "branchit=" + $("#SummerMarkBranch").val(),
        beforeSend: function() {
          $('.summerMarkGradesec').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="64" height="64" id="loa">' );
        },
        success: function(data) {
          $(".summerMarkGradesec").html(data);
        }
      });
    });
  });
</script>
<script type="text/javascript">
  $(document).ready(function() {  
    $("#summerMarkGradesec").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Summerclass/filterSubjectFromSummer/",
        data: "gradesec=" + $("#summerMarkGradesec").val(),
        beforeSend: function() {
          $('.summerMarkSubject').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(data) {
          $(".summerMarkSubject").html(data);
        }
      });
    });
  });
</script>
<script type="text/javascript">
  $('#summerMarkViewForm').on('submit', function(event) {
    event.preventDefault();
    var gs_branches=$('#SummerMarkBranch').val();
    var gs_gradesec=$('.summerMarkGradesec').val();
    var gs_subject=$('.summerMarkSubject').val();
    if ($('.gradesec').val() != '') {
      $.ajax({
        url: "<?php echo base_url(); ?>Summerclass/fecthSummerMarkresult/",
        method: "POST",
        data: ({
          gs_branches: gs_branches,
          gs_gradesec:gs_gradesec,
          gs_subject:gs_subject
        }),
        beforeSend: function() {
          $('.viewSummerMark').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="64" height="64" id="loa">' );
        },
        success: function(data) {
          $(".viewSummerMark").html(data);
        }
      })
    }else {
      alert("All fields are required");
    }
  });
</script>
<script type="text/javascript">
  $(document).ready(function(){
    load_data();
    function load_data()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>Summerclass/fetchSummerPlacement/",
        method:"POST",
        beforeSend: function() {
          $('.fetchSummerPacement').html( 'Loading placement...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="64" height="64" id="loa">');
        },
        success:function(data){
          $('.fetchSummerPacement').html(data);
        }
      })
    }
    $('#saveSummerPlacement').on('submit', function(event) {
      event.preventDefault();
      var academicyear=$('#summerAcademicyear').val();
      var staff=$('#summerStaff').val();
      id=[];subject=[];
      $("input[name='summerGradePlacement']:checked").each(function(i){
        id[i]=$(this).val();
      });
      $("input[name='summerSubject']:checked").each(function(i){
        subject[i]=$(this).val();
      });
        $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Summerclass/postSummerPlacement/",
        data: ({
          id: id,
          academicyear:academicyear,
          staff:staff,
          subject:subject
        }),
        cache: false,
        success: function(html){
          $('#saveSummerPlacement')[0].reset();
          load_data();
        }
      });
    
  });
  $(document).on('click', '#deleteSummerStaffplacement', function()
  {
    var staff_placement=$(this).attr("value");
    if(confirm('Are you susre you want to delete this Staff')){
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Summerclass/deleteSummerStaffPlacement/",
        data: ({
          staff_placement: staff_placement
        }),
        cache: false,
        beforeSend: function() {
          $('.deleteSummerStaffplacement').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="14" height="14" id="loa">'
          );
        },
        success: function(html){
         $('.deleteSummerStaffplacement').fadeOut('slow');
         load_data();
        }
      });
    }
  }); 
});
</script>
<!-- summer evaluation starts -->
<script type="text/javascript">
  $(document).ready(function(){
    load_data();
    function load_data()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>Summerclass/fetchSummerEvaluations/",
        method:"POST",
        beforeSend: function() {
          $('#summerEvaluationData').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success:function(data){
          $('#summerEvaluationData').html(data);
        }
      })
    }
    $('#saveSummerevaluation').on('submit', function(event) {
      event.preventDefault();
      var grade=$('#summerevaGrade').val();
      var evname=$('.summerevaName').val();
      var percent=$('.summerevaPercent').val();
      id=[];
      $("input[name='summerevaGrade']:checked").each(function(i){
        id[i]=$(this).val();
      });
      if( id.length == 0 || $('.summerevaPercent').val() =='' || $('.summerevaName').val() =='')
      {
        alert("Oooops, Please select necessary fields.");
      }else{
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>Summerclass/postSummerEvaluation/",
          data: ({
            id: id,
            evname:evname,
            percent:percent
          }),
          cache: false,
          success: function(html){
            $('#saveSummerevaluation')[0].reset();
            load_data();
          }
        });
      }
    });
    $(document).on('click', '.deleteSummerEvaluation', function() {
      var post_id = $(this).attr("id");
      var evname = $(this).attr("name");
      if (confirm("Are you sure you want to delete this Evaluation ?")) 
      {
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>Summerclass/deleteSummerEvaluation/",
          data: ({
            post_id: post_id,
            evname :evname
          }),
          cache: false,
          success: function(html) {
            load_data();
          }
        });
      }else {
        return false;
      }
    });
  });
</script>
<!-- Subject starts -->
<script type="text/javascript">
  $(document).ready(function(){
    loadSubjectData();
    function loadSubjectData()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>Summerclass/fetchSummerSubject/",
        method:"POST",
        beforeSend: function() {
          $('.summerSubjectList').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="84" height="84" id="loa">');
        },
        success:function(data){
          $('.summerSubjectList').html(data);
        }
      })
    }
    $('#saveNewSummerSubject').on('submit', function(event) {
      event.preventDefault();
      var subjectName=$('#summerSubjectName').val();
      subjectGrade=[];subjectLetter=[];
      $("input[name='summerSubjectGrade']:checked").each(function(i){
        subjectGrade[i]=$(this).val();
      });
      $("input[name='summerSubjectLetter']:checked").each(function(i){
        subjectLetter[i]=$(this).val();
      });
      if( subjectGrade.length == 0 || $('#summerSubjectName').val() =='')
      {
        alert("Oooops, Please select necessary fields.");
      }else{
        $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Summerclass/saveNewSummerSubject/",
        data: ({
          subjectName: subjectName,
          subjectGrade:subjectGrade,
          subjectLetter:subjectLetter
        }),
        cache: false,
        success: function(html){
          $('#saveNewSummerSubject')[0].reset();
          loadSubjectData();
        }
      });
    }
  });
  $(document).on('click', '.deleteSummersubject', function(){
    var post_id = $(this).attr("id");
    if (confirm("Are you sure you want to delete this Subject ?")) {
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Summerclass/summerSubjectDelete/",
        data: ({
          post_id: post_id
        }),
        cache: false,
        success: function(html) {
         loadSubjectData();
        }
      });
    }else {
      return false;
    }
  });
  });
</script>

<script type="text/javascript">
  $(document).ready(function() {  
    $("#grands_branchitSummer").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Summerclass/filterGradeFromBranch/",
        data: "branchit=" + $("#grands_branchitSummer").val(),
        beforeSend: function() {
          $('.grands_gradesecSummer').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="64" height="64" id="loa">' );
        },
        success: function(data) {
          $(".grands_gradesecSummer").html(data);
        }
      });
    });
  });
</script>
<script type="text/javascript">
  $('#comment_formSummer').on('submit', function(event) {
    event.preventDefault();
    var gs_branches=$('#grands_branchitSummer').val();
    var gs_gradesec=$('.grands_gradesecSummer').val();
    var grands_academicyear=$('#grands_academicyearSummer').val();
    if ($('.gradesec').val() != '') {
      $.ajax({
        url: "<?php echo base_url(); ?>Summerclass/fecthThisStudent/",
        method: "POST",
        data: ({
          gs_branches: gs_branches,
          gs_gradesec:gs_gradesec,
          grands_academicyear:grands_academicyear
        }),
        beforeSend: function() {
          $('.listSummerStudentShow').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">' );
        },
        success: function(data) {
          $(".listSummerStudentShow").html(data);
        }
      })
    }else {
      alert("All fields are required");
    }
  });
  /*delete summer student*/
  $(document).on('click', '.deleteSummerStudent', function() {
    var post_id = $(this).attr("id");
    if (confirm("Are you sure you want to delete this student permantly ?")) {
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Summerclass/deleteSummerStudent/",
        data: ({
          post_id: post_id
        }),
        cache: false,
        success: function(html) {
          $(".delete_mem" + post_id).fadeOut('slow');
        }
      });
    }else {
      return false;
    }
  });
  /*edit summer student*/
  $(document).on('click', '.editSummerStudent', function() {
    var editedId = $(this).attr("id");
    $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>Summerclass/editSummerStudent/",
      data: ({
        editedId: editedId
      }),
      cache: false,
      beforeSend: function() {
        $('.listSummerStudentShow').html( '<img src="<?php echo base_url() ?>img/loader.gif" alt="" width="74" height="74" id="loa">');
      },
      success: function(html) {
        $(".listSummerStudentShow").html(html);
      }
    });
  });
  /*update student*/
  $(document).on('submit', '#updateSummerStuForm', function(e) {
    e.preventDefault();
    $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>Summerclass/updateSummerStudents/",
      data:new FormData(this),
      processData:false,
      contentType:false,
      cache: false,
      async:false,
      beforeSend: function() {
        $('.listSummerStudentShow').html( '<span class="text-info">Updating...</span>');
      },
      success: function(html){
         $(".listSummerStudentShow").html(html);
      }
    });
  });
</script>
<!-- Grade change script starts-->
<script type="text/javascript">
  $(document).ready(function(){
    load_data();
    function load_data()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>Summerclass/fetchSummerClassStatus/",
        method:"POST",
        beforeSend: function() {
          $('#listSummerClassStatus').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success:function(data){
          $('#listSummerClassStatus').html(data);
        }
      })
    }
    $(document).on('click', "input[name='startSummerClass']", function() {
      if($(this).is(':checked')){
          $.ajax({
            method: "POST",
            url: "<?php echo base_url(); ?>Summerclass/startSummerClass/",
            cache: false,
            success: function(html) {
              iziToast.success({
                title: 'Summer class',
                message: 'started successfully',
                position: 'topRight'
              });
            }
          });
      }else{
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>Summerclass/deleteSummerClass/",
          cache: false,
          success: function(html) {
            iziToast.success({
              title: 'Summer class',
              message: 'deleted successfully',
              position: 'topRight'
            });
          }
        });
      } 
    });
  });
</script>
<!-- Import student -->
<script type="text/javascript">  
  $(document).ready(function(){  
    $('#uploadSummerStudent').on("submit", function(e){  
      e.preventDefault(); 
      $.ajax({  
        url:"<?php echo base_url(); ?>Summerclass/importStudent/",  
        method:"POST",  
        data:new FormData(this),  
        contentType:false,         
        cache:false,           
        processData:false,          
        beforeSend: function() {
          $('#importStudentInfo').html( 'Saving...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success: function(data){  
          $('#importStudentInfo').html(data);
          $("#uploadSummerStudent")[0].reset();   
        }  
      })  
    });  
  });  
 </script> 
<script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass();
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='white']").addClass("active");
      $(".selectgroup-input[value|='1']").prop("checked", true);
    } else {
      $("body").removeClass();
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='black']").addClass("active");
      $(".selectgroup-input[value|='2']").prop("checked", true);
    }
  });
</script>
<script type="text/javascript" language="javascript"> 
  var bgcolor_now=document.getElementById("bgcolor_now").value;
  if (bgcolor_now == "1") {
    $("body").removeClass();
    $("body").addClass("light");
    $("body").addClass("light-sidebar");
    $("body").addClass("theme-white");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='white']").addClass("active");
    $(".selectgroup-input[value|='1']").prop("checked", true);
  }else {
    $("body").removeClass();
    $("body").addClass("dark");
    $("body").addClass("dark-sidebar");
    $("body").addClass("theme-black");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='black']").addClass("active");
    $(".selectgroup-input[value|='2']").prop("checked", true);
  } 
</script> 

</html>