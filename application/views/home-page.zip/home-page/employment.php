<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/summernote/summernote-bs4.css">
  <link rel="stylesheet" href="<?php  echo base_url(); ?>assets/css/pretty-checkbox.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/izitoast/css/iziToast.min.css">
  <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"><div class="loaderIcon"></div></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
       <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
           <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="row">
              <div class="col-12 col-md-12 col-lg-12">
                <?php include('bgcolor.php'); ?>
                <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">
                <div class="card">
                  <div class="card-header">
                    <ul class="nav nav-tabs" id="myTab2" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active" id="home-tab1" data-toggle="tab" href="#postVacancy" role="tab" aria-selected="true">Post Vacancy</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" id="home-tab3" data-toggle="tab" href="#viewPostedVacancy" role="tab" aria-selected="false">View Posted Vacancy</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" id="home-tab2" data-toggle="tab" href="#viewApplicants" role="tab" aria-selected="false">View Applicants</a>
                      </li>
                    </ul>
                  </div>
                  <div class="tab-content tab-bordered" id="myTab3Content">
                    <div class="tab-pane fade show active" id="postVacancy" role="tabpanel" aria-labelledby="home-tab1">
                      <div class="card-body">
                        <form id="postVacancy" method="POST">
                          <div class="row">
                            <div class="col-lg-6 col-6">
                              <div class="form-group">
                                <label for="Name">Position</label>
                                <input class="form-control" name="position" id="position" required="required" type="text" placeholder="Vacancy Position">
                              </div>
                            </div>
                            <div class="col-lg-6 col-6">
                              <div class="form-group">
                                <label for="logo">Expire Date</label>
                                <div class="custom-file">
                                  <input type="date" id="expireDate" name="expireDate" class="form-control">
                                </div>
                              </div>
                            </div>
                            <div class="form-group col-lg-12 col-12">
                              <label>Vacancy Description</label>
                              <textarea name="description" id="description" class="form-control summernote-simple bio"> </textarea>
                            </div>
                            <div class="col-lg-12 col-12">
                              <button type="submit" value="upload" name="postnews" class="btn btn-primary btn-block">Post Vacancy
                              </button>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                    <div class="tab-pane fade show" id="viewPostedVacancy" role="tabpanel" aria-labelledby="home-tab3">
                      <div class="card-body blogs"> </div>
                    </div>
                    <div class="tab-pane fade show" id="viewApplicants" role="tabpanel" aria-labelledby="home-tab2">
                      <div class="card-body viewApplicants"> </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </section>
        <div class="modal fade" id="viewPostedVacancyDetail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  Vacancy Detail
                  <h5 class="modal-title" id="">
                  <button class="btn btn-default" onclick="codespeedy()" name="" type="submit" id="">
                      <span class="text-warning">Print <i class="fas fa-print"></i></span>
                  </button></h5>
                </div>
                <div class="modal-body vacancyDetailHere" id="printviewVacancyDetail">
                  
                </div>
                <div class="modal-footer bg-whitesmoke br">
                  <a id="saveskygrade"></a>
                  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
        </div>
      </div>
       <footer class="main-footer">
        <div class="footer-left">
           Call:+251967829025 &nbsp;&nbsp;
          Copyright &copy<?php echo date('Y');?>
          <a href="https://www.grandstande.com" target="_blanck">GrandStande IT Solution Plc</a>
          All rights are Reserved.
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/summernote/summernote-bs4.js"></script>
  <script src="<?php echo base_url(); ?>assets/izitoast/js/iziToast.min.js"></script>
  <script type="text/javascript">
    function codespeedy(){
      var print_div = document.getElementById("printviewVacancyDetail");
      var print_area = window.open();
      print_area.document.write(print_div.innerHTML);
      print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" type="text/css" />');
      print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css" type="text/css" />');
      print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css" type="text/css" />');
      print_area.document.close();
      print_area.focus();
      print_area.print();
    }
  </script>
<script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass();
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='white']").addClass("active");
      $(".selectgroup-input[value|='1']").prop("checked", true);
    } else {
      $("body").removeClass();
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='black']").addClass("active");
      $(".selectgroup-input[value|='2']").prop("checked", true);
    }
  });
</script>
<script type="text/javascript" language="javascript"> 
  var bgcolor_now=document.getElementById("bgcolor_now").value;
  if (bgcolor_now == "1") {
    $("body").removeClass();
    $("body").addClass("light");
    $("body").addClass("light-sidebar");
    $("body").addClass("theme-white");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='white']").addClass("active");
    $(".selectgroup-input[value|='1']").prop("checked", true);
  }else {
    $("body").removeClass();
    $("body").addClass("dark");
    $("body").addClass("dark-sidebar");
    $("body").addClass("theme-black");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='black']").addClass("active");
    $(".selectgroup-input[value|='2']").prop("checked", true);
  } 
</script> 

  <script type="text/javascript">
    $(document).ready(function(){
      load_data();
      loadApplicants();
      function loadApplicants()
      {
        $.ajax({
          url:"<?php echo base_url(); ?>employment/loadApplicants/",
          method:"POST",
          beforeSend: function() {
            $('.viewApplicants').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
          },
          success:function(data){
            $('.viewApplicants').html(data);
          }
        })
      }
      function load_data()
      {
        $.ajax({
          url:"<?php echo base_url(); ?>employment/fetchvacancy/",
          method:"POST",
          beforeSend: function() {
            $('.blogs').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
          },
          success:function(data){
            $('.blogs').html(data);
          }
        })
      }
        $('#postVacancy').on('submit', function(e) {
          e.preventDefault();
          if($('#position').val() =='')
          {
            alert("Oooops, Please enter your position.");
          }else{
            var position=$('#position').val();
            var expireDate=$('#expireDate').val();
            var description=$('#description').val();
            $.ajax({
              method: "POST",
              url: "<?php echo base_url(); ?>employment/postvacancy/",
              data:({
                position:position,
                expireDate:expireDate,
                description:description
              }),
              cache: false,
              success: function(html){
                load_data();
                iziToast.success({
                  title: 'Vacancy',
                  message: 'Posted Successfully',
                  position: 'bottomCenter'
                });
              }
          });
        }
      });
    });
  </script>
  <script type="text/javascript">
    $(document).ready(function() {
     $(document).on('click', '.deletemyvacancy', function() {
      var id = $(this).attr("id");
      if (confirm("Are you sure you want to delete this Vacancy permanently?")) 
      {
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>employment/Deletevacancy",
          data: ({
            id: id
          }),
          cache: false,
          success: function(html) {
            $(".deletevacancy" + id).fadeOut('slow');
          }
        });
      }else {
        return false;
      }
    });
  });
  $(document).on('click', '.viewmyvacancy', function() {
    var id = $(this).attr("id");
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>employment/viewmyvacancyDetail/",
        data: ({
          id: id
        }),
        cache: false,
        success: function(html) {
          $(".vacancyDetailHere").html(html);
        }
      });
  });
</script>

<script>
  $(document).ready(function() {  
    function unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_notification/",
        method: "POST",
        data: ({
            view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.notification-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-notification').html(data.unseen_notification);
          }
        }
      });
    }  
    function inbox_unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
        method: "POST",
        data: ({
            view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.inbox-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-inbox').html(data.unseen_notification);
          }
        }
      });
    }
    unseen_notification();
    inbox_unseen_notification();
    $(document).on('click', '.seen_noti', function() {
      $('.count-new-notification').html('');
      inbox_unseen_notification('yes');
    });
    $(document).on('click', '.seen', function() {
      $('.count-new-inbox').html('');
      inbox_unseen_notification('yes');
    });
    setInterval(function() {
      unseen_notification();
      inbox_unseen_notification();
    }, 5000);
  });
</script>
</body>
</html>