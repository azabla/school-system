<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/custom.css">
 <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
           <?php include('bgcolor.php'); ?>
            <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">           
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12">
                <div class="card">
                  <div class="boxs mail_listing">
                    <div class="inbox-center table-responsive">
                      <div class="card-header">
                        <h4>Add New Exam Questions</h4>
                        <?php if(isset($_SESSION['success'])){ ?>
                      <sapn class="text-success">
                          <?php echo $_SESSION['success']; ?>
                      </span>
                      <?php  }
                      elseif(isset($_SESSION['error'])) { ?>
                      <sapn class="text-danger">
                          <?php echo $_SESSION['error']; ?>  
                      </span>
                     <?php } ?>
                       </div>   
                    </div>
                   
                    <div class="row">
                    <div class="col-lg-12">
                      <form class="composeForm" method="POST"
                       action="<?php echo base_url();?>exam/">
                       <input type="hidden" name="subject" value="<?php echo $subject ?>">
                       <input type="hidden" name="gradesec" value="<?php echo $gradesec ?>">
                       <input type="hidden" name="examname" value="<?php echo $examname ?>">
                       <input type="hidden" name="minute" value="<?php echo $minute ?>">
                      <?php $no=1; for($i=0;$i<$nquestions;$i++) { ?>
                      <div class="row">
                       <div class="col-lg-12">
                        <div class="form-group">
                          <label for="Mobile"><?php echo $no;?>
                          </label>
                          <div class="form-line">
                          <input type ="text" placeholder="Question <?php echo $no ?> here..." class="form-control" required="required" name="number[ ]" id="number">
                         </div>
                       </div>
                     </div>
                   </div>
                   <div class="row">
                      <div class="col-lg-3">
                        <div class="form-group">
                          <div class="form-line">
                            <input type ="text" placeholder="Choice A for Q<?php echo $no ?>" class="form-control" required="required" name="ca[ ]" id="ca">
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-3">
                        <div class="form-group">
                          <div class="form-line">
                            <input type ="text" placeholder="Choice B for Q<?php echo $no ?>" class="form-control" required="required" name="cb[ ]" id="cb">
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-3">
                        <div class="form-group">
                          <div class="form-line">
                            <input type ="text" placeholder="Choice C for Q<?php echo $no ?> " class="form-control" required="required" name="cc[ ]" id="cc">
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-3">
                        <div class="form-group">
                          <div class="form-line">
                            <input type ="text" placeholder="Choice D for Q<?php echo $no ?> " class="form-control" required="required" name="cd[ ]" id="cd">
                          </div>
                        </div>
                      </div>
                    </div>
                       <div class="row">
                       <div class="col-lg-12">
                        <div class="form-group">
                         <div class="form-line">
                          <input type ="text" placeholder="Answer for question <?php echo $no ?> here..." class="form-control" required="required" name="answer[ ]" id="answer">
                         </div>
                        </div>
                        </div>
                      </div>
                       <?php $no++; }?>
                      <div class="row">
                      <div class="col-lg-10"> </div>
                      <div class="col-lg-2">
                      <div class="m-l-25 m-b-20">
                        <button type="submit" name="savexam" class="btn btn-info btn-border-radius waves-effect">Save
                        </button>
                      </div>
                      </div>
                      </div>
                      </form>
                      </div>
                    </div>
                 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
       <footer class="main-footer">
        <div class="footer-left">
         Call:+251967829025 &nbsp;&nbsp;
          Copyright &copy <?php echo date('Y');?>
          <a href="https://www.grandstande.com" target="_blanck">GrandStand</a>
          All rights are Reserved.
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <!-- General JS Scripts -->
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js">
  </script>
  <!-- Custom JS File -->
  <script src="<?php echo base_url(); ?>assets/js/custom.js">
  </script>
  <script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass();
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='white']").addClass("active");
      $(".selectgroup-input[value|='1']").prop("checked", true);
    } else {
      $("body").removeClass();
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='black']").addClass("active");
      $(".selectgroup-input[value|='2']").prop("checked", true);
    }
  });
</script>
 <script type="text/javascript">
    $(document).ready(function() {
        $("#gradesec").change(function() {
          var gradesec=$("#gradesec").val();
            $.ajax({
                method: "POST",
                url: "<?php echo base_url(); ?>Filtereach_user_gradesec/",
                data: {gradesec:gradesec} ,
                success: function(data) {
                    $("#subject").html(data);
                }
            });
        });
    });
  </script>
  <script>
    $(document).ready(function() {  
    function unseen_notification(view = '') { 
            $.ajax({
                url: "<?php echo base_url() ?>fetch_unseen_notification/",
                method: "POST",
                data: ({
                    view: view
                }),
                dataType: "json",
                success: function(data) {
                    $('.notification-show').html(data.notification);
                    if (data.unseen_notification > 0) {
                        $('.count-new-notification').html(data.unseen_notification);
                    }
                }
            });
        }  
        function inbox_unseen_notification(view = '') { 
            $.ajax({
                url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
                method: "POST",
                data: ({
                    view: view
                }),
                dataType: "json",
                success: function(data) {
                    $('.inbox-show').html(data.notification);
                    if (data.unseen_notification > 0) {
                        $('.count-new-inbox').html(data.unseen_notification);
                    }
                }
            });
        }
        unseen_notification();
        inbox_unseen_notification();
        $(document).on('click', '.seen_noti', function() {
            $('.count-new-notification').html('');
            inbox_unseen_notification('yes');
        });
        $(document).on('click', '.seen', function() {
            $('.count-new-inbox').html('');
            inbox_unseen_notification('yes');
        });
        setInterval(function() {
          unseen_notification();
          inbox_unseen_notification();
        }, 5000);

    });
    </script>
</body>

</html>