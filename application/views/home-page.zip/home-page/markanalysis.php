<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
   <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <link rel="stylesheet" href="<?php  echo base_url(); ?>assets/css/pretty-checkbox.min.css">
  <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">           
            <div class="row">
              <div class="col-12">
                <?php include('bgcolor.php'); ?>
                <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>"> 
                <div class="card">
                  <div class="card-header">
                    <div class="row">
                      <div class="col-md-8 col-8">
                        <h4>Students Mark Analysis</h4>
                      </div>
                       <div class="col-md-4 col-4">
                        <button class="btn btn-default pull-right" name="gethisreport" onclick="codespeedy()">
                        <span class="text-black">
                        <i data-feather="printer"></i>
                        </span>
                       </button>
                      </div>
                    </div>
                  </div>
                  <div class="card-header">
                    <div class="StudentViewTextInfo">
                      <div class="row">
                    
                        <div class="col-lg-3 col-6">
                          <div class="form-group">
                           <select class="form-control selectric" required="required" name="branch" id="admin_branch">
                           <option>--- Select branch ---</option>
                            <?php foreach($branch as $branchs){ ?>
                              <option value="<?php echo $branchs->name;?>">
                              <?php echo $branchs->name;?>
                              </option>
                            <?php }?>
                           </select>
                          </div>
                        </div>
                        <div class="col-md-2 col-6">
                          <div class="form-group">
                            <select class="form-control selectric" required="required" name="quarter"  id="analysis_quarter">
                              <option>--- Select Quarter ---</option>
                              <?php foreach($fetch_term as $fetch_terms){ ?>
                                <option value="<?php echo $fetch_terms->term;?>">
                                <?php echo $fetch_terms->term;?>
                                </option>
                              <?php }?>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-4 col-6 table-responsive" id="grade2analysis" style="height: 40vh;">
                        </div>
                        <div class="col-md-2 col-6 table-responsive evaluation_here" style="height: 30vh;">
                        </div>
                        <div class="col-md-2 col-12">
                          <button class="btn btn-primary btn-block btn-lg viewanalysis"> View Analysis 
                          </button>
                        </div>
                      </div>
                    </div>
                  <div class="listanalysisHere table-responsive" id="helloHere" style="height:30vh;">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      </div>
     <?php include('footer.php'); ?>
  </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>
</body>
<!-- filter grade from branch starts -->
<script type="text/javascript">
  $(document).ready(function() {  
    $("#admin_branch").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>markanalysis/filterGradeFromBranchGS/",
        data: "branchit=" + $("#admin_branch").val(),
        beforeSend: function() {
          $('#grade2analysis').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(data) {
          $("#grade2analysis").html(data);
        }
      });
    });
  });
</script>
<script type="text/javascript">
  $(document).on('click', '.grade2analysisGrandstande', function() {
    grade2analysis=[];
    $("input[name='grade2analysisGrandstande']:checked").each(function(i){
      grade2analysis[i]=$(this).val();
    });
    var branch2analysis=$("#admin_branch").val();
    /*var grade2analysis=$("#grade2analysis").val();*/
    var analysis_quarter=$("#analysis_quarter").val();
    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>markanalysis/filter_evaluation4analysis/",
      data:({
        branch2analysis:branch2analysis,
        grade2analysis:grade2analysis,
        analysis_quarter:analysis_quarter
      }),
      beforeSend: function() {
        $('.evaluation_here').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">'
          );
      },
      success: function(data) {
        $(".evaluation_here").html(data);
      }
    });
  });
</script>
<!-- fetch analysis starts -->
<script type="text/javascript">
  $(document).on('click', '.viewanalysis', function() {
    grade2analysis=[];
    $("input[name='grade2analysisGrandstande']:checked").each(function(i){
      grade2analysis[i]=$(this).val();
    });

    evaluationanalysis=[];
    $("input[name='evaluationanalysis']:checked").each(function(i){
      evaluationanalysis[i]=$(this).val();
    });

    var branch=$('#admin_branch').val();
    var quarter=$('#analysis_quarter').val();
    if(evaluationanalysis.length!=0 && grade2analysis.length!=0){
      $.ajax({
        url: "<?php echo base_url(); ?>markanalysis/fetch_analysis/",
        method: "POST",
        data: ({
          branch: branch,
          gradesec:grade2analysis,
          evaluation:evaluationanalysis,
          quarter:quarter
        }),
        beforeSend: function() {
          $('.listanalysisHere').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="54" height="54" id="loa">' );
        },
        success: function(data) {
          $(".listanalysisHere").html(data);
        }
      });
    }else{
      swal('Please select all necessary fields!', {
        icon: 'error',
      });
    }
  })
</script>
<script type="text/javascript">
  function codespeedy(){
    var print_div = document.getElementById("helloHere");
    var print_area = window.open();
    print_area.document.write(print_div.innerHTML);
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" type="text/css" />');
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css" type="text/css" />');
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css" type="text/css" />');
    print_area.document.close();
    print_area.focus();
    print_area.print();
  }
</script>

<script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass("dark");
      $("body").removeClass("dark-sidebar");
      $("body").removeClass("theme-black");
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
    } else {
      $("body").removeClass("light");
      $("body").removeClass("light-sidebar");
      $("body").removeClass("theme-white");
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
    }
  });
</script>
<script type="text/javascript" language="javascript"> 
  var bgcolor_now=document.getElementById("bgcolor_now").value;
  if (bgcolor_now == "1") {
    $("body").removeClass("dark");
    $("body").removeClass("dark-sidebar");
    $("body").removeClass("theme-black");
    $("body").addClass("light");
    $("body").addClass("light-sidebar");
    $("body").addClass("theme-white");
  }else {
    $("body").removeClass("light");
    $("body").removeClass("light-sidebar");
    $("body").removeClass("theme-white");
    $("body").addClass("dark");
    $("body").addClass("dark-sidebar");
    $("body").addClass("theme-black"); 
  } 
</script>
<script>
  $(document).ready(function() { 
    function unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_notification/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.notification-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-notification').html(data.unseen_notification);
          }
        }
      });
    }
    function inbox_unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.inbox-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-inbox').html(data.unseen_notification);
          }
        }
      });
    }
    unseen_notification();
    inbox_unseen_notification();
    $(document).on('click', '.seen_noti', function() {
      $('.count-new-notification').html('');
      inbox_unseen_notification('yes');
    });
    $(document).on('click', '.seen', function() {
      $('.count-new-inbox').html('');
      inbox_unseen_notification('yes');
    });
    setInterval(function() {
      unseen_notification();
      inbox_unseen_notification();
    }, 5000);
  });
</script>
</html>