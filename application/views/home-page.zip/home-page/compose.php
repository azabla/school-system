<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/summernote/summernote-bs4.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/izitoast/css/iziToast.min.css">
 <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"><div class="loaderIcon"></div></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body"> 
           <?php include('bgcolor.php'); ?>
            <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">          
            <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="card">
                  <div class="boxs mail_listing">
                    <div class="inbox-center table-responsive">
                      <div class="card-header">
                        <h4>Compose new message</h4>
                       </div>   
                    </div>
                    <div class="card">
                    <div class="card-body">
                      <form id="composeForm" method="POST">
                        <div class="row">
                         <div class="col-lg-4 col-6">
                          <div class="form-group">
                            <label for="Mobile">Select Usertype</label>
                            <div class="form-line">
                              <select class="form-control selectric"required="required" name="usertype" id="usertypee">
                                <option></option>
                                <?php foreach($usertype as $usertypes) { ?>
                                 <option value="<?php echo $usertypes->usertype;?>">
                                 <?php echo $usertypes->usertype;?></option>
                                <?php } ?>
                              </select>
                            </div>
                           </div>
                          </div>
                        <div class="col-lg-4 col-6">
                          <div class="form-group">
                            <label for="Mobile">Select Grade</label>
                            <div class="form-line">
                            <select class="form-control" name="user" id="useer">
                            </select>
                            </div>
                          </div>
                        </div>
                        <div class="col-lg-4 col-12">
                          <div class="form-group">
                            <div class="table-responsive" style="height:15vh;" id="gradee"> </div>
                          </div>
                        </div>
                        <div class="col-lg-6 col-12">
                          <div class="form-group">
                            <div class="form-line">
                              <input type="text" id="subjectt" name= "subject" required="required" class="form-control" placeholder="Subject">
                            </div>
                          </div>
                        </div>
                        <div class="col-lg-6 col-12">
                          <textarea class="form-control summernote-simple messageeJoss" id="messageeJoss" name="message" required>
                          </textarea>
                        </div>
                        <div class="col-lg-6 col-6">
                          <div class="">
                            <button type="submit" name="composemsg" id="sending" class="btn btn-primary btn-block btn-border-radius waves-effect">Send
                            </button>
                          </div>
                        </div>
                          <div class="col-lg-6 col-6">
                            <div class="">
                            <button type="button" id="discard" class="btn btn-danger btn-block btn-border-radius waves-effect">Discard
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                    </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
       <footer class="main-footer">
        <div class="footer-left">
         Call:+251967829025 &nbsp;&nbsp;
          Copyright &copy <?php echo date('Y');?>
          <a href="https://www.grandstande.com" target="_blanck">GrandStand IT Solution Plc</a>
          All rights are Reserved.
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/summernote/summernote-bs4.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/izitoast/js/iziToast.min.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.14.6/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.14.6/firebase-messaging.js"></script>
<script>
  
    const firebaseConfig = {
      apiKey: "AIzaSyCBxBMOS0fQ6coEbAJ59EbG5C85UyRAAzY",
    
      authDomain: "gsmessaging-6f8fe.firebaseapp.com",
    
      projectId: "gsmessaging-6f8fe",
    
      storageBucket: "gsmessaging-6f8fe.appspot.com",
    
      messagingSenderId: "824088762395",
    
      appId: "1:824088762395:web:f3b82d6aa4ee86210d00be",
    
      measurementId: "G-QY7YF042HW"
    
    };
    firebase.initializeApp(firebaseConfig);
    const messaging=firebase.messaging();

    function IntitalizeFireBaseMessaging() {
        messaging
            .requestPermission()
            .then(function () {
                console.log("Notification Permission");
                return messaging.getToken();
            })
            .then(function (token) {
                console.log("Token : "+token);
            //start code to save token into database
             jQuery.ajax({
               url: "<?php echo base_url(); ?>compose/save_token/",
               type:"POST",
               dataType: 'json',
               data: {token:token},
               success:function(response){
                 if(response.status == true)
                 {
                   console.log(response.msg);
                 }
                 else
                 {
                   console.log(response.msg);
                 }
                },
                error: function (xhr, status) {
               /* $(".loader-div").hide();*/ // hide loader 
                console.log('ajax error = ' + xhr.statusText);
                }
             });
             //end code to save token into database
                //document.getElementById("token").innerHTML=token;
            })
            .catch(function (reason) {
                console.log(reason);
            });
    }

    messaging.onMessage(function (payload) {
        console.log(payload);
        const notificationOption={
            body:payload.notification.body,
            icon:payload.notification.icon
        };

        if(Notification.permission==="granted"){
            var notification=new Notification(payload.notification.title,notificationOption);

            notification.onclick=function (ev) {
                ev.preventDefault();
                window.open(payload.notification.click_action,'_blank');
                notification.close();
            }
        }

    });
    messaging.onTokenRefresh(function () {
        messaging.getToken()
            .then(function (newtoken) {
                console.log("New Token : "+ newtoken);
            })
            .catch(function (reason) {
                console.log(reason);
        //alert(reason);
            })
    })
    IntitalizeFireBaseMessaging();
</script>
  <script type="text/javascript">
    $('#composeForm').on('submit', function(event) {      
        if($(".messageeJoss").val()==''){
          alert('Please write a message.')
        }else{
          event.preventDefault();
          var form_data = $(this).serialize();
        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>compose/composeMessage/",
          data: form_data,
          success: function(data) {
            iziToast.success({
              title: 'Message Sent successfully',
              message: '',
              position: 'bottomCenter'
            });
          }
        });
      }
    });
  </script>
  <script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass();
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='white']").addClass("active");
      $(".selectgroup-input[value|='1']").prop("checked", true);
    } else {
      $("body").removeClass();
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='black']").addClass("active");
      $(".selectgroup-input[value|='2']").prop("checked", true);
    }
  });
</script>
<script type="text/javascript" language="javascript"> 
  var bgcolor_now=document.getElementById("bgcolor_now").value;
  if (bgcolor_now == "1") {
    $("body").removeClass();
    $("body").addClass("light");
    $("body").addClass("light-sidebar");
    $("body").addClass("theme-white");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='white']").addClass("active");
    $(".selectgroup-input[value|='1']").prop("checked", true);
  }else {
    $("body").removeClass();
    $("body").addClass("dark");
    $("body").addClass("dark-sidebar");
    $("body").addClass("theme-black");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='black']").addClass("active");
    $(".selectgroup-input[value|='2']").prop("checked", true);
  } 
</script>  
<script type="text/javascript">
    function selectAll(){
      var itemsall=document.getElementById('selectall');
      if(itemsall.checked==true){
        var items=document.getElementsByName('username[ ]');
        for(var i=0;i < items.length;i++){
          items[i].checked=true;
        }
      }
      else{
        var items=document.getElementsByName('username[ ]');
        for(var i=0;i < items.length;i++){
          items[i].checked=false;
        }
      }
    }
</script>
  <script type="text/javascript">
    $(document).ready(function() {
      $("#discard").on("click",function() {
        $("#subjectt").val(''); 
        $("#messagee").val('');
        $("#usertypee").val('');
      });
    });
  </script>
 <script type="text/javascript">
    $(document).ready(function() {
      $("#usertypee").change(function() {
        var usertype=$("#usertypee").val();
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>compose/fetchUsertype/",
          data: {usertype:usertype} ,
          beforeSend: function() {
            $('#gradee').html('<img src="<?php echo base_url(); ?>/img/loader.gif" alt="">' );
          },
          success: function(data) {
            if(usertype !=='Student'){
              $("#gradee").html(data);
              $("#useer").attr("disabled","disabled");
            }else{
              $("#useer").html(data);
              $("#useer").removeAttr("disabled","disabled");
            }
          }
        });
      });
    });
  </script>
  <script type="text/javascript">
    $(document).ready(function() {
      $("#useer").change(function() {
        var grade=$("#useer").val();
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>compose/fetchUsertype/",
          data: {grade:grade} ,
          beforeSend: function() {
            $('#gradee').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="">' );
          },
          success: function(data) {
            $("#gradee").html(data);
          }
        });
      });
    });
  </script>
  <script>
    $(document).ready(function() { 
        checkNotificationFound();
        checkNewUserFound();
        function checkNotificationFound() { 
            $.ajax({
                url: "<?php echo base_url() ?>compose/sendNotification/",
                method: "POST"
            });
        }
        function checkNewUserFound() { 
            $.ajax({
                url: "<?php echo base_url() ?>compose/checkNewUserFound/",
                method: "POST"
            });
        }
        function unseen_notification(view = '') { 
            $.ajax({
                url: "<?php echo base_url() ?>fetch_unseen_notification/",
                method: "POST",
                data: ({
                    view: view
                }),
                dataType: "json",
                success: function(data) {
                    $('.notification-show').html(data.notification);
                    if (data.unseen_notification > 0) {
                        $('.count-new-notification').html(data.unseen_notification);
                    }
                }
            });
        }  
        function inbox_unseen_notification(view = '') { 
            $.ajax({
                url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
                method: "POST",
                data: ({
                    view: view
                }),
                dataType: "json",
                success: function(data) {
                    $('.inbox-show').html(data.notification);
                    if (data.unseen_notification > 0) {
                        $('.count-new-inbox').html(data.unseen_notification);
                    }
                }
            });
        }
        unseen_notification();
        inbox_unseen_notification();
        $(document).on('click', '.seen_noti', function() {
            $('.count-new-notification').html('');
            inbox_unseen_notification('yes');
        });
        $(document).on('click', '.seen', function() {
            $('.count-new-inbox').html('');
            inbox_unseen_notification('yes');
        });
        setInterval(function() {
          unseen_notification();
          inbox_unseen_notification();
        }, 5000);
        setInterval(function() {
          checkNewUserFound();
          checkNotificationFound();
        }, 360000);

    });
    </script>
</body>

</html>