<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/summernote/summernote-bs4.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
 <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body"> 
           <?php include('bgcolor.php'); ?>
            <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>"> 
            <div class="card">
              <div class="card-header">
                <h5 class="header-title">Communication Book</h5>
              </div>
            </div>  
            <ul class="nav nav-tabs" id="myTab2" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="home-tab1" data-toggle="tab" href="#customText" role="tab" aria-selected="true"> Custom Text</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="home-tab2" data-toggle="tab" href="#sentText" role="tab" aria-selected="false">Sent Text</a>
              </li>
            </ul>
            <div class="tab-content tab-bordered" id="myTab3Content">
              <div class="tab-pane fade show active" id="customText" role="tabpanel" aria-labelledby="home-tab1">
                <div class="row">
                  <div class="col-md-8 col-lg-8 col-8">
                    <input type="text" name="customTextName" id="customTextName" class="form-control" placeholder="Custom text here...">
                  </div>
                  <div class="col-md-4 col-lg-4 col-4">
                    <button class="btn btn-primary btn-block saveCustomText" id="saveCustomText">Save Text</button>
                  </div>
                </div>
                <div class="table-responsive fetchCustomTextHere" style="height:100vh;"></div>
              </div>
              <div class="tab-pane fade show" id="sentText" role="tabpanel" aria-labelledby="home-tab2">
                <div class="sentCommunicationBookList"></div>
              </div>
            </div>
          </div>
        </section>
        <div class="modal fade" id="viewComBookNow" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">
                  <button class="btn btn-default printlessonplan" onclick="codespeedy()" name="printlessonplan" type="submit" id="">
                      <span class="text-warning">Print <i class="fas fa-print"></i></span>
                  </button></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="comBookPrintHere"> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php include('footer.php'); ?>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      loadCustomData();
      function loadCustomData()
      {
        $.ajax({
          url:"<?php echo base_url(); ?>communicationbook/fetchCustomText/",
          method:"POST",
          beforeSend: function() {
            $('.fetchCustomTextHere').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
          },
          success:function(data){
            $('.fetchCustomTextHere').html(data);
          }
        })
      }
      $('#saveCustomText').on('click', function(event) {
        event.preventDefault();
        var customTextName=$('#customTextName').val();

        if($('#customTextName').val() =='')
        {
          swal({
            title: 'Oooops, Please select necessary fields.',
            text: '',
            icon: 'warning',
            buttons: true,
            dangerMode: true,
          })
        }else{
          $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>communicationbook/postCustomText/",
          data: ({
            customTextName: customTextName
          }),
          cache: false,
          success: function(html){
            $('#customTextName').val('');
            loadCustomData();
          }
        });
      }
    });
    $(document).on('click', '.deleteCustomText', function() {
      var textId = $(this).attr("id");
       swal({
          title: 'Are you sure you want to delete this text ?',
          text: '',
          icon: 'warning',
          buttons: true,
          dangerMode: true,
        })
      .then((willDelete) => {
        if (willDelete) {
          $.ajax({
            method: "POST",
            url: "<?php echo base_url(); ?>communicationbook/deleteCustomText/",
            data: ({
              textId: textId
            }),
            cache: false,
            success: function(html) {
              loadCustomData();
            }
          });
        }
      });
    });
  });
  </script>
  <script type="text/javascript">
    $(document).ready(function() {
      $.ajax({
        url:"<?php echo base_url(); ?>communicationbook/fetchCommunicationBookTeacher/",
        method:"POST",
        beforeSend: function() {
          $('.sentCommunicationBookList').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="84" height="84" id="loa">');
        },
        success:function(data){
          $('.sentCommunicationBookList').html(data);
        }
      })
    });
    $(document).on('click', '.viewComBook', function() {
      var viewlessonplan = $(this).attr("id");
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>communicationbook/viewComBookId/",
        data: ({
          viewlessonplan: viewlessonplan
        }),
        cache: false,
        success: function(html) {
          $(".comBookPrintHere").html(html);
        }
      });
    });
    function codespeedy(){
      var print_div = document.getElementById("printLessonPlanGs");
      var print_area = window.open();
      print_area.document.write(print_div.innerHTML);
      print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" type="text/css" />');
      print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css" type="text/css" />');
      print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css" type="text/css" />');
      print_area.document.close();
      print_area.focus();
      print_area.print();
    }
  </script>
  <script>
  $(document).ready(function() {  
    function unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_notification/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.notification-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-notification').html(data.unseen_notification);
          }
        }
      });
    }  
    function inbox_unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
        method: "POST",
        data: ({
            view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.inbox-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-inbox').html(data.unseen_notification);
          }
        }
      });
    }
    unseen_notification();
    inbox_unseen_notification();
    $(document).on('click', '.seen_noti', function() {
        $('.count-new-notification').html('');
        inbox_unseen_notification('yes');
    });
    $(document).on('click', '.seen', function() {
        $('.count-new-inbox').html('');
        inbox_unseen_notification('yes');
    });
    setInterval(function() {
      unseen_notification();
      inbox_unseen_notification();
    }, 5000);
    });
  </script>
</body>

</html>