<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/custom.css">
  <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <?php include('bgcolor.php'); ?>
            <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">
             <div class="row">
              <?php foreach($exam as $exams){ 
                $id=$exams->examname;
                $subject=$exams->subject;
                $grade=$exams->grade; ?>
              <div class="col-12 col-md-3 col-lg-3 delete_mem<?php echo $id ?><?php echo $subject ?><?php echo $grade ?>">
                <article class="article article-style-c">
                  <div class="article-details">
                    <div class="article-category">
                      <div class="bullet"></div>
                       <a href="#"><?php echo $exams->datecreated; ?></a>
                       <?php if($exams->teacher == $_SESSION['username']){ ?>
                      <input type="hidden" id="subject" name="subject" value="<?php echo $exams->subject; ?>">
                      <input type="hidden" id="grade" name="grade" value="<?php echo $exams->grade; ?>">
                       <a href="#">
                        <button class="btn btn-default deletelesson" name="deletelesson" type="submit"
                          id="<?php echo $exams->examname; ?>">
                          <i class="fas fa-trash"></i>
                        </button>
                       </a>
                     <?php } ?>
                    </div>
                    <div class="article-title">
                    <h2><a href="#"><?php echo $exams->subject;echo ' (Gr:'; echo $exams->grade.')';?></a></h2>
                    </div>
                    <p><?php echo $exams->examname; ?></p>
                    <div class="article-cta">
                    <form action="<?php echo base_url()?>readexam/" method="POST">
                      <input type="hidden" name="subject" value="<?php echo $exams->subject;?>">
                        <button name="readmore" value="<?php echo $exams->examname; ?>" class="btn btn-info" type="submit">Read
                        </button>
                   </form>
                   <form action="<?php echo base_url()?>examresult/" method="POST">
                      <input type="hidden" name="subject" value="<?php echo $exams->subject;?>">
                        <button name="viewresult" value="<?php echo $exams->examname; ?>" class="btn btn-default" type="submit">View Result
                        </button>
                   </form>
                   </div>
                    <div class="article-user">
                      <img alt="image" src="<?php echo base_url(); ?>/profile/<?php echo $exams->profile;?>">
                      <div class="article-user-details">
                        <div class="user-detail-name">
                          <a href="#"><?php echo $exams->fname;
                          echo' '; echo $exams->mname;?></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </article>
              </div>
             <?php } ?>
            </div>
          </div>
        </section>
      </div>
      <footer class="main-footer">
        <div class="footer-left">
         Call:+251967829025 &nbsp;&nbsp;
        	Copyright &copy <?php echo date('Y');?>
          <a href="https://www.grandstande.com" target="_blanck">GrandStand</a>
          All rights are Reserved.
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>

  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
  
<script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass();
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='white']").addClass("active");
      $(".selectgroup-input[value|='1']").prop("checked", true);
    } else {
      $("body").removeClass();
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='black']").addClass("active");
      $(".selectgroup-input[value|='2']").prop("checked", true);
    }
  });
</script>
<script type="text/javascript" language="javascript"> 
  var bgcolor_now=document.getElementById("bgcolor_now").value;
  if (bgcolor_now == "1") {
    $("body").removeClass();
    $("body").addClass("light");
    $("body").addClass("light-sidebar");
    $("body").addClass("theme-white");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='white']").addClass("active");
    $(".selectgroup-input[value|='1']").prop("checked", true);
  }else {
    $("body").removeClass();
    $("body").addClass("dark");
    $("body").addClass("dark-sidebar");
    $("body").addClass("theme-black");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='black']").addClass("active");
    $(".selectgroup-input[value|='2']").prop("checked", true);
  } 
</script> 
  <script>
    $(document).ready(function() {
    $('.deletelesson').click(function() {    
        var lessonid = $(this).attr("id");
        var subject = $("#subject").val();
        var grade = $("#grade").val();
        if (confirm("Are you sure you want to delete this Post ?")) {
            $.ajax({
                method: "GET",
                url: "<?php echo base_url(); ?>viewexam",
                data: ({
                    lessonid: lessonid,
                    subject:subject,
                    grade:grade
                }),
                cache: false,
                success: function(html) {
                    $(".delete_mem" + lessonid + subject + grade).fadeOut('slow');
                }
            });
        } else {
            return false;
        }
    });
});
</script>
  
<script>
    $(document).ready(function() {  
    function unseen_notification(view = '') { 
            $.ajax({
                url: "<?php echo base_url() ?>fetch_unseen_notification/",
                method: "POST",
                data: ({
                    view: view
                }),
                dataType: "json",
                success: function(data) {
                    $('.notification-show').html(data.notification);
                    if (data.unseen_notification > 0) {
                        $('.count-new-notification').html(data.unseen_notification);
                    }
                }
            });
        }  
        function inbox_unseen_notification(view = '') { 
            $.ajax({
                url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
                method: "POST",
                data: ({
                    view: view
                }),
                dataType: "json",
                success: function(data) {
                    $('.inbox-show').html(data.notification);
                    if (data.unseen_notification > 0) {
                        $('.count-new-inbox').html(data.unseen_notification);
                    }
                }
            });
        }
        unseen_notification();
        inbox_unseen_notification();
        $(document).on('click', '.seen_noti', function() {
            $('.count-new-notification').html('');
            inbox_unseen_notification('yes');
        });
        $(document).on('click', '.seen', function() {
            $('.count-new-inbox').html('');
            inbox_unseen_notification('yes');
        });
        setInterval(function() {
          unseen_notification();
          inbox_unseen_notification();
        }, 5000);

    });
    </script>
</body>

</html>