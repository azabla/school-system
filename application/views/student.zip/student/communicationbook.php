<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
 <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body"> 
           <?php include('bgcolor.php'); ?>
            <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">
            <div class="card">
              <div class="card-header">
                <h5 class="header-title">Communication Book</h5>
              </div>
            </div>
            <div class="myCommunicationBookList"></div>
          </div>
        </section>
        <div class="modal fade" id="viewMyComBookNow" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">
                  <button class="btn btn-default printlessonplan" onclick="codespeedy()" name="printlessonplan" type="submit" id="">
                      <span class="text-warning">Print <i class="fas fa-print"></i></span>
                  </button></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="myComBookPrintHere"> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php include('footer.php'); ?>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() { 
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Mycommunicationbook/fetchMyCommBook/",
        beforeSend: function() {
          $('.myCommunicationBookList').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">'
            );
        },
        success: function(data) {
          $(".myCommunicationBookList").html(data);
        }
      });
    });
    $(document).on('click', '.viewmyComBook', function() {
      var viewlessonplan = $(this).attr("id");
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Mycommunicationbook/viewComBookId/",
        data: ({
          viewlessonplan: viewlessonplan
        }),
        cache: false,
        success: function(html) {
          $(".myComBookPrintHere").html(html);
        }
      });
    });
    function codespeedy(){
      var print_div = document.getElementById("printLessonPlanGs");
      var print_area = window.open();
      print_area.document.write(print_div.innerHTML);
      print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" type="text/css" />');
      print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css" type="text/css" />');
      print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css" type="text/css" />');
      print_area.document.close();
      print_area.focus();
      print_area.print();
    }
    $(document).on('click', '.sendMyReply', function() {
      var comID = $(this).attr("value");
      var replyText=$("#replayComText"+comID).val();
      if($("#replayComText"+comID).val() !='' ){
        swal({
          title: 'Are you sure?',
          text: 'Once You send,you can not edit or delete the reply text.',
          icon: 'warning',
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            $.ajax({
              method: "POST",
              url: "<?php echo base_url(); ?>Mycommunicationbook/replyComBook/",
              data: ({
                comID: comID,
                replyText:replyText
              }),
              cache: false,
              beforeSend: function() {
                $('#replyedTextHere'+comID ).html( 'Sending...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
              },
              success: function(html) {
                $("#replyedTextHere"+comID).html(html);
                $("#replayComText"+comID).val('');
              }
            });
          }
        });
      }
    });
  </script>
  <script>
  $(document).ready(function() {
  function unseenComBook(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>Mycommunicationbook/unseenComBook/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.notification-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-notification').html(data.unseen_notification);
          }
        }
      });
    }  
    function unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_notification/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.notification-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-notification').html(data.unseen_notification);
          }
        }
      });
    }  
    function inbox_unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
        method: "POST",
        data: ({
            view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.inbox-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-inbox').html(data.unseen_notification);
          }
        }
      });
    }
    unseenComBook();
    unseen_notification();
    inbox_unseen_notification();
    $(document).on('click', '.seen_noti', function() {
        $('.count-new-notification').html('');
        inbox_unseen_notification('yes');
    });
    $(document).on('click', '.seen', function() {
        $('.count-new-inbox').html('');
        inbox_unseen_notification('yes');
    });
    $(document).on('click', '.seecomBook', function() {
        $('.count-new-comBook').html('');
        unseenComBook('yes');
    });
    setInterval(function() {
      unseenComBook();
      unseen_notification();
      inbox_unseen_notification();
    }, 5000);
    });
  </script>
</body>

</html>