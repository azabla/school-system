         <div class="sidebar-brand">
          <a href="#"> <img alt="image" src="<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>" style="height:35px;width:35px;border-radius: 3em;" class="header-logo" /> 
              <span class="logo-name"> 
                <?php foreach($schools as $school) {
                  echo $school->name;}
                  ?>
              </span>
            </a>
          </div>
          <ul class="sidebar-menu">
            <li class="dropdown">
              <a href="<?php echo base_url(); ?>mydashboard/?my-dashboard/" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
            </li>
            <li class="dropdown active">
              <a href="<?php echo base_url(); ?>home/" class="nav-link"><i data-feather="home"></i><span>Home</span></a>
            </li>
            
            <li>
              <a href="<?php echo base_url(); ?>myattendance/" class="nav-link"><i data-feather="user-check"></i><span>Attendance</span></a>
            </li>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>mycommunicationbook/?student-communication-book/"><i data-feather="message-square"></i><span>Communication Book</span>
              </a>
            </li>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <i data-feather="book-open"></i>
                <span>Lesson/Worksheet</span>
              </a>
            <ul class="dropdown-menu"> 
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>mylesson/"><i data-feather="book-open"></i>
                <span>View Lesson/Worksheet</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>replayworksheet/">
                <i data-feather="book-open"></i>
                <span>Answer Worksheet</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>sentworksheet/">
                <i data-feather="book-open"></i>
                <span>Sent Worksheet</span>
              </a>
             </li>
             </ul>
            </li>
             <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <i data-feather="code"></i>
                <span>Exam</span>
              </a>
            <ul class="dropdown-menu">
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>myexam/"><i data-feather="code"></i>
                <span>New Exam</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>myexamresult/"><i data-feather="code"></i>
                <span>Exam Result</span>
              </a>
             </li>
             </ul>
            </li>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>myresult/"><i data-feather="book"></i><span>View Result</span>
              </a>
            </li>
            
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>mypayment/"><i data-feather="dollar-sign"></i><span>Payment Report</span>
              </a>
            </li>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>mylibrary/"><i data-feather="book-open"></i><span>E-Library</span>
              </a>
            </li>
            <li>
              <a class="nav-link" href="#"><i data-feather="award"></i><span>Competition</span>
              </a>
            </li>
            
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Messages</span></a>
              <ul class="dropdown-menu">
              <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='Chat' order by id ASC "); 
              if($usergroupPermission->num_rows()>0){ ?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>mychat/">Live Chat</a></li>
                <li><a class="nav-link" href="<?php echo base_url(); ?>newcompose/">Compose</a></li>
              <?php } else{ ?>
              <?php } ?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>myinbox/">Inbox</a></li>
                <li><a class="nav-link" href="<?php echo base_url(); ?>isent/">Sent</a></li>
              
              </ul>
            </li>
            
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>myschoolgallery/"><i data-feather="image"></i><span>Gallery</span>
              </a>
            </li>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>mydocuments/"><i data-feather="file"></i><span>My Documents</span>
              </a>
            </li>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="moon"></i><span>Dark Mode</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="#">
                  <label class="selectgroup-item">
                    <input type="radio" id="changecolor" name="value" value="1" class="selectgroup-input-radio select-layout" checked>
                    <i data-feather="sun"></i>Light
                  </label></a>
                </li>
                <li><a class="nav-link" href="#">
                  <label class="selectgroup-item">
                    <input type="radio" id="changecolor" name="value" value="2" class="selectgroup-input-radio select-layout">
                   <i data-feather="moon"></i> Dark
                  </label></a>
                </li>
              </ul>
            </li>
           
          </ul>