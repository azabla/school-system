<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"><div class="loaderIcon"></div></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <?php include('myheaderdashboard.php'); ?>
      <div class="main-contentDashboard">
        <section class="section">
          <?php include('bgcolor.php'); ?>
          <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">

          <h5 class="font-25" id="ENS" > <a href="<?php echo base_url(); ?>home/?student-home-page/" class="btn btn-default"><i data-feather="home"></i>Back To Home </a></h5>
            

          <div class="row ">
            <div class="col-xl-6 col-lg-6 col-12">
              <div class="card l-bg-green">
                <div class="card-statistic-3">
                  <div class="card-icon card-icon-large"><i class="fa fa-award"></i></div>
                  <div class="card-content">
                    <h4 class="card-title">My Result</h4>
                    <span class="table-responsive" id="myMarkResult" style="height:30vh"></span>
                    <div class="progress mt-1 mb-1" data-height="8">
                      <div class="progress-bar l-bg-purple" role="progressbar" data-width="25%" aria-valuenow="25"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0 text-sm">
                      <span class="mr-2"><i class="fa fa-arrow-up"></i> 12%</span>
                      <span class="text-nowrap">Since last Quarter</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-12">
              <div class="card l-bg-cyan">
                <div class="card-statistic-3">
                  <div class="card-icon card-icon-large"><i class="fa fa-user-check"></i></div>
                  <div class="card-content">
                    <h4 class="card-title">My Attendance</h4>
                    <span class="table-responsive" id="myAttendanceData" style="height:30vh"></span>
                    <div class="progress mt-1 mb-1" data-height="8">
                      <div class="progress-bar l-bg-orange" role="progressbar" data-width="25%" aria-valuenow="25"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0 text-sm">
                      <span class="mr-2"><i class="fa fa-arrow-up"></i> 10%</span>
                      <span class="text-nowrap">Since last Quarter</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-6">
              <div class="card l-bg-purple">
                <div class="card-statistic-3">
                  <div class="card-icon card-icon-large"><i class="fa fa-envelope"></i></div>
                  <div class="card-content">
                    <a href="<?php echo base_url(); ?>mycommunicationbook/?student-communication-book-page/" class="text-white"><h4 class="card-title">Communication Book </h4></a>
                    <!-- <div class="progress mt-1 mb-1" data-height="8">
                      <div class="progress-bar l-bg-cyan" role="progressbar" data-width="25%" aria-valuenow="25"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0 text-sm">
                      <span class="mr-2"><i class="fa fa-arrow-up"></i> 10%</span>
                      <span class="text-nowrap">Since last month</span>
                    </p> -->
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-6">
              <div class="card l-bg-orange">
                <div class="card-statistic-3">
                  <div class="card-icon card-icon-large"><i class="fa fa-home"></i></div>
                  <div class="card-content">
                    <a href="<?php echo base_url(); ?>mylibrary/?student-library-page/" class="text-white"><h4 class="card-title">Library </h4></a>
                    <span></span>
                   <!--  <div class="progress mt-1 mb-1" data-height="8">
                      <div class="progress-bar l-bg-green" role="progressbar" data-width="25%" aria-valuenow="25"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0 text-sm">
                      <span class="mr-2"><i class="fa fa-arrow-up"></i> 10%</span>
                      <span class="text-nowrap">Since last month</span>
                    </p> -->
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-6">
              <div class="card l-bg-green">
                <div class="card-statistic-3">
                  <div class="card-icon card-icon-large"><i class="fa fa-envelope"></i></div>
                  <div class="card-content">
                    <a href="<?php echo base_url(); ?>myinbox/?student-message-page/" class="text-white"><h4 class="card-title"><i data-feather="mail"></i> Messages </h4> </a>
                    <span></span>
                   <!--  <div class="progress mt-1 mb-1" data-height="8">
                      <div class="progress-bar l-bg-green" role="progressbar" data-width="25%" aria-valuenow="25"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0 text-sm">
                      <span class="mr-2"><i class="fa fa-arrow-up"></i> 10%</span>
                      <span class="text-nowrap">Since last month</span>
                    </p> -->
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-6">
              <div class="card l-bg-cyan">
                <div class="card-statistic-3">
                  <div class="card-icon card-icon-large"><i class="fa fa-home"></i></div>
                  <div class="card-content">
                    <a href="<?php echo base_url(); ?>myschoolgallery/?student-gallery-page/" class="text-white"><h4 class="card-title"><i data-feather="image"></i> Gallery </h4></a>
                    <span></span>
                   <!--  <div class="progress mt-1 mb-1" data-height="8">
                      <div class="progress-bar l-bg-green" role="progressbar" data-width="25%" aria-valuenow="25"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0 text-sm">
                      <span class="mr-2"><i class="fa fa-arrow-up"></i> 10%</span>
                      <span class="text-nowrap">Since last month</span>
                    </p> -->
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-6">
              <div class="card l-bg-purple">
                <div class="card-statistic-3">
                  <div class="card-icon card-icon-large"><i class="fa fa-home"></i></div>
                  <div class="card-content">
                    <a href="<?php echo base_url(); ?>mydocuments/?student-document-page/" class="text-white"><h4 class="card-title"><i data-feather="file"></i> My Documents </h4></a>
                    <span></span>
                   <!--  <div class="progress mt-1 mb-1" data-height="8">
                      <div class="progress-bar l-bg-green" role="progressbar" data-width="25%" aria-valuenow="25"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0 text-sm">
                      <span class="mr-2"><i class="fa fa-arrow-up"></i> 10%</span>
                      <span class="text-nowrap">Since last month</span>
                    </p> -->
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-6">
              <div class="card l-bg-orange">
                <div class="card-statistic-3">
                  <div class="card-icon card-icon-large"><i class="fa fa-home"></i></div>
                  <div class="card-content">
                    <a href="<?php echo base_url(); ?>mylesson/?student-lesson-worksheet-page/" class="text-white"><h4 class="card-title"><i data-feather="file"></i> My Lesson & Worksheet </h4></a>

                    <span></span>
                   <!--  <div class="progress mt-1 mb-1" data-height="8">
                      <div class="progress-bar l-bg-green" role="progressbar" data-width="25%" aria-valuenow="25"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0 text-sm">
                      <span class="mr-2"><i class="fa fa-arrow-up"></i> 10%</span>
                      <span class="text-nowrap">Since last month</span>
                    </p> -->
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12">
              <div class="text-center" id="ENS" style="margin-top: 150px;">
                <?php include('footer.php'); ?>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script type="text/javascript">
  $(document).ready(function(){
    loadAttendanceData();
    loadMarkData();
    function loadAttendanceData()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>mydashboard/fetchMyAttendance/",
        method:"POST",
        beforeSend: function() {
          $('#myAttendanceData').html( 'Loading Attendance...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success:function(data){
          $('#myAttendanceData').html(data);
        }
      })
    }
    function loadMarkData()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>mydashboard/fetchMyMark/",
        method:"POST",
        beforeSend: function() {
          $('#myMarkResult').html( 'Loading Mark...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success:function(data){
          $('#myMarkResult').html(data);
        }
      })
    }
  });
</script>
  <script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass("dark");
      $("body").removeClass("dark-sidebar");
      $("body").removeClass("theme-black");
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
    } else {
      $("body").removeClass("light");
      $("body").removeClass("light-sidebar");
      $("body").removeClass("theme-white");
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
    }
  });
</script>
<script type="text/javascript" language="javascript"> 
  var bgcolor_now=document.getElementById("bgcolor_now").value;
  if (bgcolor_now == "1") {
    $("body").removeClass("dark");
    $("body").removeClass("dark-sidebar");
    $("body").removeClass("theme-black");
    $("body").addClass("light");
    $("body").addClass("light-sidebar");
    $("body").addClass("theme-white");
  }else {
    $("body").removeClass("light");
    $("body").removeClass("light-sidebar");
    $("body").removeClass("theme-white");
    $("body").addClass("dark");
    $("body").addClass("dark-sidebar");
    $("body").addClass("theme-black"); 
  } 
</script>
<script>
  $(document).ready(function() {
    function my_mark_status(view = '') {
      $.ajax({
        url: "<?php echo base_url() ?>my_mark_status/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
         $('.notification-show-mark').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-notification').html(data.unseen_notification);
          }
        }
      });
    } 
    function myseen_attendance(view = '') {
      $.ajax({
        url: "<?php echo base_url() ?>my_unseen_attendance/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.notification-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-notification').html(data.unseen_notification);
          }
        }
      });
    }  
    function inbox_unseen_notification(view = '') {
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.inbox-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-inbox').html(data.unseen_notification);
          }
        }
      });
    }
    my_mark_status();
    myseen_attendance();
    inbox_unseen_notification();
    $(document).on('click', '.seen_noti', function() {
      $('.count-new-notification').html('');
      myseen_attendance('yes');
      my_mark_status('yes');
    });
    $(document).on('click', '.seen', function() {
      $('.count-new-inbox').html('');
      inbox_unseen_notification('yes');
    });
    setInterval(function() {
      my_mark_status();
      myseen_attendance();
      inbox_unseen_notification();
    }, 5000);
  });
</script>
</body>

</html>