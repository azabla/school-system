         <div class="sidebar-brand">
          <a href="#"> <img alt="image" src="<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>" style="height:35px;width:35px;border-radius: 3em;" class="header-logo" /> 
              <span class="logo-name"> 
                <?php foreach($schools as $school) {
                  echo $school->name;}
                  ?>
              </span>
            </a>
          </div>
          <ul class="sidebar-menu">
            <li class="dropdown active">
              <a href="<?php echo base_url(); ?>home/" class="nav-link"><i data-feather="home"></i><span>Home</span></a>
            </li>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){  ?>
              <li class="dropdown">
                <a href="#" class="menu-toggle nav-link has-dropdown">
                  <i data-feather="user-plus"></i>
                  <span>Student</span>
                </a>
                <ul class="dropdown-menu">
                  <?php $uperStuView=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Student' and allowed='StudentVE' order by id ASC ");
                  if($uperStuView->num_rows()>0){  ?>
                      <li><a class="nav-link" href="<?php echo base_url(); ?>mystudent/?my-student-page">View Student</a> </li>
                    <li>
                      <a class="nav-link" href="<?php echo base_url(); ?>mystudentsummaryrecordreport/"><span>Summary Report</span>
                      </a>
                    </li>
                  <?php } ?>
                </ul>
              </li>
              <?php } ?>

              <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' order by id ASC ");  
            if($usergroupPermission->num_rows()>0){ ?>
              <li class="dropdown">
                 <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="users"></i><span>Staffs & Placement</span>
                  </a>
                <ul class="dropdown-menu">
                  <?php $userpStaffTP=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='staffPl' order by id ASC "); if($userpStaffTP->num_rows()>0){ ?>
                    <li><a class="nav-link" href="<?php echo base_url(); ?>mystaffplacement/">Teacher Placement</a> </li>
                  <?php } $userpStaffHrP=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='hoomeroomPl' order by id ASC "); if($userpStaffHrP->num_rows()>0){ ?>
                    <li><a class="nav-link" href="<?php echo base_url(); ?>myhomeroomplacement/">Homeroom Placement</a> </li>
                  <?php } $userpStaffPhone=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Staff' and allowed='staffPhone' order by id ASC "); if($userpStaffPhone->num_rows()>0) { ?>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>mystaffphone/">Staffs phone List</a> </li>
                  <?php } ?>
                </ul>
              </li>
            <?php } ?>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='IDCard' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
               <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="list"></i><span>ID Card</span>
                </a>
              <ul class="dropdown-menu">
                 <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='IDCard' and allowed='StaffIDCard' order by id ASC ");  
                 if($usergroupPermission->num_rows()>0){ ?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>mystaffidcard/">Staff ID</a>
                </li>
                 <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='IDCard' and allowed='StudentIDCard' order by id ASC ");if($usergroupPermission->num_rows()>0){ ?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>myidcard/">Student ID</a>
                </li>
                <?php } ?>
              </ul>
            </li>
            <?php } ?>


            <?php  $userPerStuAtt=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Attendance' and allowed='studentAttendance' order by id ASC ");  if($userPerStuAtt->num_rows()>0){?>
              <li><a class="nav-link" href="<?php echo base_url(); ?>mystudentattendance/"><i data-feather="user-check"></i><span>Student Attendance</span></a> </li>
            <?php } $userPerStaAtt=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='Attendance' and allowed='staffAttendance' order by id ASC ");  if($userPerStaAtt->num_rows()>0){?>
              <li><a class="nav-link" href="<?php echo base_url(); ?>mystaffattendance/"><i data-feather="user-check"></i><span>Staff Attendance</span></a> </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='communicationbook' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>communicationbookteacher/?teacher-communication-book/"><i data-feather="message-square"></i><span>Communication Book</span> </a> </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='lessonplan' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <i data-feather="book-open"></i>
                <span>Manage Lesson Plan</span>
              </a>
            <ul class="dropdown-menu">
              <?php $upAddLplan=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='lessonplan' and allowed='addlessonplan' order by id ASC ");  if($upAddLplan->num_rows()>0){ ?>
              <li>
                <a class="nav-link" href="<?php echo base_url(); ?>mylessonplan/?add-lesson-plan-page/">
                  <span>Add Lesson Plan</span>
                </a>
              </li>
            <?php } $upViewLplan=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='lessonplan' and allowed='viewlessonplan' order by id ASC ");  
            if($upViewLplan->num_rows()>0){?>
              <li>
                <a class="nav-link" href="<?php echo base_url(); ?>viewmylessonplan/?view-lesson-plan-page/">
                  <span>View Lesson Plan</span>
                </a>
              </li>
            <?php }?>
            </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='homeworkworksheet' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <i data-feather="book-open"></i>
                <span>Homework/Worksheet</span>
              </a>
            <ul class="dropdown-menu">
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>addstudentlesson/">
                <i data-feather="book-open"></i>
                <span>Add HW/Worksheet</span>
              </a>
             </li>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>viewstudentlesson/"><i data-feather="book-open"></i>
                <span>View HW/Worksheet</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>viewmyansweredworksheet/"><i data-feather="book-open"></i>
                <span>Answered Worksheet</span>
              </a>
             </li>
             </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='studentexam' order by id ASC ");  if($usergroupPermission->num_rows()>0){?>
             <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <i data-feather="code"></i>
                <span>Exam</span>
              </a>
            <ul class="dropdown-menu">
            <li>
              <a class="nav-link" href="#"><i data-feather="code"></i>
                <span>View Exam</span>
              </a>
             </li>
             </ul>
            </li>
            <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' order by id ASC ");  if($usergroupPermission->num_rows()>0){?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
                <i data-feather="layout"></i><span>Mark</span>
              </a>
            <ul class="dropdown-menu">
              <?php $uaddMark=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='addstudentmark' order by id ASC ");  if($uaddMark->num_rows()>0){ ?>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>addstudentresult/">
                <span>Add New result</span>
              </a>
             </li>
             <?php } $markformat=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='studentmarkformat' order by id ASC ");  if($markformat->num_rows()>0){ ?>
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>markformat/">
                <span>Prepare Mark Format</span>
              </a>
             </li>
            <?php } $markformat=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='approvemark' order by id ASC ");  if($markformat->num_rows()>0){ ?>
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>approvestudentmark/">
                <span>Approve Mark</span>
              </a>
              </li>
            <?php } ?>
            <?php $markformat=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='addstudentmark' order by id ASC ");  if($markformat->num_rows()>0){ ?>
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>importmark/">
                <span>Import excel mark </span>
              </a>
              </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>editstudentmark/">
                <span>Edit Mark</span>
              </a>
              </li>
              <?php } $uaddMark=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='viewstudentmark' order by id ASC ");  if($uaddMark->num_rows()>0){ ?>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>studentresult/">
                <span>View Result</span>
              </a>
              </li>
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>mymarkprogress/">
                <span>Mark Progress</span>
              </a>
              </li>
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>myngmark/">
                <span>NG Mark Result</span>
              </a>
              </li>
              <li>
              <a class="nav-link" href="<?php echo base_url(); ?>studentmarkanalysis/">
                <span>Mark Analysis</span>
              </a>
              </li>
              <?php } ?>
              <?php $userpStaffAI=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='StudentMark' and allowed='lockstudentmark' order by id ASC "); if($userpStaffAI->num_rows()>0){ ?>
                <li>
                <a class="nav-link" href="<?php echo base_url(); ?>lockunlockmystudentmark/?lock-unlock-page">
                  <span>Lock/Unlock Mark</span>
                </a>
              </li>
              <?php } ?>
             </ul>
            </li>
            <?php } ?>
            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' order by id ASC "); 
            if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="grid"></i><span>Card & Roster</span></a>
              <ul class="dropdown-menu">
                <?php $rpPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='reportcard' order by id ASC "); 
                if($rpPermission->num_rows()>0){ ?>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>studentreportcard/">Grade Report Card</a></li>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>studentkgreportcard/">KG Report Card</a></li>
                <?php } $roPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='roster' order by id ASC ");
                if($roPermission->num_rows()>0){ ?>
                  <li><a class="nav-link" href="<?php echo base_url(); ?>studentroster/">Student Roster</a></li>
                <?php } $trPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='transcript' order by id ASC "); 
                  if($trPermission->num_rows()>0){ ?>
                    <li><a class="nav-link" href="<?php echo base_url(); ?>studentranscript/">Transcript</a></li>
                  <?php }?>
              </ul>
            </li>
            <?php } ?>
            <?php $uaddMark=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='rankReport' order by id ASC ");
            if($uaddMark->num_rows()>0){ ?>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>studentrankreport/"><i data-feather="award"></i><span>Student Rank Report</span>
              </a>
            </li>
           <?php } ?>
            <?php $uaddMark=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='studentCard' and allowed='Statistics' order by id ASC ");  if($uaddMark->num_rows()>0){ ?>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>resultstatistics/"><i data-feather="activity"></i><span>Student Result Statistics</span>
              </a>
            </li>
          <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='studentbasicskill' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown">
              <i data-feather="clipboard"></i><span>Basic Skill & Conduct</span>
              </a>
            <ul class="dropdown-menu">
              <?php if($_SESSION['usertype']==='Director'){ ?>
              <li>
              <a class="nav-link" href="#"><span>Add BS Name & Type</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>bsformat/"><span>Export BS format</span>
              </a>
             </li>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>importbskill/"><span>Import Basic Skill </span>
              </a>
             </li>
           <?php } ?>
             <li>
              <a class="nav-link" href="<?php echo base_url(); ?>viewbs/"><span>View Student BS</span>
              </a>
             </li>
             </ul>
            </li>
            <?php } ?>

            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='ImportExport' order by id ASC ");  if($usergroupPermission->num_rows()>0){ ?>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="arrow-down-circle"></i><span>Import & Export</span></a>
              <ul class="dropdown-menu">
                <?php $exportFile=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='ImportExport' and allowed='exportFile' order by id ASC ");  if($exportFile->num_rows()>0){ ?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>exportformat/"><i data-feather="arrow-down-circle"></i>Export</a></li>
              <?php } $importFile=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and tableName='ImportExport' and allowed='importFile' order by id ASC ");  if($importFile->num_rows()>0){?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>importfile/"><i data-feather="arrow-up-circle"></i>Import</a></li>
              <?php } ?>
              </ul>
            </li>
             <?php } $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='teacherperformance' order by id ASC "); 
             if($usergroupPermission->num_rows()>0){ if($_SESSION['usertype']!=='Teacher'){ ?>
              <li>
                <a class="nav-link" href="<?php echo base_url(); ?>teacherperformance/?director-teacher-performance-page/"><i data-feather="user-plus"></i><span>Teachers Performance</span>
                </a>
              </li>
             <?php } if($_SESSION['usertype']==='Teacher'){ ?>
              <li>
                <a class="nav-link" href="<?php echo base_url(); ?>myperformance/?my-performance-page/"><i data-feather="user-plus"></i><span>My Performance</span>
                </a>
              </li>
            <?php } } ?>
            <li>
              <a class="nav-link" href="#"><i data-feather="users"></i><span>Competition</span>
              </a>
            </li>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Messages</span></a>
              <ul class="dropdown-menu">
              <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='Chat' order by id ASC "); 
              if($usergroupPermission->num_rows()>0){ ?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>mchat/">Live Chat</a></li>
                <li><a class="nav-link" href="<?php echo base_url(); ?>messagecompose/">Compose</a></li>
              <?php } else{?>
              <?php } ?>
                <li><a class="nav-link" href="<?php echo base_url(); ?>messageinbox/">Inbox</a></li>
                <li><a class="nav-link" href="<?php echo base_url(); ?>messagesent/">Sent</a></li>
              </ul>
            </li>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>schoolgallery/"><i data-feather="image"></i><span>Gallery</span>
              </a>
            </li>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>document/"><i data-feather="file"></i><span>My Documents</span>
              </a>
            </li>
            <?php $usergroupPermission=$this->db->query("SELECT * from usergrouppermission where usergroup='".$_SESSION['usertype']."' and allowed='summerclass' order by id ASC "); if($usergroupPermission->num_rows()>0){ ?>
            <li>
              <a class="nav-link" href="<?php echo base_url(); ?>mysummerclass/"><i data-feather="user-plus"></i><span>Summer Class</span>
              </a>
            </li>
          <?php }?>
           <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="moon"></i><span>Dark Mode</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="#">
                  <label class="selectgroup-item">
                    <input type="radio" id="changecolor" name="value" value="1" class="selectgroup-input-radio select-layout" checked>
                    <i data-feather="sun"></i>Light
                  </label></a>
                </li>
                <li><a class="nav-link" href="#">
                  <label class="selectgroup-item">
                    <input type="radio" id="changecolor" name="value" value="2" class="selectgroup-input-radio select-layout">
                   <i data-feather="moon"></i> Dark
                  </label></a>
                </li>
              </ul>
            </li>
          </ul>