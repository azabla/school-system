<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/summernote/summernote-bs4.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
 <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body"> 
           <?php include('bgcolor.php'); ?>
            <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">
            <div class="card">
              <div class="card-header">
                <h5 class="header-title">Communication Book</h5>
              </div>
            </div>
            <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">
                <div class="card">
                  <ul class="nav nav-tabs" id="myTab2" role="tablist">
                    <?php if($_SESSION['usertype'] == 'Director'){?>
                      <li class="nav-item">
                        <a class="nav-link" id="home-tab12" data-toggle="tab" 
                        href="#customText" role="tab" aria-selected="false"> 
                          Custom Text
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link seenBook showNonApprovedComBook" id="home-tab3" data-toggle="tab" 
                        href="#approvedCommunicationBook" role="tab" aria-selected="false"> 
                          Approve Com.Book <span class="badge badge-danger count-new-comBook"></span>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" id="home-tab1" data-toggle="tab" 
                        href="#newCommunicationBook" role="tab" aria-selected="true"> 
                          Send Com.Book</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link seenReplyComBook" id="home-tab2" data-toggle="tab" 
                        href="#sentCommunicationBook" role="tab" aria-selected="false">
                          Sent Com.Book <span class="badge badge-danger count-new-replayComBook"></span></a>
                      </li>
                    <?php } else{ ?>
                      
                      <li class="nav-item">
                        <a class="nav-link active" id="home-tab1" data-toggle="tab" 
                        href="#newCommunicationBook" role="tab" aria-selected="true"> 
                          New Com.Book</a>
                      </li>
                      <li class="nav-item seenReplyComBook">
                        <a class="nav-link" id="home-tab2" data-toggle="tab" 
                        href="#sentCommunicationBook" role="tab" aria-selected="false">
                          Sent Com.Book <span class="badge badge-danger count-new-replayComBook"></span></a>
                      </li>
                    <?php } ?>
                    <li class="nav-item">
                      <a class="nav-link seenReturnedBook showReturnedComBook" id="home-tab3" data-toggle="tab" href="#returnedCommunicationBook" role="tab" aria-selected="false">
                        Returned Com.Book<span class="badge badge-danger count-returnedcomBook"></span></a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-xs-12 col-sm-12 col-md-10 col-lg-10">
                <div class="tab-content tab-bordered" id="myTab3Content">
                  <div class="tab-pane fade show" id="customText" role="tabpanel" aria-labelledby="home-tab12">
                    <div class="row">
                      <div class="col-md-8 col-lg-8 col-8">
                        <input type="text" name="customTextName" id="customTextName" class="form-control" placeholder="Custom text here...">
                      </div>
                      <div class="col-md-4 col-lg-4 col-4">
                        <button class="btn btn-primary btn-block saveCustomText" id="saveCustomText">Save Text</button>
                      </div>
                    </div>
                    <div class="dropdown-divider"></div>
                    <div class="table-responsive  fetchCustomTextHere" style="height: 100vh;"></div>
                  </div>
                  <div class="tab-pane fade show" id="approvedCommunicationBook" role="tabpanel" aria-labelledby="home-tab3">
                    <div class="table-responsive approvedCommunicationBookList" style="height: 55vh;">
                      
                    </div>
                  </div>
                  <div class="tab-pane fade show active" id="newCommunicationBook" role="tabpanel" aria-labelledby="home-tab1">
                    <div class="card">
                      <div class="card-body">
                        <form id="saveCommunicationForm">
                          <div class="row">
                            <div class="col-lg-6 col-6">
                              <div class="form-group">
                               <select class="form-control selectric" required="required" name="gradesec" id="comGradesec">
                                  <option>--- Grade ---</option>
                                  <?php if($_SESSION['usertype']===trim('Director')){
                                    foreach($gradesec as $gradesecs){ ?>
                                      <option value="<?php echo $gradesecs->grade;?>">
                                       <?php echo $gradesecs->grade;?>
                                      </option>
                                  <?php } }else{ 
                                    foreach($gradesecTeacher as $gradesecs){ ?>
                                      <option value="<?php echo $gradesecs->grade;?>">
                                       <?php echo $gradesecs->grade;?>
                                      </option>
                                  <?php } }?>
                                </select>
                              </div>
                            </div>
                            <div class="col-lg-6 col-6">
                              <div class="form-group">
                                <select class="form-control comSubject" name="subject" id="comSubject">
                                  <option>--- Select Subject ---</option>
                                </select>
                              </div>
                            </div>
                            <div class="form-group col-lg-6 col-12 table-responsive"  id="user" style="height: 30vh;">
                            </div>
                            <div class="form-group col-lg-6 col-12">
                              <label>Select custom text to send from the following list</label>
                              <div class="table-responsive fetchCustomTexToSend" style="height:20vh"></div>
                              <textarea name="comNote" id="comNote" class="form-control comNote"> </textarea>
                            </div>
                            <div class="col-lg-12 col-12">
                              <button class="btn btn-primary btn-md btn-block" type="submit" name="viewmark">Submit</button>
                            </div>
                          </div>
                        </form>
                        <div class="communicationInfo"></div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade show" id="sentCommunicationBook" role="tabpanel" aria-labelledby="home-tab2">
                    <div class="sentCommunicationBookList"></div>
                  </div>
                  <div class="tab-pane fade show" id="returnedCommunicationBook" role="tabpanel" aria-labelledby="home-tab2">
                    <div class="returnedCommunicationBookList"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <div class="modal fade" id="editReturnedComBook" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="saveReturnedCommBookInfo"> </div>
              <div class="modal-body">
                <div class="returnedcomBookEditHere"> </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal fade" id="viewReturnedComBook" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">
                  <button class="btn btn-default " onclick="codespeedy()" name="" type="submit" id="">
                      <span class="text-warning">Print <i class="fas fa-print"></i></span>
                  </button></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="viewReturnedcomBookEditHere" id="printReturnedComBookNow"> </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal fade" id="viewComBookNow" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="comBookPrintHere"> </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal fade" id="commentComBook" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Comment Communication Book</h5>
              </div>
              <div class="card">  
                  <div class="card-header">
                    <div class="modal-body">
                      <div class="row">
                        <div class="col-lg-12 col-12 table-responsive">
                          <div class="communicationCommentInfo"></div>
                          <label for="Mobile"><a class="commentedTeacher"></a> </label>
                          <input type="hidden" name="comBookID" class="comBookID" value="">
                          <textarea name="commentCom" class="form-control summernote-simple commentCom"> </textarea>
                        </div>
                        <div class="col-lg-12 col-12">
                          <div class="form-group">
                            <button type="submit" id="saveComComments" name="post" class="btn btn-primary btn-sm btn-block"> Send Comment
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              <div class="modal-footer bg-whitesmoke">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
      </div>
       <footer class="main-footer">
        <div class="footer-left">
         Call:+251967829025 &nbsp;&nbsp;
          Copyright &copy <?php echo date('Y');?>
          <a href="https://www.grandstande.com" target="_blanck">Grandstande IT Solution Plc</a>
          All rights are Reserved.
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/summernote/summernote-bs4.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      loadCustomData();
      function loadCustomData()
      {
        $.ajax({
          url:"<?php echo base_url(); ?>communicationbookteacher/fetchCustomText/",
          method:"POST",
          beforeSend: function() {
            $('.fetchCustomTextHere').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
          },
          success:function(data){
            $('.fetchCustomTextHere').html(data);
          }
        })
      }
      $('#saveCustomText').on('click', function(event) {
        event.preventDefault();
        var customTextName=$('#customTextName').val();

        if($('#customTextName').val() =='')
        {
          swal({
            title: 'Oooops, Please select necessary fields.',
            text: '',
            icon: 'warning',
            buttons: true,
            dangerMode: true,
          })
        }else{
          $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>communicationbookteacher/postCustomText/",
          data: ({
            customTextName: customTextName
          }),
          cache: false,
          success: function(html){
            $('#customTextName').val('');
            loadCustomData();
          }
        });
      }
    });
    $(document).on('click', '.deleteCustomText', function() {
      var textId = $(this).attr("id");
       swal({
          title: 'Are you sure you want to delete this text ?',
          text: '',
          icon: 'warning',
          buttons: true,
          dangerMode: true,
        })
      .then((willDelete) => {
        if (willDelete) {
          $.ajax({
            method: "POST",
            url: "<?php echo base_url(); ?>communicationbookteacher/deleteCustomText/",
            data: ({
              textId: textId
            }),
            cache: false,
            success: function(html) {
              loadCustomData();
            }
          });
        }
      });
    });
  });
  loadCustomDataText();
  function loadCustomDataText()
  {
    $.ajax({
      url:"<?php echo base_url(); ?>communicationbookteacher/fetchCustomTextTosend/",
      method:"POST",
      beforeSend: function() {
        $('.fetchCustomTexToSend').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
      },
      success:function(data){
        $('.fetchCustomTexToSend').html(data);
      }
    })
  } 
  $(document).on('click', '.useThisText', function() {
    event.preventDefault();
    var oldText=$('#comNote').val();
    var stuID=$(this).attr("value");
    var newText=oldText+stuID+"\n";
    $("#comNote").val(newText);   
  });
  </script>
  <script type="text/javascript">
  function codespeedy(){
    var print_div = document.getElementById("printReturnedComBookNow");
    var print_area = window.open();
    print_area.document.write(print_div.innerHTML);
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" type="text/css" />');
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css" type="text/css" />');
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css" type="text/css" />');
    print_area.document.close();
    print_area.focus();
    print_area.print();
  }
</script>
  <script type="text/javascript">
    $(document).on('click', '.editReturnedComBookNow', function() {
      var comId = $(this).attr("id");
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Communicationbookteacher/editReturnedCommmbookDetail/",
        data: ({
          comId: comId
        }),
        beforeSend: function() {
          $('.returnedcomBookEditHere').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="84" height="84" id="loa">');
        },
        cache: false,
        success: function(html) {
          $(".returnedcomBookEditHere").html(html);
        }
      });
    });
    $(document).on('click', '.saveReturnedComBook', function() {
      var comId = $(this).attr("id");
      var comNote=$('.editReturnedCommBookSave').val();
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Communicationbookteacher/saveReturnedCommmbookDetail/",
        data: ({
          comId: comId,
          comNote:comNote
        }),
        beforeSend: function() {
          $('.saveReturnedCommBookInfo').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="84" height="84" id="loa">');
        },
        cache: false,
        success: function(html) {
          $(".saveReturnedCommBookInfo").html(html);
        }
      });
    });
     $(document).on('click', '.viewReturnedComBook', function() {
      var comId = $(this).attr("id");
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Communicationbookteacher/viewReturnedComBook/",
        data: ({
          comId: comId
        }),
        beforeSend: function() {
          $('.viewReturnedcomBookEditHere').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="84" height="84" id="loa">');
        },
        cache: false,
        success: function(html) {
          $(".viewReturnedcomBookEditHere").html(html);
        }
      });
    });
    $(document).on('click', '.showNonApprovedComBook', function() {
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Communicationbookteacher/fetchCommBookToapprove/",
        beforeSend: function() {
          $('.approvedCommunicationBookList').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="84" height="84" id="loa">');
        },
        cache: false,
        success: function(html) {
          $(".approvedCommunicationBookList").html(html);
        }
      });
    });

    $(document).on('click', '.viewComBook', function() {
      var viewlessonplan = $(this).attr("id");
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>communicationbookteacher/viewComBookId/",
        data: ({
          viewlessonplan: viewlessonplan
        }),
        cache: false,
        success: function(html) {
          $(".comBookPrintHere").html(html);
        }
      });
    });
  </script>
  <script type="text/javascript">
    loadReturnedCommBook();
    function loadReturnedCommBook()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>communicationbookteacher/fetchReturnedCommunicationBook/",
        method:"POST",
        beforeSend: function() {
          $('.returnedCommunicationBookList').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="84" height="84" id="loa">');
        },
        success:function(data){
          $('.returnedCommunicationBookList').html(data);
        }
      })
    }
    loadSubjectData();
    function loadSubjectData()
    {
      $.ajax({
        url:"<?php echo base_url(); ?>communicationbookteacher/fetchCommunicationBookTeacher/",
        method:"POST",
        beforeSend: function() {
          $('.sentCommunicationBookList').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="84" height="84" id="loa">');
        },
        success:function(data){
          $('.sentCommunicationBookList').html(data);
        }
      })
    }
    $(document).on('submit', '#saveCommunicationForm', function(event) {
      event.preventDefault();
      var comGradesec=$('#comGradesec').val();
      var comSubject=$('#comSubject').val();
      var comNote=$('.comNote').val();
      stuName=[];
      $("input[name='stuNameComBook']:checked").each(function(i){
        stuName[i]=$(this).val();
      });
      if( $('#comGradesec').val() =='')
      {
        alert("Oooops, Please select necessary fields.");
      }else{
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>communicationbookteacher/saveCommunicationBook/",
          data: ({
            comGradesec: comGradesec,
            comSubject:comSubject,
            stuName:stuName,
            comNote:comNote
          }),
          cache: false,
          success: function(html){
            $('.communicationInfo').html(html);
            loadSubjectData();
          }
        });
      }
    }); 
    $(document).ready(function() { 
      $.ajax({
        method: "POST",
        url: "<?php echo base_url(); ?>Communicationbookteacher/fetchCommBookToapprove/",
        beforeSend: function() {
          $('.approvedCommunicationBookList').html('<img src="<?php echo base_url(); ?>/img/loader.gif" alt="">' );
        },
        success: function(data) {
          $(".approvedCommunicationBookList").html(data);
        }
      });
    });
    $(document).on('click', '.approvComBook', function(event) {
      event.preventDefault();
      var stuID=$(this).attr('value');
      swal({
          title: 'Are you sure you want to approve this communication book?',
          text: '',
          icon: 'warning',
          buttons: true,
          dangerMode: true,
        })
      .then((willDelete) => {
        if (willDelete) {
          $.ajax({
            method: "POST",
            url: "<?php echo base_url(); ?>communicationbookteacher/approveCommunicationBook/",
            data: ({
              stuID: stuID
            }),
            cache: false,
            success: function(html){
              $('.approvedComBook' + stuID).fadeOut('slow');
            }
          });
        }
      });
    }); 
    $(document).on('click', '.rejectComBook', function(event) {
      event.preventDefault();
      var stuID=$(this).attr('value');
      swal({
          title: 'Are you sure you want to Reject this communication book?',
          text: '',
          icon: 'warning',
          buttons: true,
          dangerMode: true,
        })
      .then((willDelete) => {
        if (willDelete) {
          $.ajax({
            method: "POST",
            url: "<?php echo base_url(); ?>communicationbookteacher/rejectCommunicationBook/",
            data: ({
              stuID: stuID
            }),
            cache: false,
            success: function(html){
              $('.approvedComBook' + stuID).fadeOut('slow');
            }
          });
        }
      });
    });
    $(document).on('click', '.commentComBook', function(event) {
      var lessonID=$(this).attr('value');
      var teacherName=$(this).attr('id');
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>communicationbookteacher/commentedTeacher/",
          data: ({
            lessonID: lessonID,
            teacherName:teacherName
          }),
          cache: false,
          success: function(html){
            $('.commentedTeacher').html(html);
            $('.comBookID').html(lessonID);
          }
        });
      });
    $(document).on('click', '#saveComComments', function(event) {
      event.preventDefault();
      var commentText=$('.commentCom').val();
      var lessonID=$('.commentedTeacherName').val();
      if( $('.commentCom').val() =='')
      {
        alert("Oooops, Please select necessary fields.");
      }else{
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>communicationbookteacher/saveCommunicationBookComment/",
          data: ({
            commentText: commentText,
            lessonID:lessonID
          }),
          cache: false,
          success: function(html){
            $('.communicationCommentInfo').html(html);
          }
        });
      }
    }); 
</script>
  <script type="text/javascript">
  $(document).ready(function() {  
    $("#comGradesec").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>communicationbookteacher/fetchSubjectforMarkView/",
        data: "gradesec=" + $("#comGradesec").val(),
        beforeSend: function() {
          $('.comSubject').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">'
            );
        },
        success: function(data) {
          $(".comSubject").html(data);
        }
      });
    });
  });
  </script> 
  <script type="text/javascript">
    $(document).ready(function() {
      $("#comGradesec").bind("change", function() {
        var grade=$("#comGradesec").val();
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>Communicationbookteacher/fetchUsertype/",
          data: {grade:grade} ,
          beforeSend: function() {
            $('#user').html('<img src="<?php echo base_url(); ?>/img/loader.gif" alt="">' );
          },
          success: function(data) {
            $("#user").html(data);
          }
        });
      });
    });
  </script>
  <script type="text/javascript">
    function selectAllCom(){
      var itemsall=document.getElementById('selectall');
      if(itemsall.checked==true){
        var items=document.getElementsByName('stuNameComBook');
        for(var i=0;i < items.length;i++){
          items[i].checked=true;
        }
      }
      else{
        var items=document.getElementsByName('stuNameComBook');
        for(var i=0;i < items.length;i++){
          items[i].checked=false;
        }
      }
    }
</script>
  <script>
  $(document).ready(function() {
    function unseenreplyComBbok(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>Communicationbookteacher/unseenreplyComBbok/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          /*$('.notification-show').html(data.notification);*/
          if (data.unseen_notification > 0) {
            $('.count-new-replayComBook').html(data.unseen_notification);
          }
        }
      });
    }
    function returnedComBook(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>Communicationbookteacher/returnedComBook/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          /*$('.notification-show').html(data.notification);*/
          if (data.unseen_notification > 0) {
            $('.count-returnedcomBook').html(data.unseen_notification);
          }
        }
      });
    }
    function unseenComBook(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>Communicationbookteacher/unseenComBook/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          /*$('.notification-show').html(data.notification);*/
          if (data.unseen_notification > 0) {
            $('.count-new-comBook').html(data.unseen_notification);
          }
        }
      });
    }  
    function unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_notification/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.notification-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-notification').html(data.unseen_notification);
          }
        }
      });
    }  
    function inbox_unseen_notification(view = '') { 
      $.ajax({
        url: "<?php echo base_url() ?>fetch_unseen_message_notification/",
        method: "POST",
        data: ({
            view: view
        }),
        dataType: "json",
        success: function(data) {
          $('.inbox-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-inbox').html(data.unseen_notification);
          }
        }
      });
    }
    unseenreplyComBbok();
    returnedComBook();
    unseenComBook();
    unseen_notification();
    inbox_unseen_notification();
    $(document).on('click', '.seen_noti', function() {
        $('.count-new-notification').html('');
        inbox_unseen_notification('yes');
    });
    $(document).on('click', '.seen', function() {
        $('.count-new-inbox').html('');
        inbox_unseen_notification('yes');
    });
    $(document).on('click', '.seenBook', function() {
        $('.count-new-comBook').html('');
        unseenComBook('yes');
    });
    $(document).on('click', '.seenReplyComBook', function() {
        $('.count-new-replayComBook').html('');
        unseenreplyComBbok('yes');
    });
    setInterval(function() {
      unseenreplyComBbok();
      returnedComBook();
      unseenComBook();
      unseen_notification();
      inbox_unseen_notification();
    }, 5000);
    });
  </script>
</body>

</html>