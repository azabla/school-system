<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
    </title>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/date/daterangepicker.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/izitoast/css/iziToast.min.css">
  <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
       <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-body">
            <div class="row">
              <div class="col-12">
                <?php include('bgcolor.php'); ?>
                <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">
                <div class="card">
                  <div class="card-header">
                  <ul class="nav nav-tabs" id="myTab2" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active" id="home-tab2" data-toggle="tab" href="#feedStuAttendance" role="tab" aria-selected="true">Feed Attendance</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="home-tab3" data-toggle="tab" href="#fetchAttendance" role="tab" aria-selected="false">View Attendance</a>
                    </li>
                  </ul>
                  <div class="tab-content tab-bordered" id="myTab3Content">
                    <div class="tab-pane fade show active" id="feedStuAttendance" role="tabpanel" aria-labelledby="home-tab2">
                    <div class="card-body">
                      <div class="row">
                        <div class="col-md-4 col-6">
                          <div class="form-group">
                           <select class="form-control" required="required" name="gradesec"  id="gradesec">
                           <option>--- Select Grade ---</option>
                            <?php if($_SESSION['usertype']===trim('Director')){
                            foreach($gradesec as $gradesecs){ ?>
                              <option value="<?php echo $gradesecs->gradesec;?>">
                              <?php echo $gradesecs->gradesec;?>
                              </option>
                            <?php } } else{
                              foreach($gradesecs as $gradesecs){ ?>
                              <option value="<?php echo $gradesecs->roomgrade;?>">
                              <?php echo $gradesecs->roomgrade;?>
                              </option> 
                            <?php } }?>
                           </select>
                          </div>
                        </div>
                        <div class="col-md-4 col-6">
                          <div class="form-group">
                            <input class="form-control" name="teaStuAbsentDate" id="teaStuAbsentDate" required="required" type="date">
                          </div>
                        </div>
                        <div class="col-md-4 col-12">
                          <button class="btn btn-primary btn-block" id="fetchStu"> View</button> 
                        </div>
                      </div>
                    </div>
                    <div class="studentList"> </div>
                    </div>
                    <div class="tab-pane fade show" id="fetchAttendance" role="tabpanel" aria-labelledby="home-tab3">
                      <div class="row">
                        <div class ="col-lg-6 col-8"> 
                          <input type="text" class="form-control" id="searchAttendanceReport" name="searchAttendance" placeholder="Search attendance report here..." > 
                        </div>
                        <div class ="col-lg-6 col-4">
                          <button class="btn btn-primary pull-right" name="gethisreport" onclick="codespeedy()">  <i class="fas fa-print"></i>  print   
                          </button>
                        </div>
                      </div>
                    
                    <div class="AttendanceReport table-responsive" id="AttendanceReport" style="height:40vh;">
                    </div>
                    </div>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
      <?php include('footer.php'); ?>
    </div>
  </div>
  <!-- General JS Scripts -->
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>
</body>
<script type="text/javascript">
  function codespeedy(){
    var print_div = document.getElementById("AttendanceReport");
    var print_area = window.open();
    print_area.document.write(print_div.innerHTML);
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" type="text/css" />');
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css" type="text/css" />');
    print_area.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css" type="text/css" />');
    print_area.document.close();
    print_area.focus();
    print_area.print();
  }
</script>
<script type="text/javascript">
  $(document).on('keyup', '#searchAttendanceReport', function() { 
    $searchItem=$('#searchAttendanceReport').val();
    if($('#searchAttendanceReport').val()==''){
      $.ajax({
        url:"<?php echo base_url(); ?>mystudentattendance/fetchStuAttendance/",
        method:"POST",
        beforeSend: function() {
          $('.AttendanceReport').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success:function(data){
          $('.AttendanceReport').html(data);
        }
      })
    }else{
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>mystudentattendance/searchAttendance/",
        data: "searchItem=" + $("#searchAttendanceReport").val(),
        beforeSend: function() {
          $('.AttendanceReport').html( 'Searching...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">' );
        },
        success: function(data) {
          $(".AttendanceReport").html(data);
        }
      });
    }
  });
</script>
<script type="text/javascript">
  $(document).ready(function() {  
    loadStaffsAttendance();
    function loadStaffsAttendance(){
      $.ajax({
        url:"<?php echo base_url(); ?>mystudentattendance/fetchStuAttendance/",
        method:"POST",
        beforeSend: function() {
          $('.AttendanceReport').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa">');
        },
        success:function(data){
          $('.AttendanceReport').html(data);
        }
      });
    }
    $(document).on('click', "input[name='absenStuIdSave']", function() {
      var attendanceId = $(this).attr("value");
      var absentDate = $('#teaStuAbsentDate').val();
      if($(this).is(':checked')){
        if ($('#teaStuAbsentDate').val()!=='') {
          $.ajax({
            method: "POST",
            url: "<?php echo base_url(); ?>mystudentattendance/feedAbsentAttendance/",
            data: ({
              attendanceId: attendanceId,
              absentDate:absentDate
            }),
            cache: false,
            success: function(html) {
              loadStaffsAttendance();
              swal({
                title: 'Student Attendance submitted successfully.',
                text: '',
                icon: 'success',
                buttons: true,
                dangerMode: true,
              })
            }
          });
        }else {
          swal({
            title: 'Please select date to feed attendance.',
            text: '',
            icon: 'error',
            buttons: true,
            dangerMode: true,
          })
        }
      }else{
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>mystudentattendance/deleteAttendance/",
          data: ({
            attendanceId: attendanceId,
            absentDate:absentDate
          }),
          cache: false,
          success: function(html) {
            loadStaffsAttendance();
          }
        });
      }
    });
    $(document).on('click', "input[name='lateStuIdSave']", function() {
      var attendanceId = $(this).attr("value");
      var absentDate=$('#teaStuAbsentDate').val();
      var teaStuAbsentMin=$('#teaStuAbsentMin').val();
      if($(this).is(':checked')){
        if ($('#todayDate').val()!=='' && $('#teaStuAbsentMin').val()!=='') {
          $.ajax({
            method: "POST",
            url: "<?php echo base_url(); ?>mystudentattendance/lateAttendance/",
            data: ({
              attendanceId: attendanceId,
              absentDate:absentDate,
              teaStuAbsentMin:teaStuAbsentMin
            }),
            cache: false,
            success: function(html) {
              loadStaffsAttendance();
              swal({
                title: 'Student Attendance submitted successfully.',
                text: '',
                icon: 'success',
                buttons: true,
                dangerMode: true,
              })
            }
          });
        }
        else {
          swal({
            title: 'Please select all necessary fields to feed attendance.',
            text: '',
            icon: 'error',
            buttons: true,
            dangerMode: true,
          })
        }
      }else{
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>mystudentattendance/deleteAttendance/",
          data: ({
            attendanceId: attendanceId,
            absentDate:absentDate
          }),
          cache: false,
          success: function(html) {
            loadStaffsAttendance();
          }
        });
      }
    });
    $(document).on('click', "input[name='permissionStuIdSave']", function() {
      var attendanceId = $(this).attr("value");
      var absentDate = $('#teaStuAbsentDate').val();
      if($(this).is(':checked')){
        if ($('#teaStuAbsentDate').val()!=='') {
          $.ajax({
            method: "POST",
            url: "<?php echo base_url(); ?>mystudentattendance/permissionAttendance/",
            data: ({
              attendanceId: attendanceId,
              absentDate:absentDate
            }),
            cache: false,
            success: function(html) {
              loadStaffsAttendance();
              swal({
                title: 'Student Attendance submitted successfully.',
                text: '',
                icon: 'success',
                buttons: true,
                dangerMode: true,
              })
            }
          });
        }else {
          alert('Please select date to feed attendance.')
        }
      }else{
        $.ajax({
          method: "POST",
          url: "<?php echo base_url(); ?>mystudentattendance/deleteAttendance/",
          data: ({
            attendanceId: attendanceId,
            absentDate:absentDate
          }),
          cache: false,
          success: function(html) {
            loadStaffsAttendance();
          }
        });
      }
    });
    $(document).on('click', '.deleteStuAttendance', function() {
      var attendanceId = $(this).attr("value");
      var absentDate = $(this).attr("id");
      swal({
        title: 'Are you sure to delete this attendance?',
        text: '',
        icon: 'warning',
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
          $.ajax({
            method: "POST",
            url: "<?php echo base_url(); ?>mystudentattendance/removeAttendance/",
            data: ({
              attendanceId: attendanceId,
              absentDate:absentDate
            }),
            cache: false,
            success: function(html) {
              loadStaffsAttendance();
            }
          });
        }
      });
    });
  });
</script>
<script type="text/javascript">

</script>
<script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass();
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='white']").addClass("active");
      $(".selectgroup-input[value|='1']").prop("checked", true);
    } else {
      $("body").removeClass();
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='black']").addClass("active");
      $(".selectgroup-input[value|='2']").prop("checked", true);
    }
  });
</script>
<script type="text/javascript" language="javascript"> 
  var bgcolor_now=document.getElementById("bgcolor_now").value;
  if (bgcolor_now == "1") {
    $("body").removeClass();
    $("body").addClass("light");
    $("body").addClass("light-sidebar");
    $("body").addClass("theme-white");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='white']").addClass("active");
    $(".selectgroup-input[value|='1']").prop("checked", true);
  }else {
    $("body").removeClass();
    $("body").addClass("dark");
    $("body").addClass("dark-sidebar");
    $("body").addClass("theme-black");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='black']").addClass("active");
    $(".selectgroup-input[value|='2']").prop("checked", true);
  } 
</script> 
<script type="text/javascript">
  $(document).ready(function() {  
    $("#fetchStu").on("click", function() {
      var fetchDate=$('#teaStuAbsentDate').val();
      var gradesec=$("#gradesec").val();
      if($('#teaStuAbsentDate').val()!==''){
        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>mystudentattendance/filterGradesecForTeachers/",
          data:({
            gradesec:gradesec,
            fetchDate:fetchDate
          }) ,
          beforeSend: function() {
            $('.studentList').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="70" height="70" id="loa">');
          },
          success: function(data) {
            $(".studentList").html(data);
          }
        });
      }
      else{
        swal({
          title: 'Please select all necessary fields.',
          text: '',
          icon: 'error',
          buttons: true,
          dangerMode: true,
        })
      }
    });
  });
</script>
<script>
  $(document).ready(function() {
    function fetchNewAttendance(view = '') {
      $.ajax({
        url: "<?php echo base_url(); ?>Mystudentattendance/attendanceNotification/",
        method: "POST",
        data: ({
          view: view
        }),
        dataType:"json",
        success: function(data) {
          $('.mark-show').html(data.notification);
          if (data.unseen_notification > 0) {
            $('.count-new-mark').html(data.unseen_notification);
          }
        }
      });
    }  
    fetchNewAttendance();
    $(document).on('click', '.seen_noti', function() {
      $('.new-notification').html('');
      inbox_unseen_notification('yes');
    });
    $(document).on('click', '.seen', function() {
      $('.count-new-inbox').html('');
      inbox_unseen_notification('yes');
    });
    setInterval(function() {
      fetchNewAttendance();
    }, 5000);

  });
</script>
</html>