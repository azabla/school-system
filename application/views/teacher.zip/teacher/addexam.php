<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title> 
    <?php foreach($schools as $school) {
      echo $school->name;}
      ?>
  </title>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/app.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/pages/selectric.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
  <link rel='shortcut icon' type='image/x-icon'
   href='<?php echo base_url(); ?>/logo/<?php echo $school->logo;?>' />
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
       <?php include('header.php'); ?>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <?php include('left_menu.php'); ?>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
           <?php 
          if($summerClassMark->num_rows()>0){ ?>
             <div class="alert alert-warning alert-dismissible show fade">
            <div class="alert-body">
              <button class="close"  data-dismiss="alert">
                <span>&times;</span>
              </button>
              <i class="fas fa-check-circle"> </i> Summer class has been started. Please contact your system Admin.
            </div>
            </div> 
          <?php } else { if($markstatus->num_rows()>0 || $checkAutoLock){?>
            <div class="alert alert-warning alert-dismissible show fade">
            <div class="alert-body">
              <button class="close"  data-dismiss="alert">
                <span>&times;</span>
              </button>
              <i class="fas fa-check-circle"> </i> Access denied.
            </div>
            </div> 
          <?php } else{ ?>
          <div class="section-body">
            <?php include('bgcolor.php'); ?>
            <input type="hidden" id="bgcolor_now" value="<?php echo $sid ?>">
            <div class="row">
              <div class="col-12">
                <?php if(isset($_SESSION['success'])){ ?>
                <span class="text-success">
                  <?php echo $_SESSION['success']; ?>
                </span>
                <?php  }
                elseif(isset($_SESSION['error'])) { ?>
                <span class="text-danger">
                  <?php echo $_SESSION['error']; ?>  
                </span>
                <?php } ?>
                <div class="card">
                  <div class="card-header">
                    <h4>Add New Result</h4>
                  </div>
                  <div class="card-header">
                    <form method="POST" id="comment_form">
                     <div class="row">
                      <div class="col-lg-2 col-6">
                         <div class="form-group">
                           <select class="form-control selectric"
                           required="required" name="academicyear" 
                           id="academicyear">
                            <?php foreach($academicyear as $academicyears){ ?>
                              <option value="<?php echo $academicyears->year_name;?>">
                              <?php echo $academicyears->year_name;?>
                              </option>
                            <?php }?>
                           </select>
                          </div>
                         </div>
                         <div class="col-lg-3 col-6">
                          <div class="form-group">
                           <select class="form-control selectric"
                           required="required" name="gradesec"
                           id="gradesec">
                           <option>--- Select Grade ---</option>
                            <?php foreach($fetch_grade_fromsp_toadd_neweaxm as $gradesecs){ ?>
                              <option value="<?php echo $gradesecs->grade;?>">
                              <?php echo $gradesecs->grade;?>
                              </option>
                            <?php }?>
                           </select>
                          </div>
                         </div>
                        <div class="col-lg-3 col-6">
                           <div class="form-group">
                          <select class="form-control subject"
                            name="subject" required="required" id="subject">
                            <option> </option>
                          </select>
                          </div>
                         </div>
                         <div class="col-lg-3 col-6">
                         <div class="form-group">
                           <select class="form-control selectric" required="required" name="quarter" 
                           id="quarter">
                          <option>--- Select Quarter ---</option>
                           </select>
                          </div>
                        </div>
                        <div class="col-lg-3 col-6">
                         <div class="form-group">
                          <select class="form-control selectric"
                           required="required" name="evaluation" 
                           id="evaluation">
                          <option>--- Select Evaluation ---</option> </select>
                          </div>
                        </div>
                        <div class="col-lg-3 col-6">
                         <div class="form-group">
                            <select class="form-control" required="required" name="assesname" required="required" id="assesname">
                              <option>--- Select Assesment ---</option>
                            </select>
                          </div>
                         </div>
                         <div class="col-lg-3 col-6">
                         <div class="form-group">
                           <input type="number" class="form-control" name="percentage" id="percentage" required="required" placeholder="Percentage...">
                          </div>
                         </div>
                       <div class="col-lg-2 col-6">
                        <button class="btn btn-primary btn-block" type="submit" name="startmark">Start</button>
                      </div>
                    </div>
                  </form>
                  <div class="markform"></div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
          <?php } }?>
        </section>
      </div>
      <footer class="main-footer">
        <div class="footer-left">
         Call:+251967829025 &nbsp;&nbsp;
          Copyright &copy<?php echo date('Y');?>
          <a href="https://www.grandstande.com" target="_blanck">Grandstande IT Solution Plc</a>
          All rights are Reserved.
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script>
</body>
<!-- fetch student for new mark result starts -->
<script type="text/javascript">
 $(document).ready(function() {  
    $("#evaluation").bind("change", function() {
      var gradesec=$("#gradesec").val();
      var evaluation=$("#evaluation").val();
      var quarter=$("#quarter").val();
      var subject=$("#subject").val();
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Addstudentresult/FilterAssesmentQuarterChange/",
        data: ({
          gradesec:gradesec,
          evaluation:evaluation,
          quarter:quarter,
          subject:subject
        }),
         beforeSend: function() {
          $('#assesname').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(data) {
          $("#assesname").html(data);
        }
      });
    });
 });
</script>
<script>
  $('#comment_form').on('submit', function(event) {
    event.preventDefault();
    var academicyear=$("#academicyear").val();
    var gradesec=$("#gradesec").val();
    var subject=$("#subject").val();
    var evaluation=$("#evaluation").val();
    var quarter=$("#quarter").val();
    var assesname=$("#assesname").val();
    var percentage=$("#percentage").val();
    if($("#subject").val()!=''){
    $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>Addstudentresult/studentResultForm/",
      data: ({
        academicyear: academicyear,
        gradesec:gradesec,
        subject:subject,
        evaluation:evaluation,
        quarter:quarter,
        assesname:assesname,
        percentage:percentage
      }),
      cache: false,
      beforeSend: function() {
        $('.markform').html( 'Loading...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="54" height="54" id="loa">' );
      },
      success: function(html){
        $('.markform').html(html);
      }
    });
    }else{
    alert('Please select all fields!');
  }
  });
</script>
<!-- save mark result starts -->
<script>
  function chkMarkValue(){
    var stuid=$("#stuid").val();
    var chkPercent=parseInt($("#percentage").val());
    var markResult=$("#resultvalue").val();
    $("input[name='markvalue_result']").each(function(i){
      resultvalue=parseInt($(this).val());
      if(resultvalue > chkPercent){
        swal({
          title: 'Oooops, Incorrect Mark result. Please try Again.',
          text: '',
          icon: 'warning',
          buttons: true,
          dangerMode: true,
        })
      }
    });
  }
  $(document).on('click', '#SaveResult', function() {
    /*event.preventDefault();*/
    var stuid=$("#stuid").val();
    /*var resultvalue=$("#resultvalue").val();*/
    var academicyear=$("#academicyear").val();
    var subject=$("#subject").val();
    var evaluation=$("#evaluation").val();
    var quarter=$("#quarter").val();
    var assesname=$("#assesname").val();
    var percentage=$("#percentage").val();
    var markGradeSec=$("#markGradeSec").val();
    stuid=[];resultvalue=[];
      $("input[name='stuid_result']").each(function(i){
        stuid[i]=$(this).val();
      });
      $("input[name='markvalue_result']").each(function(i){
        resultvalue[i]=$(this).val();
      });
    $.ajax({
      method: "POST",
      url: "<?php echo base_url(); ?>Addstudentresult/addNewresult/",
      data: ({
        stuid:stuid,
        resultvalue:resultvalue,
        academicyear: academicyear,
        subject:subject,
        evaluation:evaluation,
        quarter:quarter,
        assesname:assesname,
        percentage:percentage,
        markGradeSec:markGradeSec
      }),
      cache: false,
      beforeSend: function() {
        $('.markform').html( '<h3><span class="text-success">Saving...<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="74" height="74" id="loa"></span></h3>' );
      },
      success: function(html){
        $('.markform').html(html);
      }
    });
  });
</script>
<script type="text/javascript">
  $(document).on('click', '#changecolor', function() {
    var bgcolor=$(this).attr("value");
    $.ajax({
      url: "<?php echo base_url(); ?>Change_bgcolor/",
      method: "POST",
      data: ({
        bgcolor: bgcolor
      }),
    });
    if (bgcolor == "1") {
      $("body").removeClass();
      $("body").addClass("light");
      $("body").addClass("light-sidebar");
      $("body").addClass("theme-white");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='white']").addClass("active");
      $(".selectgroup-input[value|='1']").prop("checked", true);
    } else {
      $("body").removeClass();
      $("body").addClass("dark");
      $("body").addClass("dark-sidebar");
      $("body").addClass("theme-black");
      $(".choose-theme li").removeClass("active");
      $(".choose-theme li[title|='black']").addClass("active");
      $(".selectgroup-input[value|='2']").prop("checked", true);
    }
  });
</script>
<script type="text/javascript" language="javascript"> 
  var bgcolor_now=document.getElementById("bgcolor_now").value;
  if (bgcolor_now == "1") {
    $("body").removeClass();
    $("body").addClass("light");
    $("body").addClass("light-sidebar");
    $("body").addClass("theme-white");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='white']").addClass("active");
    $(".selectgroup-input[value|='1']").prop("checked", true);
  }else {
    $("body").removeClass();
    $("body").addClass("dark");
    $("body").addClass("dark-sidebar");
    $("body").addClass("theme-black");
    $(".choose-theme li").removeClass("active");
    $(".choose-theme li[title|='black']").addClass("active");
    $(".selectgroup-input[value|='2']").prop("checked", true);
  } 
</script>
<script type="text/javascript">
 $(document).ready(function() {  
    $("#gradesec").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Filter_subject_from_staffp/",
        data: "gradesec=" + $("#gradesec").val(),
         beforeSend: function() {
          $('.subject').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(data) {
          $(".subject").html(data);
        }
      });
    });
 });
</script>
<script type="text/javascript">
  $(document).ready(function() {  
    $("#gradesec").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Filter_quarter/",
        data: "gradesec=" + $("#gradesec").val(),
         beforeSend: function() {
          $('#quarter').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">'
          );
        },
        success: function(data) {
          $("#quarter").html(data);
        }
      });
    });
  });
</script>
<script type="text/javascript">
  $(document).ready(function() {  
    $("#gradesec").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Filter_quarter/",
        data: "gradesec=" + $("#gradesec").val(),
         beforeSend: function() {
          $('#quarter').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">'
          );
        },
        success: function(data) {
          $("#quarter").html(data);
        }
      });
    });
  });
</script>
<script type="text/javascript">
 $(document).ready(function() {  
    $("#quarter").bind("change", function() {
      var gradesec=$("#gradesec").val();
      var quarter=$("#quarter").val();
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Filter_evaluation_quarterchange/",
        data: ({
          gradesec:gradesec,
          quarter:quarter
        }),
         beforeSend: function() {
          $('#evaluation').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">' );
        },
        success: function(data) {
          $("#evaluation").html(data);
        }
      });
    });
 });
</script>
<script type="text/javascript">
  $(document).ready(function() {  
    $("#subject").bind("change", function() {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Filter_quarter/",
        data: "gradesec=" + $("#gradesec").val(),
         beforeSend: function() {
          $('#quarter').html( '<img src="<?php echo base_url(); ?>/img/loader.gif" alt="" width="34" height="34" id="loa">'
          );
        },
        success: function(data) {
          $("#quarter").html(data);
        }
      });
    });
  });
</script>
</html>